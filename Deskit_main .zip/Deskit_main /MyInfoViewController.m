//
//  ViewController.m
//  My Info
//
//  Created by xtoucher08 on 13-6-30.
//  Copyright (c) 2013年 xtoucher08. All rights reserved.
//

#import "MyInfoViewController.h"
#import "constant.h"

@interface MyInfoViewController ()

@end

@implementation MyInfoViewController
@synthesize name;
@synthesize studyNo;
@synthesize college;

@synthesize nameInf;
@synthesize studyNoInf;
@synthesize collageInf;

@synthesize lastview;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self LoadingInfo];
    gesture=[[UIPanGestureRecognizer alloc]init];
    [gesture addTarget:self action:@selector(backGuesture:)];
    [self.view addGestureRecognizer:gesture];
    [name setEnabled:NO];
    [studyNo setEnabled:NO];
    [college setEnabled:NO];
    
    CGRect frame=CGRectMake(-lastview.size.width, 0, lastview.size.width, lastview.size.height);
    lastView=[[UIImageView alloc]initWithImage:lastview];
    [lastView setFrame:frame];
    [self.view addSubview:lastView];

    
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestufreRecognizer
{
    
	return gesture.state == UIGestureRecognizerStatePossible;
}

-(void)backGuesture:(UIPanGestureRecognizer*) sender
{
    switch (sender.state) {
        case UIGestureRecognizerStatePossible:
        {
            break;
        }
        case UIGestureRecognizerStateBegan:
        {
            FirstPosition=[sender locationInView:self.view];
            break;
        }
        case UIGestureRecognizerStateChanged:
        {
            CGPoint translation=[sender translationInView:self.view];
            if (abs((int)translation.y)*3 < translation.x)
            {
                CGPoint NowPosition=[sender locationInView:self.view];
                CGRect frame=self.view.frame;
                float Xmove=(NowPosition.x-FirstPosition.x);
                frame.origin.x+=Xmove;
                [self.view setFrame:frame];
            }
            break;
        }
        case UIGestureRecognizerStateEnded:
        {
            NSLog(@"lastview %f,%f",lastView.frame.origin.x,lastView.frame.size.width);
            if (self.view.frame.origin.x>back_width) {
                [UIView animateWithDuration:0.3f
                                      delay:0
                                    options:UIViewAnimationOptionCurveLinear
                                 animations:^{
                                     CGRect frame = self.view.frame;
                                     frame.origin.x = 320;
                                     [self.view setFrame:frame];

                                 }
                                 completion:^(BOOL finished) {
                                     [self.navigationController popViewControllerAnimated:NO];
                                 }
                 ];
            }
            else
            {
                [UIView animateWithDuration:0.3f
                                      delay:0
                                    options:UIViewAnimationOptionCurveLinear
                                 animations:^{
                                     CGRect frame = self.view.frame;
                                     frame.origin.x = 0;
                                     [self.view setFrame:frame];
                                   
                                 }
                                 completion:^(BOOL finished) {
                                     
                                 }
                 
                 ];
            }
            break;
        }
        case UIGestureRecognizerStateCancelled:
        {
            break;
        }
            
        default:
            break;
    }
    
}



-(void)LoadingInfo
{
    NSURL *url=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,@"/front/front_user/current_info"]];
    inforequest=[ASIFormDataRequest requestWithURL:url];
    [inforequest setRequestMethod:@"POST"];
    [inforequest setDelegate:self];
    [inforequest startAsynchronous];

}




-(void)requestFinished:(ASIHTTPRequest *)request
{
    NSError *error;
    NSData *responseData = [request responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
    
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        
        
        //        NSLog(@"%@",responseDictionary);
        
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"返回值出错");
            NSLog(@"%@",ResponseErrMsg);
            return ;
        }
        
        
        
        
    }
    
    
    
    NSDictionary *data=[responseDictionary objectForKey:@"data"];
    NSLog(@"%@",data);
//    NSString *name1=[data objectForKey:@"user_name"];
    nameInf.text=[data objectForKey:@"user_name"];
    
    
}





-(IBAction)closeKeyBoard:(id)sender{
    [name resignFirstResponder];
    [studyNo resignFirstResponder];
    [college resignFirstResponder];
}


-(IBAction)popback:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc
{
    if (inforequest) {
        [inforequest clearDelegatesAndCancel];
        inforequest=nil;
    }

}

@end
