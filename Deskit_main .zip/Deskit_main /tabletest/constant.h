//
//  constant.h
//  SGFocusImageFrame
//
//  Created by Sway on 13-6-12.
//  Copyright (c) 2013年 Shane Gao. All rights reserved.
//

#ifndef SGFocusImageFrame_constant_h
#define SGFocusImageFrame_constant_h


#define table_view_hight 73
#define view_slide_left 276
#define data_file_name @"TableViewCellData"
#define icon_width 100
#define back_width 70


#define kNewsTitleHight 34 //新闻透明标题栏的高
#define kScrollDotWidth 10 //新闻头条的ScrollView的小点长宽
#define kScrollDotHight 10

#define kNewsTitleLabelHight 17
#define kUIPageControlHight 10

#define kDotSpacer 14 //UIPageControl 的间距


#define basePath @"http://deskit.lijin.dashi.us"
#define HotTagListURL @"/front/tag/hot/list" //热门标签url
#define SlideUrl @"/front/essay/slide/list"//顶部滑动头条

#define ListUrl @"/front/category/list"//Tableview
#define ListDetailUrl @"/front/category/essay/current_list"//TableviewCell的内容
#define ListDetailLeftUrl @"/front/essay/current_detail"//Cell左侧划出小格的数据 input id
#define LoginUrl @"/front/front_user/login"//登陆
#define isLoginUrl @"/front/front_user/is_login"//是否登陆
#define LogoutUrl @"/front/front_user/logout" //注销

#define MySubscribeListUrl @"/front/front_user/tag/subscribe/current_list" //input null
#define SubscribeCommitUrl @"/front/front_user/tag/subscribe/current_create"//input tag_id
#define SubscribeCancelUrl @"/front/front_user/tag/subscribe/current_delete"//input tag_id
#define MyFavoriteListUrl @"/front/front_user/essay/favorite/current_list" // list_query ListQuery
#define TagCloudUrl @"/front/combine/category/tag/list"//标签云
#define TagListUrl @"/front/category/tag/list"//通过category_id获得tag列表
#define TagDetailUrl @"/front/tag/current_detail"//标签详细信息



#define LikeStateUrl @"/front/front_user/essay/like/current_is"//是否喜欢某篇消息 input essay_id
#define LikeCancelUrl @"/front/front_user/essay/like/current_delete"//不喜欢某篇消息了
#define LikeCommitUrl @"/front/front_user/essay/like/current_create"//喜欢某篇消息
#define LikeTotalUrl @"/front/essay/front_user/like/total"//某篇消息喜欢人数
#define FavoriteStateUrl @"/front/front_user/essay/favorite/current_is"//是否收藏某篇消息
#define FavoriteCancelUrl @"/front/front_user/essay/favorite/current_delete"
#define FavoriteCommitUrl @"/front/front_user/essay/favorite/current_create"
#define FavoriteTotalUrl @"/front/essay/front_user/favorite/total"
#define EssayDetail @"/front/essay/detail"

#define SearchUrl @"/front/search/list"

#define serverDataError 101;//连接传过来的数据无法解析
#define responseNoting 102;//服务器没有传过来任何东西
#define dataStructError 103;//服务器传来的json结构与约定的不同
#define dataError 104;//数据存在错误
#define NoLogin 105;//用户未登陆


#define notificationNumber @"/front/essay/push/current_front_user_unread_number" //推送数量
#define notificationListUnread @"/front/essay/push/current_unread_list" //未读推送列表
#define notificationList @"/front/essay/push/list" //推送列表 input:list_query ListQuery


#define ScreenFrame_iPhone   [[UIScreen mainScreen] bounds]
#define ScreenFrame_without_status_iphone CGRectMake(ScreenFrame_iPhone.origin.x, ScreenFrame_iPhone.origin.y, ScreenFrame_iPhone.size.width, ScreenFrame_iPhone.size.height-20)
#define Screen_Height_4inch_without_status 568
#define Screen_Height_4inch_with_status 548

#endif

