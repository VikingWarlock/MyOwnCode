//
//  ViewController.h
//  Setting
//
//  Created by xtoucher08 on 13-6-30.
//  Copyright (c) 2013年 xtoucher08. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIFormDataRequest.h"
#import "constant.h"
#import "JsonDataFormatting.h"
#import "LoginViewController.h"
#import "Switch.h"
#import "ImageLocalized.h"

@interface SettingViewController : UIViewController
{
    NSArray*path;
    NSString *pathDocuments;
    UIPanGestureRecognizer *gesture;
    CGPoint FirstPosition;
    UIImageView *lastView;
    UIImage *lastview;
}
@property UIImage *lastview;

@property (nonatomic,retain) IBOutlet Switch *offline;
@property (nonatomic,retain) IBOutlet Switch *mySwitch;
@property (nonatomic,retain) IBOutlet UITextField *mysending;
@property (nonatomic,retain) IBOutlet UIButton *cleanButton;
@property (nonatomic,retain) IBOutlet UILabel *nameLabel;
@property (nonatomic,retain) IBOutlet UILabel *numLabel;
@property BOOL pushState;

@end
