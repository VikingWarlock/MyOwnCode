//
//  ViewController.m
//  Setting
//
//  Created by xtoucher08 on 13-6-30.
//  Copyright (c) 2013年 xtoucher08. All rights reserved.
//

#import "SettingViewController.h"
#import "Switch.h"
@interface SettingViewController ()

@end

@implementation SettingViewController
@synthesize mySwitch;
@synthesize mysending;
@synthesize cleanButton;
@synthesize nameLabel;
@synthesize numLabel;
@synthesize lastview;
@synthesize offline;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
 
    path=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    pathDocuments=[path objectAtIndex:0];
//    NSError *errorInf=nil;
    
   // [mySwitch addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
    
    
    mySwitch.arrange = CustomSwitchArrangeONLeftOFFRight;
    mySwitch.onImage = [UIImage imageNamed:@"switch-on.png"];
    mySwitch.offImage = [UIImage imageNamed:@"switch-off.png"];
    mySwitch.method=@"PushButton";
    
    offline.arrange = CustomSwitchArrangeOFFLeftONRight;
    offline.onImage = [UIImage imageNamed:@"switch-off.png"];
    offline.offImage = [UIImage imageNamed:@"switch-on.png"];
    offline.method=@"Cellular";
    
    NSDictionary *setting=[[NSDictionary alloc]initWithContentsOfFile:[NSString stringWithFormat:@"%@/%@",pathDocuments,@"setting.plist"]];
    BOOL yesPush=[[setting objectForKey:@"PushButton"]intValue];
    if (yesPush) {
    mySwitch.status = CustomSwitchStatusOn;
    }else mySwitch.status = CustomSwitchStatusOff;
    
    BOOL yesCellular=[[setting objectForKey:@"Cellular"]intValue];
    if (yesCellular) {
        offline.status = CustomSwitchStatusOn;
    }else offline.status = CustomSwitchStatusOff;
    

    

    [mysending setEnabled:NO];
     
    
    float calculateSize=[self fileSizeForDir:pathDocuments]/1024.0/1024;
    
    numLabel.text=[[NSString alloc]initWithFormat:@"%.1f MB",calculateSize];
    
    cleanButton=[[UIButton alloc]init];
    [cleanButton addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    gesture=[[UIPanGestureRecognizer alloc]init];
    [gesture addTarget:self action:@selector(backGuesture:)];
    [self.view addGestureRecognizer:gesture];
    CGRect frame=CGRectMake(-lastview.size.width, 0, lastview.size.width, lastview.size.height);
    lastView=[[UIImageView alloc]initWithImage:lastview];
    [lastView setFrame:frame];
    [self.view addSubview:lastView];
    

    

    
}


- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestufreRecognizer
{
    
	return gesture.state == UIGestureRecognizerStatePossible;
}

-(void)backGuesture:(UIPanGestureRecognizer*) sender
{
    switch (sender.state) {
        case UIGestureRecognizerStatePossible:
        {
            break;
        }
        case UIGestureRecognizerStateBegan:
        {
            FirstPosition=[sender locationInView:self.view];
            break;
        }
        case UIGestureRecognizerStateChanged:
        {
            CGPoint translation=[sender translationInView:self.view];
            if (abs((int)translation.y)*3 < translation.x)
            {
                CGPoint NowPosition=[sender locationInView:self.view];
                CGRect frame=self.view.frame;
                float Xmove=(NowPosition.x-FirstPosition.x);
                frame.origin.x+=Xmove;
                [self.view setFrame:frame];
            }
            break;
        }
        case UIGestureRecognizerStateEnded:
        {
            NSLog(@"lastview %f,%f",lastView.frame.origin.x,lastView.frame.size.width);
            if (self.view.frame.origin.x>back_width) {
                [UIView animateWithDuration:0.3f
                                      delay:0
                                    options:UIViewAnimationOptionCurveLinear
                                 animations:^{
                                     CGRect frame = self.view.frame;
                                     frame.origin.x = 320;
                                     [self.view setFrame:frame];
                                     
                                 }
                                 completion:^(BOOL finished) {
                                     [self.navigationController popViewControllerAnimated:NO];
                                 }
                 ];
            }
            else
            {
                [UIView animateWithDuration:0.3f
                                      delay:0
                                    options:UIViewAnimationOptionCurveLinear
                                 animations:^{
                                     CGRect frame = self.view.frame;
                                     frame.origin.x = 0;
                                     [self.view setFrame:frame];
                                     
                                 }
                                 completion:^(BOOL finished) {
                                     
                                 }
                 
                 ];
            }
            break;
        }
        case UIGestureRecognizerStateCancelled:
        {
            break;
        }
            
        default:
            break;
    }
    
}

-(long)fileSizeForDir:(NSString*)pathes//计算文件夹下文件的总大小
{
    NSFileManager *fileManager = [[NSFileManager alloc] init];
    long size=0;
    NSArray* array = [fileManager contentsOfDirectoryAtPath:pathes error:nil];
    for(int i = 0; i<[array count]; i++)
    {
        NSString *fullPath = [pathes stringByAppendingPathComponent:[array objectAtIndex:i]];
        
        BOOL isDir;
        if ( !([fileManager fileExistsAtPath:fullPath isDirectory:&isDir] && isDir) )
        {
          //  NSLog(@"%@",fullPath);
            NSDictionary *fileAttributeDic=[fileManager attributesOfItemAtPath:fullPath error:nil];
            size+= fileAttributeDic.fileSize;

        }
        else
        {
          size+=[self fileSizeForDir:fullPath];
        }
    }
    NSLog(@"%ld",size);
    return size;
    
}

/*
-(void)switchAction:(id)sender{
    UISwitch *Switch=(UISwitch *)sender;
  //  ImageLocalized *file=[[ImageLocalized alloc]init];
    BOOL isButtonOn=[Switch isOn];
    if(isButtonOn){
        NSLog(@"on");
        
    }else{
        NSLog(@"off");
   
    
    }
}
*/

-(void)buttonClick{
    self.nameLabel.textColor=[UIColor grayColor];
    self.numLabel.textColor=[UIColor grayColor];
    
}

- (IBAction)popBack:(id)sender {
//    [self unloadThisView];
    [self.navigationController popViewControllerAnimated:YES];
    
    
}

-(IBAction)logout:(id)sender
{
    ASIFormDataRequest *logout;
    NSURL *url=[NSURL URLWithString:[basePath stringByAppendingString:LogoutUrl]];
    logout=[ASIFormDataRequest requestWithURL:url];
    [logout setRequestMethod:@"POST"];
    [logout startSynchronous];
    
    NSError *error;
    NSData *data = [logout responseData];
    NSDictionary *dictionary =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
    if (error!=nil){
        ;
        return;
    }
    
    if (![[dictionary objectForKey:@"err"] isKindOfClass:[NSNull class]]){
        return ;
    }

    LoginViewController *login=[[LoginViewController alloc]init];
    [[UIApplication sharedApplication] keyWindow].rootViewController=login;

    
    
}

-(IBAction)warning:(id)sender
{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"清理缓存完毕" message:@"删除保存的图片，文章信息\n并且注销登录" delegate:self
                                       cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

-(IBAction)ClearFile:(id)sender
{
       
    NSError *errorInf=nil;
    
    
    NSDictionary *setting=[[NSDictionary alloc]initWithContentsOfFile:[NSString stringWithFormat:@"%@/%@",pathDocuments,@"setting.plist"]];
    
    if([[NSFileManager defaultManager]removeItemAtPath:pathDocuments error:&errorInf])
    {
        numLabel.text=@"0.0 MB";
        if( [[NSFileManager defaultManager]createDirectoryAtPath:pathDocuments withIntermediateDirectories:YES attributes:nil error:NULL])
            NSLog(@"succeed create folder");
        else
            NSLog(@"fail create folder");

         NSString *myDirectory =[pathDocuments stringByAppendingPathComponent:@"img"];
        if( [[NSFileManager defaultManager]createDirectoryAtPath:myDirectory withIntermediateDirectories:YES attributes:nil error:NULL])
            NSLog(@"succeed create folder");
        else
            NSLog(@"fail create folder");
        

    }
    [setting writeToFile:[NSString stringWithFormat:@"%@/%@",pathDocuments,@"setting.plist"] atomically:YES];
    //    [self logout:nil];
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"MainStoryboard" bundle:[NSBundle mainBundle]];
    
    [[UIApplication sharedApplication] keyWindow].rootViewController=[storyBoard instantiateInitialViewController];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
