//
//  NewsCell.h
//  Deskit_beta
//
//  Created by Sway on 13-6-20.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsCell : UITableViewCell

@end
