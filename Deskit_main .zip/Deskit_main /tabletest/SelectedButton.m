//
//  SelectedButton.m
//  Test
//
//  Created by Sway on 13-6-22.
//  Copyright (c) 2013年 Sway. All rights reserved.
//

#import "SelectedButton.h"
@interface SelectedButton(){
    UIImage *NormalImage,*SelectedImage;
}

@end
@implementation SelectedButton


-(void)setSelectedImage:(UIImage *)Simage{
    SelectedImage=Simage;
//    [self setImage:SelectedImage forState:UIControlStateNormal];
}

-(void)setNormalImage:(UIImage *)Nimage{
    NormalImage=Nimage;
    [self setImage:NormalImage forState:UIControlStateNormal];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame NormalImage:(UIImage*)Nimage SelectedImage:(UIImage *)Simage{
    self =[super initWithFrame:frame];
    if (self){
        NormalImage=Nimage;
        SelectedImage=Simage;
        [self setImage:Nimage forState:UIControlStateNormal];
        
        self.SelectedState=NO;
        [self addTarget:self action:@selector(Select) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

-(void)InitForPress{
    self.SelectedState=NO;
    [self addTarget:self action:@selector(Select) forControlEvents:UIControlEventTouchUpInside];
}





-(void)ButtonNormalState{
//    [self setBackgroundImage:NormalImage forState:UIControlStateNormal];
    [self setImage:NormalImage forState:UIControlStateNormal];
    self.SelectedState=NO;
}
-(void)ButtonSelectedState{
//    [self setBackgroundImage:SelectedImage forState:UIControlStateNormal];
    [self setImage:SelectedImage forState:UIControlStateNormal];
    self.SelectedState=YES;
}

-(void)Select{
    if (self.SelectedState==NO){
        [self ButtonSelectedState];
    }
    else [self ButtonNormalState];

}




-(void)setButtonState:(BOOL)State{
    _SelectedState=State;
    if (State)    [self setImage:SelectedImage forState:UIControlStateNormal];
    else     [self setImage:NormalImage forState:UIControlStateNormal];
}



//-(void)setSelectedState:(BOOL)SelectedState{
//    _SelectedState=SelectedState;
//    if (SelectedState)    [self setImage:SelectedImage forState:UIControlStateNormal];
//    else     [self setImage:NormalImage forState:UIControlStateNormal];
//    
//}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
