//
//  Transition.h
//  Deskit_beta
//
//  Created by Sway on 13-9-20.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Transition : NSObject

+(void)pushViewControllerFormBotton:(UIViewController*)base ViewController:(UIViewController*)controller;
+(void)popViewControllerToBotton:(UIViewController*)base;
@end
