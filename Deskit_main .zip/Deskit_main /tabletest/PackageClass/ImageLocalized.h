//
//  ImageLocalized.h
//  Deskit_beta
//
//  Created by viking warlock on 8/22/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "JsonDataFormatting.h"
#import "ASIHTTPRequestDelegate.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"

@interface ImageLocalized : NSObject

{
    
    NSArray*path;
    NSString *pathDocuments;

}

//@property NSArray *path;
//@property NSString *pathDocuments;

-(void) addDataToFile :(NSObject*) data forKey:(NSString *)key FileName:(NSString*)name; //更改原始数据
-(void) addPic :(UIImage *)image URL_Address:(NSString*)urlAddress DataBaseFileName:(NSString*)filename FileNameDetail:(NSString*) detail;
-(NSDictionary*) readNSDictionary :(NSString*) FileName :(NSString*) options;

-(BOOL) updateDataToFile :(NSObject*) data forkey:(NSString*)key FileName:(NSString*)name Path:(NSArray*) optionals; //向原始数据添加项目
-(BOOL) checkPicById :(NSString*) idnumber  DataBaseFileName:(NSString *)filename;
-(BOOL) checkPicByPath:(NSString *)path DataBaseFileName:(NSString *)filename;
-(BOOL) downloadPicToFile :(NSString*)filename IDNumber:(NSString*)idnumber URL:(NSString *)url;

-(UIImage*) LoadPicById :(NSString*)idnumber DataBaseFileName:(NSString*)filename;
-(UIImage*) LoadPicByPath:(NSString *)path DataBaseFileName:(NSString *)filename;

-(UIImage*)captureView:(UIView *)theView;

@end
