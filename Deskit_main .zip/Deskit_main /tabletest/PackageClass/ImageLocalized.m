



//
//  ImageLocalized.m
//  Deskit_beta
//
//  Created by viking warlock on 8/22/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import "ImageLocalized.h"
#import <QuartzCore/QuartzCore.h>

@implementation ImageLocalized

/*
@synthesize path;
@synthesize pathDocuments;
*/


-(void) NessaryDataInit
{
    path=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    pathDocuments=[path objectAtIndex:0];
}



-(void)addDataToFile:(NSObject *)data forKey:(NSString *)key FileName:(NSString *)name
{
    [self NessaryDataInit];
    NSMutableDictionary *temp=[[NSMutableDictionary alloc]initWithContentsOfFile:[NSString stringWithFormat:@"%@/%@",pathDocuments,name]];
    if (temp) {
    }
    else temp=[[NSMutableDictionary alloc]init];

    [temp setObject:data forKey:key];

    
    if([temp writeToFile:[NSString stringWithFormat:@"%@/%@",pathDocuments,name] atomically:YES])
    {NSLog(@"AddDataToFile Succeed");}
    else{
        NSLog(@"negative!!\n\n\n");}
    
    
}

-(void)addPic:(UIImage *)image URL_Address:(NSString *)urlAddress  DataBaseFileName:(NSString *)filename FileNameDetail:(NSString *)detail
{
    [self NessaryDataInit];
    NSMutableDictionary *imageDictionary=[[NSMutableDictionary alloc]init];
    int PictureSumNumber=0;
    NSMutableDictionary *temp=[[NSMutableDictionary alloc]initWithContentsOfFile:[NSString stringWithFormat:@"%@/picMatch.plist",pathDocuments]];
    if ([[temp allKeys]containsObject:@"data"]&&[[temp allKeys]containsObject:@"amount"]) {
        PictureSumNumber=[[temp objectForKey:@"amount"]intValue];
        imageDictionary=[temp objectForKey:@"data"];
        
    }
    else
    {
        PictureSumNumber=0;
        imageDictionary=[[NSMutableDictionary alloc]init];
        NSMutableDictionary *temp=[[NSMutableDictionary alloc]init];
        [temp writeToFile:[NSString stringWithFormat:@"%@/picMatch.plist",pathDocuments] atomically:YES];
    }

    
   
    if ([UIImagePNGRepresentation(image) writeToFile:[NSString stringWithFormat:@"%@/img/%d",pathDocuments,++PictureSumNumber] atomically:YES])
    {
        NSLog(@"picture succeed");
        NSMutableDictionary *picDetail=[[NSMutableDictionary alloc]init];
        [picDetail setValue:[NSString stringWithFormat:@"%@/img/%d",pathDocuments,PictureSumNumber] forKey:[ NSString stringWithFormat:@"%@",@"Path"]];
        [picDetail setValue:[NSString stringWithString:urlAddress] forKey:@"URL"];
      //  [imageDictionary setValue:[NSString stringWithFormat:@"%@/img/%d",pathDocuments,PictureSumNumber] forKey:detail];
        [imageDictionary setObject:picDetail forKey:[NSString stringWithFormat:@"%@",detail]];
        
        NSMutableDictionary *temp=[[NSMutableDictionary alloc]init];
        [temp setValue:imageDictionary forKey:@"data"];
        [temp setValue:[NSNumber numberWithInt: PictureSumNumber] forKey:@"amount"];
        if([temp writeToFile:[NSString stringWithFormat:@"%@/picMatch.plist",pathDocuments] atomically:YES])
        {NSLog(@"picMatch.plist succeed");}
    }
    else NSLog(@"fail");
    

    
    

}


-(NSDictionary*) readNSDictionary:(NSString *)FileName :(NSString *)options
{
    [self NessaryDataInit];
    NSDictionary *temp=[[NSDictionary alloc]initWithContentsOfFile:[NSString stringWithFormat:@"%@/%@",pathDocuments,FileName]];
    if (options) {
        NSDictionary *temp2=temp;
        temp=[temp2 objectForKey:options];
    }
    
    if (temp) {
        return temp;
    }else
        return nil;
}



-(BOOL) updateDataToFile:(NSObject *)data forkey:(NSString *)key FileName:(NSString *)name Path:(NSArray*) optionals
{
    [self NessaryDataInit];
    NSMutableDictionary *temp=[[NSMutableDictionary alloc]initWithContentsOfFile:[NSString stringWithFormat:@"%@/%@",pathDocuments,name]];
    if (temp) {
    }
    else temp=[[NSMutableDictionary alloc]init];
   
    NSMutableDictionary *father=[[NSMutableDictionary alloc]initWithDictionary:temp];
    if ([optionals count]>0) {
//        NSMutableDictionary *father=[[NSMutableDictionary alloc]initWithDictionary:temp];
        NSMutableDictionary *sub;
        for (NSString *pathName in optionals)
        {
            sub=[father objectForKey:pathName];
            father=sub;
        }
    }
//    NSString *thempPath=[]
    [father setObject:data forKey:key];
    
    
    if([temp writeToFile:[NSString stringWithFormat:@"%@/%@",pathDocuments,name] atomically:YES])
    {NSLog(@"AddDataToFile Succeed");}
    else{}
    
    


    
}



-(UIImage*)captureView:(UIView *)theView

{
    CGRect rect = theView.frame;
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    [theView.layer renderInContext:context];
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    
    return img;
    
}

-(BOOL)checkPicById:(NSString *)idnumber DataBaseFileName:(NSString *)filename
{
    return 0;
}

-(BOOL)checkPicByPath:(NSString *)path DataBaseFileName:(NSString *)filename
{
    return 0;
}

-(UIImage*)LoadPicById:(NSString *)idnumber DataBaseFileName:(NSString *)filename
{
    UIImage *load=[[UIImage alloc]init];
    NSDictionary *temp=[[NSDictionary alloc]initWithDictionary:[self readNSDictionary:filename :nil]];
    if (temp) {
        if ([[temp allKeys]containsObject:@"data"]) {
            NSDictionary *temp2=[temp objectForKey:@"data"];
            if ([[temp2 allKeys]containsObject:[NSString stringWithFormat:@"%@",idnumber]]) {
                NSDictionary *temp3=[temp2 objectForKey:[NSString stringWithFormat:@"%@", idnumber]];
                NSString *localpath=[NSString stringWithFormat:@"%@",[temp3 objectForKey:@"Path"]];
                load=[[UIImage alloc]initWithContentsOfFile:localpath];
                return load;
            }
        }
    }
    
    return  nil;
}


-(BOOL)downloadPicToFile:(NSString *)filename IDNumber:(NSString *)idnumber URL:(NSString *)url
{
    

    return 0;
}

-(UIImage*)LoadPicByPath:(NSString *)path DataBaseFileName:(NSString *)filename
{
    return  nil;
}





@end
