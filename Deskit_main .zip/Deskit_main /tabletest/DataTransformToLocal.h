//
//  DataTransformToLocal.h
//  Deskit_beta
//
//  Created by Sway on 13-7-25.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataTransformToLocal : NSObject

@end
