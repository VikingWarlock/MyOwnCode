//
//  main.m
//  tabletest
//
//  Created by vikingwarlock on 13-6-14.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DeskItAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DeskItAppDelegate class]));
    }
}
