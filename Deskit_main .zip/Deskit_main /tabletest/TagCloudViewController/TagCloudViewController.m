//
//  ViewController.m
//  TagCloud
//
//  Created by sjy on 13-8-5.
//  Copyright (c) 2013年 sjy. All rights reserved.
//

#import "TagCloudViewController.h"
#import "TagButton.h"
#import "SearchViewController.h"
#import "constant.h"
#import "JsonDataFormatting.h"
#import "Subscribe_DetailViewController.h"
#import "Transition.h"
#define TagSpace 1 //标签之间的间隔

//1 可围绕的标签
int minTag =0;
int maxTag =0;


//位号使用
typedef struct{
    BOOL used[8];
}eightBOOLStruct;

eightBOOLStruct PositionBOOL[60];
eightBOOLStruct PositionPoint;


//集合2 所有已添加到view里的区域
int MaxRect=0;
CGRect AddedRectArray[60];


@interface TagCloudViewController (){
    BOOL isAddToView;
//    ASIFormDataRequest *Request;
    NSArray *category,*tagArray;//四个大标签和其他小标签
    NSArray *categoryIdArray,*categoryNameArray,*tagIdArray,*tagCategoryIdArray,*tagNameArray;
    NSArray *ButtonArray;
    
}

@end

@implementation TagCloudViewController
@synthesize lastview;


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self typeStructInit];
    
	// Do any additional setup after loading the view, typically from a nib.
    UIImageView *imag=[[UIImageView alloc]initWithFrame:CGRectMake(12, 12, 20, 20)];
    imag.image=[UIImage imageNamed:@"icon-back-blue"];
    [self.view addSubview:imag];
    UIImageView *image=[[UIImageView alloc]initWithFrame:CGRectMake(290, 12, 20, 20)];
    image.image=[UIImage imageNamed:@"icon-search-blue"];
    [self.view addSubview:image];
    
    
    gesture=[[UIPanGestureRecognizer alloc]init];
    [gesture addTarget:self action:@selector(backGuesture:)];
    [self.view addGestureRecognizer:gesture];
    
    CGRect frame=CGRectMake(-lastview.size.width, 0, lastview.size.width, lastview.size.height);
    lastView=[[UIImageView alloc]initWithImage:lastview];
    [lastView setFrame:frame];
    [self.view addSubview:lastView];
    

    
    
    ASIFormDataRequest *Request=[[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:[basePath stringByAppendingString:TagCloudUrl]]];
    [Request setTimeOutSeconds:1.5];
    [Request startSynchronous];
    NSInteger statusCode=[Request responseStatusCode];
    
    
    NSArray *nameArray;
    
    if (statusCode!=200)[JsonDataFormatting NetworkingError:@"连接失败，请重试"];
    else {
        NSData *data = [Request responseData];
        NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];

        id err = [dictionary objectForKey:@"err"];
        if (![err isKindOfClass:[NSNull class]]){
            [JsonDataFormatting NetworkingError:@"服务器数据出错"];
            
        }
        else {
            category=[[dictionary objectForKey:@"data"] objectForKey:@"category"];
            tagArray=[[dictionary objectForKey:@"data"] objectForKey:@"tag"];
            NSMutableArray *mutableArray = [[NSMutableArray alloc]init];
            NSMutableArray *nameMutableArray = [[NSMutableArray alloc]init];
            for (NSInteger i=0;i<[category count];i++){
                NSDictionary *dictionary = [category objectAtIndex:i];
                TagButton *b = (TagButton*)[self.view viewWithTag:i+1];
                b.Id=[[dictionary objectForKey:@"id"] intValue];
                b.Name=[dictionary objectForKey:@"name"];
                [b setTitle:b.Name forState:UIControlStateNormal];
                [b setTitle:b.Name forState:UIControlStateHighlighted];
                
            }
            for (NSDictionary *item in tagArray){
                TagButton *b = [[TagButton alloc]init];
                b.Id=[[item objectForKey:@"id"] intValue];
                b.CategoryId=[[item objectForKey:@"category_id"] intValue];
                b.Name=[item objectForKey:@"name"];
                [mutableArray addObject:b];
                [nameMutableArray addObject:b.Name];
            }
            ButtonArray=mutableArray;
            nameArray=nameMutableArray;
        }
    }
    
//    NSArray *array=[[NSArray alloc]initWithObjects:@"新闻中心",@"学校要闻",@"综合新闻",@"学院动态",@"名师苑",@"银杏海",@"校园观察",@"媒体成电",@"哈哈哈哈哈哈哈",@"首都发生地方",@"啊啊啊",@"的",@"都是发",@"w而w",@"阿迪法",@"小cv政府",@"阿迪发生大发",@"2423分w额时代",@"阿什顿发生地方", nil];
    //        NSArray *array=[[NSArray alloc]initWithObjects:@"新闻中心",@"学校要闻",@"综合新闻",@"学院动态",nil];
    [self tagCloud:nameArray];
    
    
}

//-(void)viewDidDisappear:(BOOL)animated{
//    if (Request){
//        [Request clearDelegatesAndCancel];
//        Request=nil;
//    }
//}


- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestufreRecognizer
{
    
	return gesture.state == UIGestureRecognizerStatePossible;
}

-(void)backGuesture:(UIPanGestureRecognizer*) sender
{
    switch (sender.state) {
        case UIGestureRecognizerStatePossible:
        {
            break;
        }
        case UIGestureRecognizerStateBegan:
        {
            FirstPosition=[sender locationInView:self.view];
            break;
        }
        case UIGestureRecognizerStateChanged:
        {
            CGPoint translation=[sender translationInView:self.view];
            if (abs((int)translation.y)*3 < translation.x)
            {
                CGPoint NowPosition=[sender locationInView:self.view];
                CGRect frame=self.view.frame;
                float Xmove=(NowPosition.x-FirstPosition.x);
                frame.origin.x+=Xmove;
                [self.view setFrame:frame];
            }
            break;
        }
        case UIGestureRecognizerStateEnded:
        {
            NSLog(@"lastview %f,%f",lastView.frame.origin.x,lastView.frame.size.width);
            if (self.view.frame.origin.x>back_width) {
                [UIView animateWithDuration:0.3f
                                      delay:0
                                    options:UIViewAnimationOptionCurveLinear
                                 animations:^{
                                     CGRect frame = self.view.frame;
                                     frame.origin.x = 320;
                                     [self.view setFrame:frame];
                                     
                                 }
                                 completion:^(BOOL finished) {
                                     [self.navigationController popViewControllerAnimated:NO];
                                 }
                 ];
            }
            else
            {
                [UIView animateWithDuration:0.3f
                                      delay:0
                                    options:UIViewAnimationOptionCurveLinear
                                 animations:^{
                                     CGRect frame = self.view.frame;
                                     frame.origin.x = 0;
                                     [self.view setFrame:frame];
                                     
                                 }
                                 completion:^(BOOL finished) {
                                     
                                 }
                 
                 ];
            }
            break;
        }
        case UIGestureRecognizerStateCancelled:
        {
            break;
        }
            
        default:
            break;
    }
    
}

-(void)typeStructInit{
    
    //初始化NO
    for (NSInteger i=0;i<60;i++){
        for (NSInteger j=0;j<8;j++){
            PositionBOOL[i].used[j]=NO;
        }
    }
    
    //下标初始化
    minTag=1;
    maxTag=4;
    MaxRect=4;
    for (NSInteger i=0;i<MaxRect;i++){
        AddedRectArray[i]=[self.view viewWithTag:i+1].frame;
    }
}

//返回围绕标签的制定位号的左上角坐标
-(CGPoint)getTargetPoint:(NSInteger)PositionNum TagRect:(CGRect)TagRect Rect:(CGRect)TargetRect{
    CGPoint result;
    CGFloat width=TagRect.size.width;
    CGFloat height = TagRect.size.height;
    CGFloat x=TagRect.origin.x;
    CGFloat y = TagRect.origin.y;
    switch (PositionNum) {
            //暂时废掉5、7、6、8号位,用1号位代码代替
        case 1:
            result.x=x+width+TagSpace;
            result.y=y+height/2;
            break;
        case 2:
            result.x=x+width/2;
            result.y=y+height+TagSpace;
            break;
        case 3:
            result.x=x+width/2;
            result.y=y-TagSpace-TargetRect.size.height;
            break;
        case 4:
            result.x=x-TagSpace-TargetRect.size.width;
            result.y=y+height/2;
            break;
        case 5:
            
//            result.x=x+width+TagSpace;
//            result.y=y;
            result.x=x+width+TagSpace;
            result.y=y+height/2;
            break;
        case 6:
//            result.x=x;
//            result.y=y+height+TagSpace;
            result.x=x+width+TagSpace;
            result.y=y+height/2;
            break;
        case 7:
//            result.x=x;
//            result.y=y-TagSpace-TargetRect.size.height;
            result.x=x+width+TagSpace;
            result.y=y+height/2;
            break;
        case 8:
//            result.x=x-TagSpace-TargetRect.size.width;
//            result.y=y;
            result.x=x+width+TagSpace;
            result.y=y+height/2;
        default:
            break;
    }
    
    return result;
    
}


//判断区域是否覆盖
-(BOOL)isPositionNumCover:(NSInteger)positionNum TagRect:(CGRect)tagRect Rect:(CGRect)rect{
    //    CGPoint TargetOrigin = [self getTargetPoint:positionNum TagRect:tagRect Rect:rect];
    //    rect.origin.x=TargetOrigin.x;
    //    rect.origin.y=TargetOrigin.y;
    for(NSInteger i=0;i<MaxRect;i++){
        CGPoint Aorigin=AddedRectArray[i].origin;
        CGSize Asize = AddedRectArray[i].size;
        CGPoint Borigin=rect.origin;
        CGSize Bsize = rect.size;
        
        if (rect.origin.x<0||(rect.origin.x+rect.size.width>[UIScreen mainScreen].bounds.size.width))return YES;
        if (rect.origin.y<=44||(rect.origin.y+rect.size.height>[UIScreen mainScreen].bounds.size.height))return YES;
        
//        if (CGRectContainsPoint(AddedRectArray[i], Borigin))return YES;
//        if (CGRectContainsPoint(AddedRectArray[i], CGPointMake(Borigin.x+Bsize.width, Borigin.y)))return YES;
//        if (CGRectContainsPoint(AddedRectArray[i], CGPointMake(Borigin.x+Bsize.width, Borigin.y+Bsize.height)))return YES;
//        if (CGRectContainsPoint(AddedRectArray[i], CGPointMake(Borigin.x, Borigin.y+Bsize.height)))return YES;
        
        if ([self RectContainPoint:AddedRectArray[i] Point:Borigin])return YES;
        if ([self RectContainPoint:AddedRectArray[i] Point:CGPointMake(Borigin.x+Bsize.width, Borigin.y)])return YES;
        if ([self RectContainPoint:AddedRectArray[i] Point:CGPointMake(Borigin.x+Bsize.width, Borigin.y+Bsize.height)])return YES;
        if ([self RectContainPoint:AddedRectArray[i] Point:CGPointMake(Borigin.x, Borigin.y+Bsize.height)])return YES;
        
        if ([self RectContainPoint:rect Point:Aorigin])return YES;
        if ([self RectContainPoint:rect Point:CGPointMake(Aorigin.x+Asize.width, Aorigin.y)])return YES;
        if ([self RectContainPoint:rect Point:CGPointMake(Aorigin.x+Asize.width, Aorigin.y+Asize.height)])return YES;
        if ([self RectContainPoint:rect Point:CGPointMake(Aorigin.x, Aorigin.y+Asize.height)])return YES;
        
        
        
//        if (CGRectContainsPoint(rect, Aorigin))return YES;
//        if (CGRectContainsPoint(rect, CGPointMake(Aorigin.x+Asize.width, Aorigin.y)))return YES;
//        if (CGRectContainsPoint(rect, CGPointMake(Aorigin.x+Asize.width, Aorigin.y+Asize.height)))return YES;
//        if (CGRectContainsPoint(rect, CGPointMake(Aorigin.x, Aorigin.y+Asize.height)))return YES;
        
        
    }
    return NO;
}


-(BOOL)RectContainPoint:(CGRect)rect Point:(CGPoint)point{
    if ((point.x>=rect.origin.x)&&(point.x<=(rect.origin.x+rect.size.width))&&(point.y>=rect.origin.y)&&(point.y<=(rect.size.height+rect.origin.y)))return YES;
    return NO;
}

//新元素推入集合2
-(void)pushSet2:(TagButton*)button{
    AddedRectArray[MaxRect++]=button.frame;
}

//-(void)setTagButtonFrame:(TagButton*)tag PositionNum:(NSInteger)num{
//
//}

-(void)tagCloud:(NSArray*)StringArray{
    //新建按钮
    for (NSInteger index=0;index<[StringArray count];index++){
        isAddToView=NO;
        TagButton *newButton =[ButtonArray objectAtIndex:index];
        NSString *buttonName = [StringArray objectAtIndex:index];
        CGFloat fontSize;
        if (index%2==0)fontSize=18;
        else if (index%3==0)fontSize=15;
        else fontSize=14;
        
        CGSize buttonSize = [self measureLabelSize:buttonName FontSize:fontSize];
        [newButton setFrame:CGRectMake(newButton.frame.origin.x, newButton.frame.origin.y, buttonSize.width, buttonSize.height)];
        [newButton setTitle:buttonName forState:UIControlStateNormal];
        [newButton setTitle:buttonName forState:UIControlStateHighlighted];
        [newButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [newButton.titleLabel setFont:[UIFont systemFontOfSize:fontSize]];
        
        for (NSInteger i=minTag;i<=maxTag;i++){
            
            TagButton *b = (TagButton*)[self.view viewWithTag:i];
            PositionPoint=PositionBOOL[i];
            
            for (NSInteger j=0;j<8;j++){
                if (!PositionBOOL[i].used[j]){//位号未被使用
                    
                    
                    //                    //根据当前标签和位号处理按钮的frame
                    //                    [self setTagButtonFrame:b PositionNum:j];
                    CGPoint TargetPoint = [self getTargetPoint:j+1 TagRect:b.frame Rect:newButton.frame];
                    [newButton setFrame:CGRectMake(TargetPoint.x, TargetPoint.y, newButton.frame.size.width, newButton.frame.size.height)];
                    
                    if (![self isPositionNumCover:j+1 TagRect:b.frame Rect:newButton.frame]){//@判断该位号下放下按钮是否造成覆盖
                        
                        //设置button的rect
                        
                        
                        //@集合1处理
                        maxTag++;
                        //按钮的tag设为maxTag
                        newButton.tag=maxTag;
                        //当前位号被使用
                        PositionBOOL[i].used[j]=YES;
                        //@集合2处理
                        [self pushSet2:newButton];
                        //@view处理
                        [self.view addSubview:newButton];
                        
                        //处理按钮点击事件
                        [newButton addTarget:self action:@selector(TagButtonPress:) forControlEvents:UIControlEventTouchUpInside];
                        isAddToView=YES;
                        break;
                    }
                }
            }
            if (isAddToView)break;
            //@如果1-8号都被使用
            minTag++;
            
        }
    }
}


-(IBAction)TagButtonPress2:(TagButton*)sender
{
    NSLog(@"%d",sender.tag);
    TagCloud_Detail *controller = [[TagCloud_Detail alloc]init];
    [controller initStyle:NO :sender.Name :0 :[NSString stringWithFormat:@"%d",sender.tag] :@"Tag Clouds Cate"];
    ImageLocalized *file=[[ImageLocalized alloc]init];
    UIImage *thisView=[file captureView:self.view];
    controller.lastview=thisView;

    [self.navigationController pushViewController:controller animated:YES];


}


-(void)TagButtonPress:(TagButton*)sender{
    //TagButtonPress 是除了"新闻"，“活动”，“通知”，“生活”的其余按钮响应事件
    //每个按钮都已经设置好id category_id 和name 如    sender.Id sender.CategoryId sender.Name
    //响应事件是直接跳转到Subscirbe_DetailViewController
    
    
    //"新闻"，“活动”，“通知”，“生活”4个按钮也是TagButton，他们只有id和name
    //这4个按钮跳转界面是SubscribeListViewController
    //这4个按钮可以用viewWithTag来获得按钮地址tag为1-4
    
    
    NSLog(@"%d",sender.tag);
    NSLog(@"%d",sender.Id);
//ListDetailUrl
    
     TagCloud_Detail *controller = [[TagCloud_Detail alloc]init];
    
    if (sender.Id==0) {
        
 //   [controller ]
    //  [controller initStyle:NO :sender.Name :0 :<#(NSString *)#> :@"tag clouds"]
        
        
    
        
    }else
        
        if (sender.Id>0) {
              [controller initStyle:NO :sender.Name :0 :[NSString stringWithFormat:@"%d",sender.Id] :@"tag clouds"];
        
        }
    ImageLocalized *file=[[ImageLocalized alloc]init];
    UIImage *thisView=[file captureView:self.view];
    controller.lastview=thisView;

    [self.navigationController pushViewController:controller animated:YES];

    
/*
 
    ASIFormDataRequest *request = [[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:[basePath stringByAppendingString:TagDetailUrl]]];
    [request setPostValue:[NSNumber numberWithInt:sender.Id] forKey:@"id"];
    [request setTimeOutSeconds:2];
    [request startSynchronous];
    if ([request responseStatusCode]!=200){
        NSLog(@"%d",[request responseStatusCode]);
        [JsonDataFormatting NetworkingError:@"链接失败"];
    }
    else {
        NSData *data = [request responseData];
        NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        id err= [dictionary objectForKey:@"err"];
        
        if (![err isKindOfClass:[NSNull class]]){
            //详细要判断未登陆
            [JsonDataFormatting NetworkingError:@"链接失败"];
        }else {
            NSLog(@"%@",dictionary);
            NSDictionary *data = [dictionary objectForKey:@"data"];
            BOOL is_subscribe = [[data objectForKey:@"is_subscribe"] boolValue];
            NSString *name = [data objectForKey:@"name"];
            NSString *category_id = [data objectForKey:@"category_id"];
            
//            -(void)initStyle:(BOOL)subscribe :(NSString *)title :(int)numbers :(NSString *)cata_id :(NSString*) from
            [controller initStyle:is_subscribe :name :0 :category_id :@"TagCloudViewController"];
        }
        
    }
*/ 
//    controller.listData=array;
    
}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
#pragma mark 计算标签长度
-(CGSize)measureLabelSize:(NSString*)myString FontSize:(float)size{
    CGSize maximumSize = CGSizeMake(300, 9999);
    //    UIFont *myFont = [UIFont fontWithName:@"Helvetica" size:14];
    UIFont *myFont =[UIFont systemFontOfSize:size];
    CGSize myStringSize = [myString sizeWithFont:myFont
                               constrainedToSize:maximumSize
                                   lineBreakMode:NSLineBreakByWordWrapping];
    
    return CGSizeMake(myStringSize.width+4, myStringSize.height+2);
}
- (IBAction)pushSearch:(UIButton *)sender {
    [Transition pushViewControllerFormBotton:self ViewController:[[SearchViewController alloc]init]];
}
- (IBAction)popBack:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}




@end
