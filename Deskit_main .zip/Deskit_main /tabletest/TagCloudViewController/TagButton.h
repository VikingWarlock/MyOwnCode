//
//  TagButton.h
//  TagCloud
//
//  Created by Sway on 13-8-14.
//  Copyright (c) 2013年 sjy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TagButton : UIButton
@property (nonatomic) NSInteger Id;
@property(nonatomic)NSInteger CategoryId;
@property (nonatomic)NSString *Name;
@end
