//
//  TagButton.m
//  TagCloud
//
//  Created by Sway on 13-8-14.
//  Copyright (c) 2013年 sjy. All rights reserved.
//

#import "TagButton.h"

@implementation TagButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(id)init{
    self =[super init];
    if (self){
        [self setBackgroundImage:[UIImage imageNamed:@"button-add-light-solid.png"] forState:UIControlStateHighlighted];
        self.Id=0;
        self.CategoryId=0;
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
