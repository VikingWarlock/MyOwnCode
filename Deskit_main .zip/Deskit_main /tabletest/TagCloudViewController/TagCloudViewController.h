//
//  ViewController.h
//  TagCloud
//
//  Created by sjy on 13-8-5.
//  Copyright (c) 2013年 sjy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequestDelegate.h"
#import "TagCloud_Detail.h"
//#import "SubscribeListViewController.h"
@interface TagCloudViewController : UIViewController
{
    UIPanGestureRecognizer *gesture;
    CGPoint FirstPosition;
    UIImageView *lastView;
    UIImage *lastview;
}
@property UIImage *lastview;


@end
