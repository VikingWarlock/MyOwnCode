//
//  CellSelectedButton.h
//  Deskit_beta
//
//  Created by Sway on 13-6-22.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

//需要再TableView的DataSource里设置好它的CurrentCellRow以便让按钮知道当前是哪一行
//设置代理给视图控制器，以便处理好按钮的信息响应



@class  CellSelectedButton;
#import "SelectedButton.h"
@protocol CellSelectedButtonDelegate <NSObject>
@optional
//用于定位按钮点击时处于的Cell行
-(void)SelectedButton:(CellSelectedButton*)cellSelectedButton CellIndexRow:(NSInteger)Row Message:(NSInteger)message;
//按钮点击代理，会进行选择状态和为选择状态的切换
-(void)buttonPress:(CellSelectedButton*)button;
@end

@interface CellSelectedButton : SelectedButton{

}

@property(nonatomic)NSInteger Message;
@property (nonatomic)NSInteger CurrentCellRow;
@property (nonatomic,assign) id<CellSelectedButtonDelegate> CellSelectedDelegate;
//@property(nonatomic)id<CellSelectedButtonDelegate>delegate;

@end