//
//  JsonDataFormatting.m
//  Test
//
//  Created by Sway on 13-7-19.
//  Copyright (c) 2013年 Sway. All rights reserved.
//

#import "JsonDataFormatting.h"






@implementation JsonDataFormatting




-(id)initWithJsonData:(NSData*)response{
    self=[super init];
    if (self){
        [self initData:response];
    }
    return self;
}

//网络错误弹出的警示
+(void)NetworkingError
{
    UIAlertView *alert;
    alert=[[UIAlertView alloc]initWithTitle:@"网络错误" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
    [alert show];
}

+(void)NetworkingError:(NSString*)errorMsg{
    UIAlertView *alert;
    alert=[[UIAlertView alloc]initWithTitle:errorMsg message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
    [alert show];
}



//将服务器回传的数据解析
-(void)initData:(NSData*)response{
    self.state=0;
    NSError *error;
    NSDictionary *jsonDictionary = [NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableLeaves error:&error];
    if (error!=NULL){//连接传过来的数据无法解析
        self.state=serverDataError;
        
        //[modify@卓越：从逻辑考虑，本类用于解析数据结构返回数据状态，所以错误提示应该在处理完数据获取数据状态以后，所以]
        //错误弹出框移到Delegate里
        
        
        return;
    }
    if([jsonDictionary count]==0){//服务器没有传过来任何东西
        self.state=responseNoting;
        
        
        return;
    }
    
    
    
    NSDictionary *data = [jsonDictionary objectForKey:@"data"];
    id err=[jsonDictionary objectForKey:@"err"];
    NSString *err_local=[jsonDictionary objectForKey:@"err_local"];
    if (data==nil||err==nil||err_local==nil){//服务器传来的json结构与约定的不同
        self.state=dataStructError;
        
        return;
    }
    
    if (![err isMemberOfClass:[NSNull class]]){//返回数据中包含错误信息

        
        
        if ([err isEqualToString:@"please login"]){
            self.state=NoLogin;
            }
        else self.state=dataError;
        [self setErr:(NSString*)err];//如果非空，那么就是字符串了
        [self setErr_local:err_local];
        return;
    }
    
    
    
    
    if (![data isKindOfClass:[NSDictionary class]]){//结构错误
        //在有些情况下，data返回的直接是数组而不是字典
        if (data==nil){
            self.state=dataStructError;
            
            return;
        }
        if (![data isMemberOfClass:[NSNull class]]){
            NSArray *dataArray=(NSArray*)data;
            [self setData:dataArray];
            [self setErr:NULL];
            [self setErr_local:err_local];
            self.state=0;
            return;
        }
        
    }
    
    
    

    
    [self setData:[data objectForKey:@"data"]];
    [self setErr:NULL];
    [self setErr_local:err_local];
    self.state=0;
    //结果正确
    
    
}

@end
