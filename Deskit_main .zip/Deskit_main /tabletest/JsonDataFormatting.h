//
//  JsonDataFormatting.h
//  Test
//
//  Created by Sway on 13-7-19.
//  Copyright (c) 2013年 Sway. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "constant.h"
@interface JsonDataFormatting : NSObject
@property (nonatomic,getter = getData) NSArray* Data;
@property (nonatomic,getter = getErr) NSString *Err;
@property (nonatomic,getter = getErr_local) NSString *Err_local;
-(id)initWithJsonData:(NSData*)response;
+(void)NetworkingError;
+(void)NetworkingError:(NSString*)errorMsg;
@property (nonatomic) NSInteger state;
@end
