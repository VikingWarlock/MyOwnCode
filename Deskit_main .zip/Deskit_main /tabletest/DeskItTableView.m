//
//  DeskItTableView.m
//  tabletest_mod1
//
//  Created by vikingwarlock on 13-6-19.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import "DeskItTableView.h"
#import "DeskItCell_settings.h"
@interface DeskItTableView ()

@end

@implementation DeskItTableView

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//TableView Parts
-(NSInteger)numberOfSectionsInTableView:(UITableView *) tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    //   NSLog(@"%d",[[DataSource allKeys]count]);
    return [[DataSource allKeys]count];
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier=@"MyCell";
    NSArray *keys = [[DataSource allKeys]
					 sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
	NSString *key = [keys objectAtIndex:[indexPath row]];
    NSDictionary *DataSource_key=[DataSource objectForKey:key];
    DeskItCell_settings *cell=(DeskItCell_settings *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell==nil){
        [[NSBundle mainBundle]loadNibNamed:@"DeskItCell_settings" owner:self options:nil];
        cell=CustomTableViewCell;
        
        //     cell=[[DeskItCell_settings alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        self.CustomTableViewCell=nil;
        
    }
    
    [[cell ShareNum] setText:[DataSource_key objectForKey:@"ShareNum"]];
    [[cell AdmireNum] setText:[DataSource_key objectForKey:@"AdmireNum"]];
    [[cell MainText] setText:[DataSource_key objectForKey:@"MainText"]];
    [[cell FrontPicture]setImage:[UIImage imageNamed:[DataSource_key objectForKey:@"FrontPicture"]]];
    cell.delegate=self;
    
    /*
     
     if (cell.SAshowed) {
     if (SAshowed)
     {
     [lastMoved goback];
     NSLog(@"changed");
     }
     else
     {
     lastMoved=cell;
     SAshowed=YES;
     }
     }
     
     */
    
    return cell;
    
}

-(void)tableView:(UITableView *) tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath*)indexPath
{
    
    
}



/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     */
}

@end
