//
//  MyUIPageControl.h
//  SGFocusImageFrame
//
//  Created by Sway on 13-6-12.
//  Copyright (c) 2013年 Shane Gao. All rights reserved.
// 这个文件夹里的文件时用来设置UIPageControl小图标的

#import <UIKit/UIKit.h>

@interface MyUIPageControl : UIPageControl
@property (strong, nonatomic) UIImage *normalImage;
@property (strong, nonatomic) UIImage *highlightedImage;

@end
