//
//  DeskItCell_settings.m
//  tabletest
//
//  Created by vikingwarlock on 13-6-16.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import "DeskItCell_settings.h"
#import "DeskItViewController.h"
#import "DeskItAppDelegate.h"


#define Cell_icon_width 130

@interface DeskItCell_settings(){
    ASIFormDataRequest *ImageRequest;
    __weak NSMutableDictionary *imageArray;
    NSInteger currentRow;
}

@end

@implementation DeskItCell_settings

@synthesize AdmireButton;
@synthesize AdmireNum;
//@synthesize UnderButton;
@synthesize ShareButton;
@synthesize ShareNum;

@synthesize MainText;
@synthesize FrontPicture;
@synthesize Title;

@synthesize SAshowed;

@synthesize TableViewCellGesture;
@synthesize currentEssayId;
@synthesize currentRow;


#pragma 孙嘉玉把cell写这
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self configureCell];
        //用代码实现还是用xib实现请自行衡量
        
        
        //不管是用代码还是用xib都要用头文件里的变量名，代码的话最直接使用。
        //xib的话请添加IBOutlet
        
        
        //这句话是加载xib用的
        self=[[[NSBundle mainBundle]loadNibNamed:@"DeskItCell_settings" owner:self options:NULL]lastObject];
        
        
        [self.AdmireButton addTarget:self action:@selector(AdmirePress:) forControlEvents:UIControlEventTouchUpInside];
        [self.AdmireButton setSelectedImage:[UIImage imageNamed:@"finger_selected.png"]];
        [self.AdmireButton setNormalImage:[UIImage imageNamed:@"finger_normal.png"]];
        [self.AdmireButton InitForPress];

        
        
        [self.ShareButton addTarget:self action:@selector(SharePress:) forControlEvents:UIControlEventTouchUpInside];

        [self.ShareButton setNormalImage:[UIImage imageNamed:@"star.png"]];
        [self.ShareButton setSelectedImage:[UIImage imageNamed:@"star_selected.png"]];
        [self.ShareButton setImage:[UIImage imageNamed:@"TabBarStar.png"] forState:UIControlStateHighlighted];
        [self.ShareButton InitForPress];
        self.ContainImage=NO;
        //        [self setBackgroundColor:[UIColor colorWithRed:239.0/255.0 green:239.0/255.0 blue:239.0/255.0 alpha:1]];
        
    }
    return self;
}





-(void)setContainImageViewState:(BOOL)isContainImage{
    if(isContainImage){
        [Title setFrame:CGRectMake(142, 12, 241, 16)];
        [MainText setFrame:CGRectMake(142, 30, 241, 31)];
        [FrontPicture setHidden:NO];
        self.ContainImage=YES;
    }
    else{
        [Title setFrame:CGRectMake(142,12,292,16)];
        [MainText setFrame:CGRectMake(142,30,292,31)];
        [FrontPicture setHidden:YES];
        self.ContainImage=NO;
    }
}

-(void)setFrame:(CGRect)frame{
    frame.origin.x-=130;
    frame.size.width=450;
    [super setFrame:frame];
}


-(void)awakeFromNib
{
    [super awakeFromNib];
    [self configureCell];
}


#pragma cell往回滑
-(void) goback
{
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3f];
    [UIView setAnimationCurve:UIViewAnimationCurveLinear];
    
    self.frame = CGRectMake(0, self.frame.origin.y, 320, self.frame.size.height);
    self.SAshowed=NO;
    [UIView commitAnimations];
    [self sentGoBackMessage];
}



//-(void)SentCellAddress
//{
// //   DeskItCell_settings *cell=self;
//
//    DeskItViewController *app=(DeskItViewController *) [UIApplication sharedApplication];
//
//
//    app.NowMove=self;
//    [app MoveCellAddition];
//
//
//}


#pragma mark cell滑回后会调用这个函数
-(void)sentGoBackMessage{
    if ([self.delegate respondsToSelector:@selector(DeskItCell_settingsGoback:)]){
        [self.delegate DeskItCell_settingsGoback:self];
    }
}



#pragma mark cell滑出
-(void)SentCellAddress{
    if([self.delegate respondsToSelector:@selector(DeskItCell_settings:)]){
        [self.delegate DeskItCell_settings:self];
    }
}


- (void) panGestureAction:(UIPanGestureRecognizer *)sender
{
    
    CGPoint translatedPoint = [sender translationInView:self];
    
 //   NSLog(@"%f,%f",translatedPoint.x,translatedPoint.y);
    if (!shouldBegin) {
        shouldBegin=[self gestureRecognizerShouldBegin:sender];
    }
    
    if (shouldBegin) {
        
        
        switch (sender.state)
        {
            case UIGestureRecognizerStatePossible:
                break;
            case UIGestureRecognizerStateBegan:
                beginPoint=[sender locationInView:self];
                break;
            case UIGestureRecognizerStateChanged:
                if(translatedPoint.x>30 && !SAshowed &&translatedPoint.x<160)
                {
                    direction=1;
                    [UIView beginAnimations:nil context:NULL];
                    [UIView setAnimationDuration:0.3f];
                    [UIView setAnimationCurve:UIViewAnimationCurveLinear];
                    
                    self.frame = CGRectMake(Cell_icon_width, self.frame.origin.y, 320, self.frame.size.height);
                    SAshowed=YES;
                    showedChange=YES;
                    if(direction==1)
                        [self SentCellAddress];
                    
                } else
                    
                    if(translatedPoint.x<-30 && SAshowed)
                    {
                        direction=-1;
                        [UIView beginAnimations:nil context:NULL];
                        [UIView setAnimationDuration:0.3f];
                        [UIView setAnimationCurve:UIViewAnimationCurveLinear];
                        
                        self.frame = CGRectMake(0, self.frame.origin.y, 320, self.frame.size.height);
                        SAshowed=NO;
                        showedChange=YES;
                        if(direction==1)
                            [self SentCellAddress];
                        [self sentGoBackMessage];
                        
                    }
                
                break;
            case UIGestureRecognizerStateEnded:
                //  if (SelfView.center.x>beginPoint.x)
                if(showedChange)
                {
                    [UIView commitAnimations];
                   
                    direction=0;
                    showedChange=NO;
                }
                shouldBegin=NO;
                
                break;
                
            case UIGestureRecognizerStateCancelled:
                break;
            case UIGestureRecognizerStateFailed:
                break;
                
                
                
        }
        
        
    }//should begin
}


//+(void)changed:(id)sender
//{
//
//
//
//}




-(void) configureCell
{
    SAshowed=NO;
    showedChange=NO;
    viewchange=NO;
    shouldBegin=NO;
    
    TableViewCellGesture=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panGestureAction:)];
    TableViewCellGesture.delegate=self;
    
    [self addGestureRecognizer:TableViewCellGesture];
    
    /*
     Title.frame=CGRectMake(12, 7, 247+icon_width, 25);
     Title.font=[UIFont boldSystemFontOfSize:15];
     
     
     MainText.frame=CGRectMake(12, 40, 247+icon_width, 49);;
     MainText.font=[UIFont fontWithName:@"times new roman" size:12];
     
     
     FrontPicture.frame=CGRectMake(260, 12, 49+icon_width, 49);
     
     */
    
}


- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    if (gestureRecognizer==TableViewCellGesture) {
        
        
        
        CGPoint translation = [(UIPanGestureRecognizer*)gestureRecognizer translationInView:self];
        
        if (! SAshowed) {
            if(translation.x<0) return NO ;
        }
        
        if (SAshowed) {
            if (translation.x>0) {
                return NO;
            }
        }
        
        return fabs(translation.y) < fabs(translation.x);
    }
    else return NO;
    
    
}


- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestufreRecognizer
{
    
    //    if ([self gestureRecognizerShouldBegin:gestureRecognizer])
    
	return self.TableViewCellGesture.state == UIGestureRecognizerStatePossible;
    
}

-(void)setImageWithUrl:(NSURL *)url imageArray:(NSMutableDictionary*)array index:(NSInteger)row{
//    NSLog(@"%@",url);
    imageArray=array;
    currentRow=row;
    ImageRequest =[[ASIFormDataRequest alloc]initWithURL:url];
    [ImageRequest setDidFinishSelector:@selector(ImageDownloadFinished:)];
    [ImageRequest setDelegate:self];
    [ImageRequest setRequestMethod:@"GET"];
    [ImageRequest startAsynchronous];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

-(void)dealloc{
    if (ImageRequest){
            [ImageRequest clearDelegatesAndCancel];
    }
    ImageRequest=nil;

}

-(void)ImageDownloadFinished:(ASIFormDataRequest*)request{
    NSData *data =[request responseData];
    if ([request responseStatusCode]!=200){
        NSLog(@"%d",[request responseStatusCode]);
        return;
    }
    UIImage * image =[UIImage imageWithData:data];
 //   [UIImagePNGRepresentation(image) writeToFile:<#(NSString *)#> atomically:<#(BOOL)#>]
    [self.FrontPicture setImage:image];
 //   [imageArray setObject:image forKey:[NSNumber numberWithInt:currentRow]];
    ImageLocalized *local=[[ImageLocalized alloc]init];
    [local addPic:image URL_Address:[request.url relativeString] DataBaseFileName:nil FileNameDetail: [NSString stringWithFormat:@"%d", self.currentEssayId]];

}


//赞
-(void)AdmirePress:(CellSelectedButton*)button{
    BOOL Admired = button.SelectedState;

    NSInteger count = [self.AdmireNum.text intValue];
    if (Admired==NO){
        ASIFormDataRequest *Brequest = [[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:[basePath stringByAppendingString:LikeCommitUrl]]];
        [Brequest setTimeOutSeconds:1.0];
        [Brequest setPostValue:[[NSString alloc]initWithFormat:@"%d",self.currentEssayId] forKey:@"essay_id"];
        [self.AdmireNum setText:[[NSString alloc]initWithFormat:@"%d",++count]];
//        [Brequest setDelegate:self];
        [Brequest startSynchronous];

        
    }
    
    else {
        ASIFormDataRequest *Brequest = [[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:[basePath stringByAppendingString:LikeCancelUrl]]];
        [Brequest setTimeOutSeconds:1.0];
        [Brequest setPostValue:[[NSString alloc]initWithFormat:@"%d",self.currentEssayId] forKey:@"essay_id"];
        [self.AdmireNum setText:[[NSString alloc]initWithFormat:@"%d",--count]];
        [Brequest startSynchronous];

    }
}
//分享，喜欢
-(void)SharePress:(CellSelectedButton*)button{
    BOOL Shared = button.SelectedState;

    NSInteger count = [self.ShareNum.text intValue];
    if (Shared==YES){
        ASIFormDataRequest *Srequest = [[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:[basePath stringByAppendingString:FavoriteCancelUrl]]];
        [Srequest setTimeOutSeconds:1.0];
        [Srequest setPostValue:[[NSString alloc]initWithFormat:@"%d",self.currentEssayId] forKey:@"essay_id"];

        [self.ShareNum setText:[[NSString alloc]initWithFormat:@"%d",--count]];
        [Srequest startSynchronous];

    }
    else {
        ASIFormDataRequest *Srequest = [[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:[basePath stringByAppendingString:FavoriteCommitUrl]]];
        [Srequest setTimeOutSeconds:1.0];
        [Srequest setPostValue:[[NSString alloc]initWithFormat:@"%d",self.currentEssayId] forKey:@"essay_id"];
        [self.ShareNum setText:[[NSString alloc]initWithFormat:@"%d",++count]];
        [Srequest startSynchronous];

    }
}



@end
