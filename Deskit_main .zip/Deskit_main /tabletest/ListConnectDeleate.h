//
//  ListConnectDeleate.h
//  Deskit_beta
//
//  Created by Sway on 13-7-21.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequestDelegate.h"
#import "ASIFormDataRequest.h"
#import "constant.h"

@interface ListConnectDeleate : NSObject<ASIHTTPRequestDelegate>
@property (nonatomic)NSInteger TabIndex;
@end
