//
//  CustomTabBar.h
//  Tes
//
//  Created by Sway on 13-6-19.
//  Copyright (c) 2013年 Sway. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CustomTabBarDelegate <NSObject>
@optional
-(void)CustomTabBar:(UIButton*)button pressedButtonIndex:(NSInteger)index;
@end

@interface CustomTabBar : UIView{
    UIButton *button0,*button1,*button2,*button3;
    id<CustomTabBarDelegate> delegate;
    UIColor *selectedTitleColor;
    UIColor *selectedBackgroundColor;
    UIColor *buttonBasicBackgoundColor;
    UIColor *NormalTitleColor;
    NSInteger selectedButtonIndex;
    NSInteger lastSelectedButtonIndex;
    NSArray *ButtonArray;
    
}

-(id)init;
-(void)setButtonTitle:(NSString*)title WithIndex:(NSInteger)index;
@property (nonatomic,assign) id<CustomTabBarDelegate> delegate;
@end





