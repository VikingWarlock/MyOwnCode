//
//  Transition.m
//  Deskit_beta
//
//  Created by Sway on 13-9-20.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import "Transition.h"
#import <QuartzCore/QuartzCore.h>
@implementation Transition
+(void)pushViewControllerFormBotton:(UIViewController*)base ViewController:(UIViewController*)controller{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3f;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromTop;
//        transition.delegate = self;
    [base.navigationController.view.layer addAnimation:transition forKey:nil];
    [base.navigationController pushViewController:controller animated:NO];
}

+(void)popViewControllerToBotton:(UIViewController*)base{
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3f;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromBottom;
    //    transition.delegate = self;
    [base.navigationController.view.layer addAnimation:transition forKey:nil];
    [base.navigationController popViewControllerAnimated:NO];
}
@end
