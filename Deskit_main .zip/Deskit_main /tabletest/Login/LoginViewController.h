//
//  ViewController.h
//  Login
//
//  Created by xtoucher08 on 13-6-30.
//  Copyright (c) 2013年 xtoucher08. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTextField.h"
#import "ImageLocalized.h"
@interface LoginViewController : UIViewController{
    NSInteger selectedButtonIndex;
    NSInteger lastSelectedButtonIndex;
}

@property (nonatomic,retain) IBOutlet UIButton *button;
@property (nonatomic,retain) IBOutlet UIButton *checkbox;
@property (nonatomic)BOOL checkBoxSelected;
@property (nonatomic,retain) IBOutlet MyTextField *passWord;
@property (nonatomic,retain) IBOutlet MyTextField *userName;

@property BOOL remindMe;
-(IBAction)closeKeyBoard:(id)sender;
@end
