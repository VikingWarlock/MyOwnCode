//
//  MyTextField.m
//  Login
//
//  Created by Sway on 13-7-29.
//  Copyright (c) 2013年 xtoucher08. All rights reserved.
//

#import "MyTextField.h"

@implementation MyTextField

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (CGRect)textRectForBounds:(CGRect)bounds{
    CGRect rect = CGRectMake(bounds.origin.x+20, bounds.origin.y, bounds.size.width-20, bounds.size.height);
    return rect;
}
- (CGRect)placeholderRectForBounds:(CGRect)bounds{
    CGRect rect = CGRectMake(bounds.origin.x+20, bounds.origin.y, bounds.size.width-20, bounds.size.height);
    return rect;

}
- (CGRect)editingRectForBounds:(CGRect)bounds{
    CGRect rect = CGRectMake(bounds.origin.x+20, bounds.origin.y, bounds.size.width-20, bounds.size.height);
    return rect;

}

@end
