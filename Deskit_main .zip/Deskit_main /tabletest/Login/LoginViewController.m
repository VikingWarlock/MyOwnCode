//
//  ViewController.m
//  Login
//
//  Created by xtoucher08 on 13-6-30.
//  Copyright (c) 2013年 xtoucher08. All rights reserved.
//

#import "LoginViewController.h"
#import "ASIFormDataRequest.h"
#import "constant.h"
#import "JsonDataFormatting.h"
@interface LoginViewController ()



@end

@implementation LoginViewController
@synthesize button;
@synthesize checkbox;
@synthesize passWord;
@synthesize userName;
@synthesize remindMe;
@synthesize checkBoxSelected=_checkBoxSelected;

- (id)initWithUserName:(NSString *)UserName PassWord:(NSBundle *)PassWord RemindMe:(BOOL)RemindMe
{
    
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)setCheckBoxSelected:(BOOL)checkBoxSelected{
    _checkBoxSelected=checkBoxSelected;
    if (_checkBoxSelected){

        [checkbox setBackgroundImage:[UIImage imageNamed:@"checkbok-selected"] forState:UIControlStateNormal];
    }
    else {
                [checkbox setBackgroundImage:[UIImage imageNamed:@"checkbok-blank"] forState:UIControlStateNormal];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.checkBoxSelected=NO;
    
    
    NSLog(@"%f,%f,%f,%f",self.view.frame.origin.x,self.view.frame.origin.y,self.view.frame.size.width,self.view.frame.size.height);
    
    ImageLocalized *temp=[[ImageLocalized alloc]init];
    [temp addDataToFile:[NSString stringWithFormat:@"%d",self.checkBoxSelected] forKey:@"Saved UserInf" FileName:@"setting.plist"];
    
    
    [passWord setSecureTextEntry:YES ];
    //userName=[[UITextField alloc]init];
    //[userName addTarget:self action:@selector(editingRectForBounds:) forControlEvents:UIControlEventTouchUpInside];
    //[userName editingRectForBounds:CGRectMake(10, 0, 290, 44)];
    UIImageView *image=[[UIImageView alloc]initWithFrame:CGRectMake(12, 7, 130, 30)];
    image.image=[UIImage imageNamed:@"Logo"];
    [self.view addSubview:image];
//    button=[[UIButton alloc]init];
//    [button addTarget:self action:@selector(buttonpress0:) forControlEvents:UIControlStateHighlighted];
    [button addTarget:self action:@selector(buttonpress0:) forControlEvents:UIControlEventTouchUpInside];
    
//    checkbox=[[UIButton alloc]initWithFrame:CGRectMake(15, 180, 20, 20)];
        [checkbox setBackgroundImage:[UIImage imageNamed:@"checkbok-blank"] forState:UIControlStateNormal];
    [checkbox setBackgroundImage:[UIImage imageNamed:@"checkbok-pressed"] forState:UIControlStateHighlighted];
    [checkbox addTarget:self action:@selector(buttonpress1:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:checkbox];
    
    
}
-(CGRect)editingRectForBounds:(CGRect)bounds{
    
    return CGRectMake(50, 0, 290, 44);
}



-(IBAction)closeKeyBoard:(id)sender{
    [userName resignFirstResponder];
    [passWord resignFirstResponder];

}

//登陆
-(void)buttonpress0:(UIButton*)button{
//    if(lastSelectedButtonIndex==selectedButtonIndex){
//        [self.button setBackgroundImage:[UIImage imageNamed:@"button-blue"] forState:UIControlStateNormal];
//    }
    
ASIFormDataRequest *loginRequest = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[basePath stringByAppendingString:LoginUrl]]];
[loginRequest setPostValue:userName.text forKey:@"user_name"];
[loginRequest setPostValue:passWord.text forKey:@"plain_password"];
[loginRequest startSynchronous];


    NSError *error;
    NSData *data = [loginRequest responseData];
    NSDictionary *dictionary =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves
    error:&error];
    
    
    /*
    if (error!=nil){
        [JsonDataFormatting NetworkingError:@"网络连接失败"];
        return;
        
        
        
        
    }

    if (![[dictionary objectForKey:@"err"] isKindOfClass:[NSNull class]]){
        [JsonDataFormatting NetworkingError:@"用户名或密码错误"];
        return ;
    }
    */
    
    
    //跳转到初始化面
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"MainStoryboard" bundle:[NSBundle mainBundle]];

    [[UIApplication sharedApplication] keyWindow].rootViewController=[storyBoard instantiateInitialViewController];

}

/*-(void)setBackGroudImage{
    [checkbox setBackgroundImage:[UIImage imageNamed:@"checkbok-pressed"] forState:UIControlStateNormal];
    [checkbox setBackgroundImage:[UIImage imageNamed:@"checkbok-selected"] forState:UIControlStateSelected];
    [checkbox addTarget:self action:@selector(buttonpress1:) forControlEvents:UIControlEventTouchUpInside];
    
}

-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self setBackGroudImage];
    }
    return self;
}*/

-(IBAction)buttonpress1:(id)sender{
    self.checkBoxSelected=!self.checkBoxSelected;
   
    ImageLocalized *temp=[[ImageLocalized alloc]init];
    [temp addDataToFile:[NSString stringWithFormat:@"%d",self.checkBoxSelected] forKey:@"Saved UserInf" FileName:@"setting.plist"];
    
    
    //if(remindMe!=remindMe){
   // [button1 setImage:[UIImage imageNamed:@"checkbok-selected"] forState:UIControlStateNormal];}
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
