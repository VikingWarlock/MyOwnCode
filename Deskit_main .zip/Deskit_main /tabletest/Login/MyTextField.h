//
//  MyTextField.h
//  Login
//
//  Created by Sway on 13-7-29.
//  Copyright (c) 2013年 xtoucher08. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTextField : UITextField

@end
