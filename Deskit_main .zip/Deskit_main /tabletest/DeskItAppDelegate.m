//
//  DeskItAppDelegate.m
//  tabletest
//
//  Created by vikingwarlock on 13-6-14.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import "DeskItAppDelegate.h"
#import "DeskItViewController.h"
#import "ASIFormDataRequest.h"
#import "JsonDataFormatting.h"
#import "LoginViewController.h"
#import "ImageLocalized.h"
@implementation DeskItAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    

    
    path=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    pathDocuments=[path objectAtIndex:0];
    
//    //存放cookie的目录
//    NSString *CookiePath = [[NSSearchPathForDirectoriesInDomains(NSLibraryDirectory,NSUserDomainMask,YES) lastObject] stringByAppendingPathComponent:@"Cookies"];
//    
//    [CookiePath stringByAppendingPathComponent:@"Cookies.binarycookies"];
//    
//    BOOL CookieExist=[[NSFileManager defaultManager] fileExistsAtPath:CookiePath];
//    if (CookieExist){
//        return YES;
//        
//    }
//    else{
//        
//    }
    
    
    
    
    ImageLocalized *file=[[ImageLocalized alloc]init];
    BOOL isLogin=NO;

    NSDictionary *setting=[[NSDictionary alloc]initWithContentsOfFile:[NSString stringWithFormat:@"%@/%@",pathDocuments,@"setting.plist"]];
    BOOL saveUser=[[setting objectForKey:@"Saved UserInf"]intValue];
    if (!saveUser) {
        [self logout];
    }
    if (![[setting allKeys]containsObject:@"PushButton"]) {
        [file addDataToFile:[NSString stringWithFormat:@"%d",YES] forKey:@"PushButton" FileName:@"setting.plist"];
    }
    if (![[setting allKeys]containsObject:@"Cellular"]) {
            [file addDataToFile:[NSString stringWithFormat:@"%d",YES] forKey:@"Cellular" FileName:@"setting.plist"];
    
    }

    NSURL *url = [NSURL URLWithString:[basePath stringByAppendingString:isLoginUrl]];


    ASIFormDataRequest *request = [[ASIFormDataRequest alloc]initWithURL:url];
    [request setTimeOutSeconds:1.5];


    [request startSynchronous];

        NSLog(@"%@",[request requestHeaders]);
    NSLog(@"code %d",[request responseStatusCode]);
    if (request.responseStatusCode!=200){
        [JsonDataFormatting NetworkingError:@"网络连接失败，请检查网络"];
        if (!saveUser) {
            isLogin=NO;
            
            [self logout];
            
        }
        return YES;
    }

    
    NSError *error;
    NSData *data= [request responseData];
    NSDictionary * dictionary =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
    NSLog(@"%@",dictionary);
    if (error!=nil){
        NSLog(@"%@",error);
        [JsonDataFormatting NetworkingError:@"网络连接失败，请重新登录"];
       // isLogin=NO;
        return YES;
    }
    id result=[dictionary objectForKey:@"data"];
    if (result==nil){
        [JsonDataFormatting NetworkingError:@"网络连接失败，请重新登录"];
        //isLogin=NO;
        return YES;
    }else {
     isLogin= [result boolValue];
    }
    
    if (isLogin)return YES;
    else {
        self.window.rootViewController=[[LoginViewController alloc]init];
        return YES;
    }

    
//    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"MainStoryboard" bundle:[NSBundle mainBundle]];
//
//    self.window.rootViewController=[storyBoard instantiateInitialViewController];    // Override point for customization after application launch.
    return YES;
}
							
- (void)applicationWillResignActive:(UIApplication *)application
{

    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
   
}


-(void)logout{
    ASIFormDataRequest *logout;
    NSURL *url=[NSURL URLWithString:[basePath stringByAppendingString:LogoutUrl]];
    logout=[ASIFormDataRequest requestWithURL:url];
    [logout setRequestMethod:@"POST"];
    [logout startSynchronous];
    
    NSError *error;
    NSData *data = [logout responseData];
    
    /*
    NSDictionary *dictionary =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
    if (error!=nil){
        ;
        return;
    }
    
    if (![[dictionary objectForKey:@"err"] isKindOfClass:[NSNull class]]){
        return ;
    }
    */
  
    
    
}

@end
