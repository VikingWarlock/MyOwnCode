//
//  DeskItCellLoadFile.m
//  tabletest
//
//  Created by vikingwarlock on 13-6-16.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import "DeskItCellLoadFile.h"

@implementation DeskItCellLoadFile

//[modify@卓越：2013-7-24 改到沙盒里]
//+(NSDictionary *)LoadFile:(NSString *)FileName
//{
//    NSString *errorInf=nil;
//    NSPropertyListFormat format;
//    NSString *plistPath=[[NSBundle mainBundle] pathForResource:FileName ofType:@"plist"];
//    NSData *plistXML=[[NSFileManager defaultManager]contentsAtPath:plistPath];
//    
//    NSDictionary *temp=(NSDictionary *)[NSPropertyListSerialization propertyListFromData:plistXML mutabilityOption:NSPropertyListMutableContainersAndLeaves format:&format errorDescription:&errorInf];
//        
//    if (!temp)
//        NSLog(@"line %d with error : %@",__LINE__,errorInf);
//    
//    
//    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    NSString *SandboxPath = [paths objectAtIndex:0];
//    
//    
//    NSString *filePath =[SandboxPath stringByAppendingPathComponent:[FileName stringByAppendingString:@".plista"]] ;
//    [temp writeToFile:filePath atomically:YES];
//    
//    
//    return temp;
//    
//}

+(NSDictionary *)LoadFile:(NSString *)FileName{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *SandboxPath = [paths objectAtIndex:0];


    NSString *filePath =[SandboxPath stringByAppendingPathComponent:[FileName stringByAppendingString:@".plist"]] ;
    if (![[NSFileManager defaultManager] fileExistsAtPath:filePath]){
        NSDictionary *dictionary = [[NSDictionary alloc ]init];
        return dictionary;
    }
    
    NSDictionary *dictionary = [[NSDictionary alloc]initWithContentsOfFile:filePath];
    return dictionary;

}

+(BOOL)FileExist :(NSString*) FileName
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *SandboxPath = [paths objectAtIndex:0];
    
    
    NSString *filePath =[SandboxPath stringByAppendingPathComponent:[FileName stringByAppendingString:@".plist"]] ;
    return ([[NSFileManager defaultManager]fileExistsAtPath:filePath]);

}

+(void)WriteFile:(NSDictionary*)dictionary name:(NSString*)FileName{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *SandboxPath = [paths objectAtIndex:0];
    
    
    NSString *filePath =[SandboxPath stringByAppendingPathComponent:[FileName stringByAppendingString:@".plist"]];
    [dictionary writeToFile:filePath atomically:YES];
}

@end
