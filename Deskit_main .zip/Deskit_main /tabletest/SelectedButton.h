//
//  SelectedButton.h
//  Test
//
//  Created by Sway on 13-6-22.
//  Copyright (c) 2013年 Sway. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SelectedButton;
@protocol SelectedButtonDelegate <NSObject>
@optional
-(void)SelectedButton:(SelectedButton*)button;

@end

@interface SelectedButton : UIButton{

}
@property(nonatomic)BOOL SelectedState;
@property(nonatomic)id<SelectedButtonDelegate>delegate;
-(id)initWithFrame:(CGRect)frame NormalImage:(UIImage*)Nimage SelectedImage:(UIImage *)Simage;
-(void)setNormalImage:(UIImage*)Nimage;
-(void)setSelectedImage:(UIImage*)Simage;
-(void)Select;
-(void)InitForPress;//如果是Xib加载的话要调用这个方法初始化
-(void)setButtonState:(BOOL)State;
@end



