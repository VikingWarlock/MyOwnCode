//
//  Switch.m
//  Setting
//
//  Created by Sway on 13-8-5.
//  Copyright (c) 2013年 xtoucher08. All rights reserved.
//

#import "Switch.h"
#import <QuartzCore/QuartzCore.h>
#import "ImageLocalized.h"

#define DEFAULT_DURATION 0.5f

#define w 60
#define h 25

@interface Switch()
{
    CGFloat _minusTranslate;
    CGRect _leftRect;
    CGRect _middleRect;
    BOOL first;
    CGFloat _currentTranslationX;
    
}

@property(nonatomic,retain) UIView *customSwitch;
@property(nonatomic,retain) UIButton *onButton;
@property(nonatomic,retain) UIButton *offButton;

@end

@implementation Switch
@synthesize onImage = _onImage;
@synthesize offImage = _offImage;
@synthesize customSwitch = _customSwitch;
@synthesize onButton = _onButton;
@synthesize offButton = _offButton;
@synthesize arrange = _arrange;
@synthesize status = _status;
@synthesize method;

-(void)switchAction{
    ImageLocalized *file=[[ImageLocalized alloc]init];
    if ([method isEqualToString:@"PushButton"]) {
        
    
    if (self.status == CustomSwitchStatusOn) {
        NSLog(@"on");
        [file addDataToFile:[NSString stringWithFormat:@"%d",YES] forKey:@"PushButton" FileName:@"setting.plist"];
    }
    else
    {
        NSLog(@"off");
        [file addDataToFile:[NSString stringWithFormat:@"%d",NO] forKey:@"PushButton" FileName:@"setting.plist"];
    }
    }else
    if ([method isEqualToString:@"Cellular"]) {
        if (self.status == CustomSwitchStatusOn) {
            NSLog(@"on");
            [file addDataToFile:[NSString stringWithFormat:@"%d",YES] forKey:@"Cellular" FileName:@"setting.plist"];
        }
        else
        {
            NSLog(@"off");
            [file addDataToFile:[NSString stringWithFormat:@"%d",NO] forKey:@"Cellular" FileName:@"setting.plist"];
        }

    }
}
-(void)setStatus:(CustomSwitchStatus)status
{
    if (_arrange == CustomSwitchArrangeOFFLeftONRight) {
        
        if (self.status == CustomSwitchStatusOn) {
            if (status == CustomSwitchStatusOff) {
                _status = status;
                [self moveButtonTranslation:_minusTranslate];
            }
        }
        else{
            if (status == CustomSwitchStatusOn) {
                _status = status;
                [self moveButtonTranslation:0];
            }
            
        }
    }
    else{
        if (self.status == CustomSwitchStatusOn) {
            if (status == CustomSwitchStatusOff) {
                _status = status;
                [self moveButtonTranslation:0];
            }
            
        }
        else{
            if (status == CustomSwitchStatusOn) {
                _status = status;
                [self moveButtonTranslation:_minusTranslate];
            }
        }
    }
    
    //_status = status;
    
    if ([_delegate respondsToSelector:@selector(customSwitchSetStatus:)]) {
        [_delegate customSwitchSetStatus:_status];
    }
    
}

-(void)moveButtonTranslation:(CGFloat)translation
{
    [UIView animateWithDuration:0.3 animations:^{
        _onButton.transform = CGAffineTransformMakeTranslation(translation, 0);
        _offButton.transform = CGAffineTransformMakeTranslation(translation, 0);
        [_customSwitch exchangeSubviewAtIndex:0 withSubviewAtIndex:1];
        [self switchAction];
        
    } completion:^(BOOL finished) {
        
    }];
}

-(id)initWithOnImage:(UIImage*)onImage offImage:(UIImage*)offImage arrange:(CustomSwitchArrange)arrange
{
    self.onImage = onImage;
    self.offImage = offImage;

    
    
    _customSwitch = [[UIView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
    _customSwitch.backgroundColor = [UIColor redColor];
    
    _onButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_onButton setImage:onImage forState:UIControlStateNormal];
    
    _offButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_offButton setImage:offImage forState:UIControlStateNormal];
    _currentTranslationX = 0;
    
    
    if (_arrange == CustomSwitchArrangeONLeftOFFRight) {
        
        _onButton.frame = CGRectMake(0, 0, w, h);
        _offButton.frame = CGRectMake(w - h, 0, w, h);
    }else{
        
        _offButton.frame = CGRectMake(0, 0, w, h);
        _onButton.frame = CGRectMake(w - h, 0, w, h);
        
    }
    [_onButton addTarget:self action:@selector(switchBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [_offButton addTarget:self action:@selector(switchBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    [_customSwitch addSubview:_onButton];
    [_customSwitch addSubview:_offButton];
    
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(switchBtnDragged)];
    [_onButton addGestureRecognizer:panGesture];
    [_offButton addGestureRecognizer:panGesture];
    
    [self addSubview:_customSwitch];
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
-(void)switchBtnClicked
{
    if (_status == CustomSwitchStatusOn) {
        [self setStatus:CustomSwitchStatusOff];
    }else{
        [self setStatus:CustomSwitchStatusOn];
    }
}


-(void)switchBtnDragged:(UIPanGestureRecognizer*)panGuester
{
    CGFloat translation = [panGuester translationInView:panGuester.view].x;
    CGFloat moveTranslation = 0.0;
    moveTranslation = translation + _currentTranslationX;
    
    //    NSLog(@"translation ：%f\n",translation);
    if (panGuester.state == UIGestureRecognizerStateChanged) {
        
        //往左边滑x<0 ,往右边滑x>0
        if (translation < 0) {
            [self setStatus:CustomSwitchStatusOff];
                    }
        else if (translation > 0) {
            [self setStatus:CustomSwitchStatusOn];
                }
   }
}


- (void)drawRect:(CGRect)rect
{
    if (!first) {
        _customSwitch.backgroundColor = [UIColor clearColor];
        [_customSwitch setFrame:CGRectMake(0, 0, w, h)];
        [_onButton setImage:_onImage forState:UIControlStateNormal];
        [_offButton setImage:_offImage forState:UIControlStateNormal];
        [_onButton addTarget:self action:@selector(switchBtnClicked) forControlEvents:UIControlEventTouchUpInside];
        [_offButton addTarget:self action:@selector(switchBtnClicked) forControlEvents:UIControlEventTouchUpInside];
        
        _leftRect = CGRectMake(-(w - h), 0, w, h);
        _middleRect = CGRectMake(0, 0, w, h);
        
        CAShapeLayer *maskLayer = [CAShapeLayer layer];
        UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:_customSwitch.bounds
                                                            cornerRadius:_customSwitch.bounds.size.height / 2.0];
        maskLayer.path = maskPath.CGPath;
        _customSwitch.layer.mask = maskLayer;
        
        
        _minusTranslate = w - h;
        _currentTranslationX = 0;
        if (_arrange == CustomSwitchArrangeONLeftOFFRight) {
            
            _onButton.frame = _leftRect;
            _offButton.frame =  _middleRect;
            if (self.status == CustomSwitchStatusOn) {
                
                [self moveButtonTranslation:_minusTranslate];
                
                
            }else{
                [self moveButtonTranslation:0];
            }
            
        }else{
            
            _offButton.frame = _leftRect;
            _onButton.frame =  _middleRect;
            if (self.status == CustomSwitchStatusOn) {
                
                [self moveButtonTranslation:0];
                
                
            }else{
                
                [self moveButtonTranslation:_minusTranslate];
            }
            
        }
        UIPanGestureRecognizer *off_panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(switchBtnDragged:)];
        UIPanGestureRecognizer *on_panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(switchBtnDragged:)];
        [_onButton addGestureRecognizer:on_panGesture];
        [_offButton addGestureRecognizer:off_panGesture];
        
        [self addSubview:_customSwitch];
    }
    first = YES;
    
}


-(void)awakeFromNib{
    NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:@"Switch" owner:self options:nil];
    for (UIView *view in nibs)
        if ([view isKindOfClass:[UIView class]]) {
            _customSwitch = (UIView*)[view retain];
            break;
        }
    NSArray *subviews = [_customSwitch subviews];
    for (UIView *view in subviews) {
        
        if ([view isKindOfClass:[UIButton class]]) {
            
            UIButton *btn = (UIButton*)view;
            if (btn.tag == 1)
                _onButton = [btn retain];
            else if (btn.tag == 2)
                _offButton = [btn retain];
        }
    }

}





@end
