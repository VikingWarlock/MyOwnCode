//
//  MyUIPageControl.m
//  SGFocusImageFrame
//
//  Created by Sway on 13-6-12.
//  Copyright (c) 2013年 Shane Gao. All rights reserved.
//

#import "MyUIPageControl.h"
#import "constant.h"
@interface MyUIPageControl(){

}

- (void)uodateDots;



@end

@implementation MyUIPageControl
//@synthesize normalImage = _normalImage;
//@synthesize highlightedImage = _highlightedImage;



- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        //圆点的两张图片
        self.normalImage =[UIImage imageNamed:@"小方块_暗.png"];

        self.highlightedImage =[UIImage imageNamed:@"小方块_亮.png"];
        self.opaque=NO;
        //self.clearsContextBeforeDrawing=YES;
    }
    return self;
}

- (void)setNormalImage:(UIImage *)normalImage
{
    _normalImage = normalImage;
    [self updateDots];
}

- (void)setHighlightedImage:(UIImage *)highlightedImage
{
    _highlightedImage = highlightedImage;
    [self updateDots];
}

- (void)updateDots
{
    if(_normalImage || _highlightedImage)
    {
        NSArray *subviews = self.subviews;
        for(NSInteger i = 0;i<subviews.count;i++)
        {
            UIImageView *dot = [subviews objectAtIndex:i];
//            if (dot)NSLog(@"!!!!");
            //小方块位置
            [dot setFrame:CGRectMake(dot.frame.origin.x, dot.frame.origin.y, kScrollDotWidth,kScrollDotHight)];
//            NSLog(@"%@",dot.image);
            dot.image = self.currentPage == i ? _highlightedImage : _normalImage ;

        }
    }
}


#ifdef _FOR_DEBUG_
-(BOOL) respondsToSelector:(SEL)aSelector {
    printf("SELECTOR: %s\n", [NSStringFromSelector(aSelector) UTF8String]);
    return [super respondsToSelector:aSelector];
}
#endif


- (void)setCurrentPage:(NSInteger)currentPage
{
    [super setCurrentPage:currentPage];
    [self updateDots];
}


 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
     for(NSInteger i = 0;i<self.subviews.count;i++)
     {
         UIImageView *dot = [self.subviews objectAtIndex:i];
         //小方块位置
         [dot setFrame:CGRectMake(self.bounds.origin.x+i*kDotSpacer, self.bounds.origin.y,kScrollDotWidth,kScrollDotHight)];
     }

 }


@end

