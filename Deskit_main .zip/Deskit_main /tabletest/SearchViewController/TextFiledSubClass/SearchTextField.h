//
//  SearchTextField.h
//  Search
//
//  Created by Sway on 13-9-21.
//  Copyright (c) 2013年 Sway. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchTextField : UITextField

@end
