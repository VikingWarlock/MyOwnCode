//
//  SearchTextField.m
//  Search
//
//  Created by Sway on 13-9-21.
//  Copyright (c) 2013年 Sway. All rights reserved.
//

#import "SearchTextField.h"
#define TextOffset 30

@implementation SearchTextField

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (CGRect)textRectForBounds:(CGRect)bounds{
    return CGRectMake(bounds.origin.x+TextOffset, bounds.origin.y, bounds.size.width-TextOffset, bounds.size.height);
}
- (CGRect)placeholderRectForBounds:(CGRect)bounds{
    return CGRectMake(bounds.origin.x+TextOffset, bounds.origin.y, bounds.size.width-TextOffset, bounds.size.height);
}
- (CGRect)editingRectForBounds:(CGRect)bounds{
    return CGRectMake(bounds.origin.x+TextOffset, bounds.origin.y, bounds.size.width-TextOffset, bounds.size.height);
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
