//
//  ViewController.m
//  Search
//
//  Created by Sway on 13-9-21.
//  Copyright (c) 2013年 Sway. All rights reserved.
//

#import "SearchViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "SearchTextField.h"
#import "constant.h"
#import "TagCloud_Detail.h"
#import "Transition.h"
#import "InformationViewController.h"
#import "CellForTagWithSubscribeButton.h"



@interface HotTagButton:UIButton
@property NSInteger TagId;
@property NSInteger CategoryId;
@property NSString *name;

@end
@implementation HotTagButton



@end

@interface SearchViewController (){
    IBOutlet UIView *Bar;
    IBOutlet SearchTextField *myTextField;
    UIView *searchingView;
    UIActivityIndicatorView *gear;
    
    UITableView *resultTableView;
    ASIFormDataRequest *searchRequest,*hotTagRequest;
    //搜索结果得两种类型
    NSArray *essays,*tags;
    
    //TableView用到的数据数组
    //二重DIctionary，第一层存放tableview section 的名字，第二层存放每行Cell的名称和Id
    NSDictionary *TableViewDataDictionary;
    
    
}
@property (nonatomic)    BOOL resultTableViewDisplayed,searchingViewDisplayed;

@end

@implementation SearchViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    //界面初始化
    [self displayViewElements];
    
    
    //请求热门标签
    NSURL *url =[NSURL URLWithString:[basePath stringByAppendingString:HotTagListURL]];
    hotTagRequest = [ASIFormDataRequest requestWithURL:url];
    [hotTagRequest setRequestMethod:@"POST"];
    [hotTagRequest setDelegate:self];
    [hotTagRequest startAsynchronous];
    
}

-(void)viewDidDisappear:(BOOL)animated{
    if (hotTagRequest){
        [hotTagRequest clearDelegatesAndCancel];
        hotTagRequest=nil;
    }
}




-(void)setResultTableViewDisplayed:(BOOL)resultTableViewDisplayed{
    _resultTableViewDisplayed=resultTableViewDisplayed;
    resultTableView.hidden=!resultTableViewDisplayed;
}

-(void)setSearchingViewDisplayed:(BOOL)searchingViewDisplayed{
    _searchingViewDisplayed=searchingViewDisplayed;
    searchingView.hidden=!searchingViewDisplayed;
    if (searchingViewDisplayed){
        [gear startAnimating];
    }else {
        [gear stopAnimating];
    }
}

-(void)displayViewElements{
    //搜索栏界面配置
    
    
    [Bar.layer setShadowColor:[[UIColor grayColor] CGColor]];
    [Bar.layer setShadowOffset:CGSizeMake(-20, 0.2)];
    [Bar.layer setShadowRadius:20];
    [Bar.layer setShadowOpacity:0.5];
    
    
    //文本框代理
    myTextField.Delegate=self;
    
    
    
    //“搜寻中。。”界面
    searchingView =[[[NSBundle mainBundle] loadNibNamed:@"searchingView" owner:self options:nil] lastObject];
    gear=(UIActivityIndicatorView*)[searchingView viewWithTag:1];
    [searchingView setFrame:CGRectMake(0, 44, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-44)];
    //    [searchingView setAlpha:0];
    [self.view insertSubview:searchingView belowSubview:Bar];
    
    //监听文本框的改变
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textFieldChange:) name:UITextFieldTextDidChangeNotification object:myTextField];
    
    
    //tableView 初始化
    resultTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 44, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-44)];

    [resultTableView setBackgroundColor:[UIColor colorWithRed:237.0/255.0 green:237.0/255.0 blue:237.0/255.0 alpha:1]];
    [resultTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [resultTableView registerClass:[UITableViewHeaderFooterView class] forHeaderFooterViewReuseIdentifier:@"header"];
    [self.view insertSubview:resultTableView belowSubview:Bar];
    resultTableView.delegate=self;
    resultTableView.dataSource=self;
    self.resultTableViewDisplayed=NO;
    self.searchingViewDisplayed=NO;
    
    //标签的Cell注册
    [resultTableView registerClass:[CellForTagWithSubscribeButton class] forCellReuseIdentifier:@"tags"];
}

//关闭键盘
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    
    if (![myTextField isExclusiveTouch]) {
        [myTextField resignFirstResponder];
    }
    
//    NSLog(@"%d",self.resultTableViewDisplayed);
}



- (IBAction)popButtonPress:(id)sender {
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




#pragma mark - UITextFiled Delegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    NSLog(@"begin");
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField{

//    NSLog(@"end");
}

-(void)textFieldChange:(id)sender{
    //隐藏tableview和显示searchingView
    if (myTextField.text.length==0){
        
        self.resultTableViewDisplayed=NO;
        self.searchingViewDisplayed=NO;
        return;
    }
//    NSLog(@"%d",self.searchingViewDisplayed );
    if (self.resultTableViewDisplayed)self.resultTableViewDisplayed=NO;
    if (!self.searchingViewDisplayed)self.searchingViewDisplayed=YES;
    
    
    //获取字符串，重建搜索请求
    NSString *keyWord = [myTextField text];
    if (searchRequest)[searchRequest clearDelegatesAndCancel];
    searchRequest =[ASIFormDataRequest requestWithURL:[NSURL URLWithString:[basePath stringByAppendingString:SearchUrl]]];
    [searchRequest setPostValue:keyWord forKey:@"keyword"];
    [searchRequest setDelegate:self];
    [searchRequest setDidFinishSelector:@selector(searchFinish:)];
    [searchRequest startAsynchronous];
    
    
}

#pragma mark TableView

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return [TableViewDataDictionary.allKeys count];
}

//-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
//    if (section==0)return @"标签";
//    else if (section==1)return @"信息";
//    else return nil;
//}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSString *key = [[TableViewDataDictionary allKeys] objectAtIndex:section];
    return [[TableViewDataDictionary objectForKey:key] count];
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *SectionName = [[TableViewDataDictionary allKeys] objectAtIndex:indexPath.section];
    UITableViewCell *cell;
    if ([SectionName isEqualToString:@"标签"]){
        CellForTagWithSubscribeButton* tempCell =[tableView dequeueReusableCellWithIdentifier:@"tags" forIndexPath:indexPath];
        [tempCell setTagId:[[[[TableViewDataDictionary objectForKey:SectionName] objectAtIndex:indexPath.row] objectForKey:@"id"] integerValue]];
//        tempCell.textLabel.text=[[[TableViewDataDictionary objectForKey:SectionName] objectAtIndex:indexPath.row] objectForKey:@"name"];
        cell=tempCell;
    }
    if ([SectionName isEqualToString:@"信息"])cell =[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    //    cell.contentView.backgroundColor=[UIColor colorWithRed:237.0/255.0 green:237.0/255.0 blue:237.0/255.0 alpha:1];
    cell.textLabel.backgroundColor=[UIColor clearColor];
    [cell.textLabel setFont:[UIFont systemFontOfSize:16]];
    [cell.textLabel setTextColor:[UIColor colorWithRed:61.0/255.0 green:61.0/255.0 blue:61.0/255.0 alpha:1]];
//    NSLog(@"%@",[essays objectAtIndex:indexPath.row] );
//    NSLog(@"%d",indexPath.row);


    cell.textLabel.text=[[[TableViewDataDictionary objectForKey:SectionName] objectAtIndex:indexPath.row] objectForKey:@"name"];
//    cell.textLabel.text=@"aa";
    return cell;
}


-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 30;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}

-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view =[[UIView alloc]initWithFrame:CGRectMake(0, 1, 320, 28)];
    [view setBackgroundColor:[UIColor colorWithRed:221.0/255.0 green:221.0/255.0 blue:221.0/255.0 alpha:1]];
    UILabel *label =[[UILabel alloc]initWithFrame:CGRectMake(10, 5, 40, 20)];
    [view addSubview:label];
    [label setBackgroundColor:[UIColor clearColor]];
    [label setFont:[UIFont systemFontOfSize:14]];
    [label setTextColor:[UIColor colorWithRed:164.0/255.0 green:164.0/255.0 blue:164.0/255.0 alpha:1]];
    
    label.text=[[TableViewDataDictionary allKeys] objectAtIndex:section];
    
    UIView *blackLine=[[UIView alloc]initWithFrame:CGRectMake(0, 0, view.bounds.size.width, view.bounds.size.height+2)];
    [blackLine setBackgroundColor:[UIColor colorWithRed:200.0f/255 green:200.0f/255 blue:200.0f/255 alpha:1]];
    [blackLine addSubview:view];
    
    
    return  blackLine;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString* SectionName = [[TableViewDataDictionary allKeys] objectAtIndex:indexPath.section];
    
    //element 包含name和id
    NSDictionary *element = [[TableViewDataDictionary objectForKey:SectionName] objectAtIndex:indexPath.row];
    if ([SectionName isEqualToString:@"标签"]){
        [self pushToTagCloudDetialWithId:[[element objectForKey:@"id"] integerValue] TagName:[element objectForKey:@"name"]];
    }
    if ([SectionName isEqualToString:@"信息"]){
        [self pushToInformationWithId:[[element objectForKey:@"id"] integerValue]];
    }
}

-(void)requestFinished:(ASIHTTPRequest *)request{
    NSError *error;
    NSData *responseData = [request responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
        NSArray *data=[NSArray arrayWithObject:[responseDictionary objectForKey:@"data"]];
        NSArray *HotTagArray;
        if ([data count]==0){
            NSLog(@"data empty");
            return;
        }
        
        HotTagArray = [data lastObject];
        if ([HotTagArray count]==0) {
            NSLog(@"tag array empty");
            return ;
        }
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"返回值出错");
            NSLog(@"%@",ResponseErrMsg);
            return ;
        }
        
        NSLog(@"%@",[[HotTagArray objectAtIndex:0] allKeys]);
        NSMutableArray *TempArray=[[NSMutableArray alloc]init];
        
        
        for (NSDictionary *element in HotTagArray){
            //        [idArray addObject:ç];
            //        [TempArray addObject:ç];
            //        [cateArray addObject:[element objectForKey:@"category_id"]];
            HotTagButton *button = [[HotTagButton alloc ]init];
            button.TagId=[[element objectForKey:@"id"] integerValue];
            button.CategoryId=[[element objectForKey:@"category_id"] integerValue];
            button.name=[element objectForKey:@"name"];
            [TempArray addObject:button];
        }
        //    [self setTagCateGoryIdArray:cateArray];
        //    [self setTagIdArray:idArray];
        //    [self setTagArray:TempArray];
        [self setButtonArray:TempArray];
        
    }
}

-(void)setButtonArray:(NSArray *)buttonArray{
    NSInteger row=0;
    const CGFloat hightInteval=38;
    const CGFloat basicHight=80;
    CGFloat currentX=6.0;
    _buttonArray=buttonArray;
    CGFloat fontSize=16.0;
    
    
    //    NSInteger length=[buttonArray count];
    
    //    for (NSInteger i=0;i<length;i++){
    //        NSString *tag = [TagArray objectAtIndex:i];
    for (HotTagButton* button in buttonArray){
        CGSize size= [self measureLabelSize:button.name FontSize:fontSize];
        //        NSLog(@"%f",size.width);
        
        //计算区域
        if (currentX+size.width>[UIScreen mainScreen].bounds.size.width-20){
            row++;
            currentX=6.0;
            
        }
        
        //将按钮添加到相应区域
        //        HotTagButton *button=[[HotTagButton alloc]init];
        [button setFrame:CGRectMake(currentX, basicHight+row*hightInteval, size.width, size.height)];
        [button setTitle:button.name forState:UIControlStateNormal];
        [button.titleLabel setFont:[UIFont systemFontOfSize:fontSize]];
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
        [button addTarget:self action:@selector(press:) forControlEvents:UIControlEventTouchUpInside];
        [self.view insertSubview:button atIndex:1];
        currentX+=size.width;
        
        
    }
}

-(void)press:(HotTagButton*)button{
    //    NSLog(@"%@",button.titleLabel.text);
    TagCloud_Detail *controller = [[TagCloud_Detail alloc]init];
    [controller initStyle:NO :button.name :0 :[NSString stringWithFormat:@"%d",button.TagId] :@"SearchView"];
//    [self dismissModalViewControllerAnimated:NO];
    [self.navigationController pushViewController:controller animated:YES];
}
- (IBAction)popPress:(id)sender {

        
        //    [self.navigationController popViewControllerAnimated:YES];
        //    [self dismissViewControllerAnimated:YES completion:nil];
        [Transition popViewControllerToBotton:self];
        
    
}


#pragma  mark 搜索完成回调
-(void)searchFinish:(ASIFormDataRequest*)request{
    self.searchingViewDisplayed=NO;
    //*疑问：搜索超时的话。。。。
    self.resultTableViewDisplayed=YES;
    
    //tableview 处理
    NSData *data = [request responseData];
    NSDictionary *dic=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
    if (![[dic objectForKey:@"err"] isMemberOfClass:[NSNull class]]){
        NSLog(@"搜索出错");
        self.resultTableViewDisplayed=NO;
        return;
    }
    essays = [[dic objectForKey:@"data"] objectForKey:@"essays"];
    tags = [[dic objectForKey:@"data"] objectForKey:@"tags"];
    
    //
    //TableView section 的初始化
    NSMutableDictionary *tempTableViewDataArray = [[NSMutableDictionary alloc]init];
    
    //如果不为空就加入TableVIewDataArray中，TableView Delegate 只需根据该数组处理即可
    if ([tags count]!=0){
        [tempTableViewDataArray setObject:tags forKey:@"标签"];
    }
    
    if ([essays count]!=0){
        NSMutableArray *tempEssaysArray = [[NSMutableArray alloc]init];
        for (NSDictionary *dic in essays){
            //最里层
            NSDictionary *tempDic = [[NSDictionary alloc]initWithObjectsAndKeys:[dic objectForKey:@"id"],@"id",[dic objectForKey:@"title"],@"name", nil];
            //加到数组中
            [tempEssaysArray addObject:tempDic];
        }
        NSArray *EssaysArray = [[NSArray alloc]initWithArray:tempEssaysArray];
        [tempTableViewDataArray setObject:EssaysArray forKey:@"信息"];
    }
    
    TableViewDataDictionary =[[NSDictionary alloc]initWithDictionary:tempTableViewDataArray];
    //*如果为空
    [resultTableView reloadData];


}

-(void)pushToInformationWithId:(NSInteger)Id{
    InformationViewController* controller = [[InformationViewController alloc] init];
    [controller initStyleFromRoot:[NSNumber numberWithInteger:Id]];
    [self.navigationController pushViewController:controller animated:YES];
}

-(void)pushToTagCloudDetialWithId:(NSInteger)Id TagName:(NSString*)name{
    TagCloud_Detail *controller = [[TagCloud_Detail alloc]init];
    [controller initStyle:NO :name:0 :[NSString stringWithFormat:@"%d",Id] :@"SearchView"];
    [self.navigationController pushViewController:controller animated:YES];
}



#pragma mark -
#pragma mark 计算标签长度
-(CGSize)measureLabelSize:(NSString*)myString FontSize:(float)size{
    CGSize maximumSize = CGSizeMake(300, 9999);
    //    UIFont *myFont = [UIFont fontWithName:@"Helvetica" size:14];
    UIFont *myFont =[UIFont systemFontOfSize:size];
    CGSize myStringSize = [myString sizeWithFont:myFont
                               constrainedToSize:maximumSize
                                   lineBreakMode:NSLineBreakByWordWrapping];
    
    return CGSizeMake(myStringSize.width+16, myStringSize.height+8);
}
////requestFinishFunc
//{
//    //hide searchingView
//    //display TableView
//    
//
//
//
//}
@end
