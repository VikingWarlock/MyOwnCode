//
//  ViewController.h
//  Search
//
//  Created by Sway on 13-9-21.
//  Copyright (c) 2013年 Sway. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIFormDataRequest.h"
@interface SearchViewController : UIViewController<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate,ASIHTTPRequestDelegate>
@property (nonatomic)NSArray *buttonArray;
@end
