//
//  IntroductionPage.h
//  Deskit_beta
//
//  Created by viking warlock on 9/1/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IntroductionPage : UIView
{
    NSArray *imageArray;
    int sumIntroduction;
    

}


-(void)CheckFirstTimeToThisPage :(NSString*)pagename CheckFileForKey:(NSString*) key;

@property (nonatomic,weak) IBOutlet UIButton *previous;
@property (nonatomic,weak) IBOutlet UIButton *next;
@property (nonatomic,weak) IBOutlet UIImageView *content;

@end
