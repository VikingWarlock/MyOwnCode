//
//  IntroductionPage.m
//  Deskit_beta
//
//  Created by viking warlock on 9/1/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import "IntroductionPage.h"

@implementation IntroductionPage

@synthesize previous;
@synthesize next;
@synthesize content;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void)CheckFirstTimeToThisPage :(NSString*)pagename CheckFileForKey:(NSString*) key
{
}




/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
