//
//  CustomCell.h
//  Order
//
//  Created by Sway on 13-6-21.
//  Copyright (c) 2013年 sjy. All rights reserved.
//

#import <UIKit/UIKit.h>
@class SubscribeCell;

@protocol SubscribeCellDelegate <NSObject>
@optional
-(void)SubscribeCell:(SubscribeCell*)Nowcell: (NSInteger)buttonPressRowInTableView;

@end

@interface SubscribeCell : UITableViewCell{
    BOOL Subscribed;
    NSInteger CurrentRow;//当前Cell所处的TableView里的Row
}
@property (assign)id<SubscribeCellDelegate> delegate;
@property (readonly)BOOL Subscribed;
@property (nonatomic)NSInteger CurrentRow;
-(void)setButtonStatusWithSubscribed:(BOOL)subscribed;
-(SubscribeCell*)initWithStyle:(UITableViewCellStyle)CellStyle reuseIdentifier:(NSString*)identifier delegate:(id<SubscribeCellDelegate>)Delegate;
@end



