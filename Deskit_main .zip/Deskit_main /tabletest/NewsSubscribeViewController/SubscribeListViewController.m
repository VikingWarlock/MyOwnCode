//
//  ViewController.m
//  Order
//
//  Created by sjy on 13-6-12.
//  Copyright (c) 2013年 sjy. All rights reserved.
//
//#import"Subscribe_DetailViewController.h"
#import "SubscribeListViewController.h"
#import "SearchViewController.h"
#import "Transition.h"
#import "Subscribe_Detail.h"
@interface SubscribeListViewController (){
    ASIFormDataRequest *SubscribeRequest;
}

@end

@implementation SubscribeListViewController

@synthesize  listData;
@synthesize CategoryIdArray;
@synthesize searchButton;
@synthesize SubscribeStateArray;
@synthesize SubscribIdArray;
@synthesize SelftableView;
@synthesize popBackButton;
@synthesize NavTitleLabel;
@synthesize DetailId;
@synthesize lastview;

-(id)init{
    self = [super init];
    if (self){
//        [self UIInit];//界面初始化
//        //    [SelftableView registerClass:[SubscribeCell class] forCellReuseIdentifier:@"CustomCell"];
//        
//        // Do any additional setup after loading the view, typically from a nib.
//        //    NSArray *array=[[NSArray alloc]initWithObjects:@"新闻中心",@"学校要闻",@"综合新闻",@"学院动态",@"名师苑",@"银杏海",@"校园观察",@"媒体成电", nil];
//        //    self.listData=array;
//        
//        //按钮响应函数注册
//        [popBackButton addTarget:self action:@selector(popBack) forControlEvents:UIControlEventTouchUpInside];
//        [searchButton addTarget:self action:@selector(pushsearchViewController) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self UIInit];//界面初始化
//    [SelftableView registerClass:[SubscribeCell class] forCellReuseIdentifier:@"CustomCell"];
    
	// Do any additional setup after loading the view, typically from a nib.
//    NSArray *array=[[NSArray alloc]initWithObjects:@"新闻中心",@"学校要闻",@"综合新闻",@"学院动态",@"名师苑",@"银杏海",@"校园观察",@"媒体成电", nil];
//    self.listData=array;
    
    //按钮响应函数注册
    [self.popBackButton addTarget:self action:@selector(popBack) forControlEvents:UIControlEventTouchUpInside];
    [self.searchButton addTarget:self action:@selector(pushsearchViewController) forControlEvents:UIControlEventTouchUpInside];
    
    gesture=[[UIPanGestureRecognizer alloc]init];
    [gesture addTarget:self action:@selector(backGuesture:)];
    [self.view addGestureRecognizer:gesture];

    CGRect frame=CGRectMake(-lastview.size.width, 0, lastview.size.width, lastview.size.height);
    lastView=[[UIImageView alloc]initWithImage:lastview];
    [lastView setFrame:frame];
    [self.view addSubview:lastView];
    

    
  /*
    NSLog(@"%@",listData);
    NSLog(@"%@",CategoryIdArray);
    NSLog(@"%@",SubscribeStateArray);
    NSLog(@"");
   */ 
    
}




- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestufreRecognizer
{
    
	return gesture.state == UIGestureRecognizerStatePossible;
}

-(void)backGuesture:(UIPanGestureRecognizer*) sender
{
    switch (sender.state) {
        case UIGestureRecognizerStatePossible:
        {
            break;
        }
        case UIGestureRecognizerStateBegan:
        {
            FirstPosition=[sender locationInView:self.view];
            break;
        }
        case UIGestureRecognizerStateChanged:
        {
            CGPoint translation=[sender translationInView:self.view];
            if (abs((int)translation.y)*3 < translation.x)
            {
                CGPoint NowPosition=[sender locationInView:self.view];
                CGRect frame=self.view.frame;
                float Xmove=(NowPosition.x-FirstPosition.x);
                frame.origin.x+=Xmove;
                [self.view setFrame:frame];
            }
            break;
        }
        case UIGestureRecognizerStateEnded:
        {
            NSLog(@"lastview %f,%f",lastView.frame.origin.x,lastView.frame.size.width);
            if (self.view.frame.origin.x>back_width) {
                [UIView animateWithDuration:0.3f
                                      delay:0
                                    options:UIViewAnimationOptionCurveLinear
                                 animations:^{
                                     CGRect frame = self.view.frame;
                                     frame.origin.x = 320;
                                     [self.view setFrame:frame];
                                     
                                 }
                                 completion:^(BOOL finished) {
                                     [self.navigationController popViewControllerAnimated:NO];
                                 }
                 ];
            }
            else
            {
                [UIView animateWithDuration:0.3f
                                      delay:0
                                    options:UIViewAnimationOptionCurveLinear
                                 animations:^{
                                     CGRect frame = self.view.frame;
                                     frame.origin.x = 0;
                                     [self.view setFrame:frame];
                                     
                                 }
                                 completion:^(BOOL finished) {
                                     
                                 }
                 
                 ];
            }
            break;
        }
        case UIGestureRecognizerStateCancelled:
        {
            break;
        }
            
        default:
            break;
    }
    
}


-(void)viewDidDisappear:(BOOL)animated{
    if (SubscribeRequest){
        [SubscribeRequest clearDelegatesAndCancel];
        SubscribeRequest=nil;
    }
}


#pragma mark UI初始化代码
-(void)UIInit{
    UIImageView *popBackButtonImageView = [[UIImageView alloc ]initWithFrame:CGRectMake(11, 11, 22, 22)];
    [self.popBackButton addSubview:popBackButtonImageView];
    [popBackButtonImageView setImage:[UIImage imageNamed:@"back.png"]];
    UIImage *popBackButtonSelectedBackGroundImag=[UIImage imageNamed:@"按钮点击后的阴影"];
    [self.popBackButton setBackgroundImage:popBackButtonSelectedBackGroundImag forState:UIControlStateHighlighted];
    
    UIImageView *searchButtonImageView =[[UIImageView alloc]initWithFrame:CGRectMake(11, 11, 22, 22)];
    [self.searchButton addSubview:searchButtonImageView];
    [searchButtonImageView setImage:[UIImage imageNamed:@"search.png"]];
    UIImage *searchButtonSelectedBackGroundImage = [UIImage imageNamed:@"按钮点击后的阴影"];
    [self.searchButton setBackgroundImage:searchButtonSelectedBackGroundImage forState:UIControlStateHighlighted];
    
}

#pragma mark -
#pragma mark Table Data Source Methods

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return [self.listData count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CellIdentifier=@"CustomCell";
    SubscribeCell *cell=[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(cell==nil){
        
        cell=(SubscribeCell*) [[SubscribeCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.delegate=self;
        
    }
    
    [cell setButtonStatusWithSubscribed:[[self.SubscribeStateArray objectAtIndex:indexPath.row] boolValue]];
    cell.CurrentRow=indexPath.row;//告诉Cell当前处于第几行
    
    NSUInteger row=[indexPath row];
    cell.textLabel.text=[listData objectAtIndex:row];
  
    
//    UIButton *downButton=[[UIButton alloc]initWithFrame:CGRectMake(250, 11, 56, 26)];
//    [downButton setBackgroundImage:[UIImage imageNamed:@"_0002s_0000s_0002_Switch-(on)-Bg"] forState:UIControlStateNormal];
//    [downButton setTitle:@"订阅" forState:UIControlStateNormal];
//    [downButton.titleLabel setFont:[UIFont systemFontOfSize:14]];
//    [downButton setTag:indexPath.row];
//    [downButton addTarget:self action:nil forControlEvents:UIControlEventTouchUpInside];
//    [downButton setTitleColor:[UIColor colorWithRed:40.0/255.0 green:40.0/255.0 blue:40.0/255.0 alpha:1] forState:UIControlStateNormal];
//    [cell.contentView addSubview:downButton];
//    [downButton setBackgroundImage:[UIImage imageNamed:@"_0002s_0007s_0002_Switch-(on)-Bg"] forState:UIControlStateHighlighted];
//    [downButton setTitle:@"取消" forState:UIControlStateHighlighted];
    //[downButton setFrame:CGRectMake(230, 7, 80, 30)];
    
    return cell;
}

//-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    
//    return 44;
//}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    Subscribe_Detail *DetailController =[[Subscribe_Detail alloc]init];
    
//    NSUInteger row=(NSUInteger) indexPath.row;
    
 //   NSLog(@"%d",row);
    
    NSString *cataid=[DetailId objectAtIndex:indexPath.row];
    NSString *titlename=[listData objectAtIndex:indexPath.row];
    
    BOOL subscribe;
    //= (bool) [SubscribeStateArray objectAtIndex:indexPath.row];
    if ([[SubscribeStateArray objectAtIndex:indexPath.row]integerValue]==1) {
        subscribe=YES;
    }else subscribe=NO;
    
    NSLog(@"hello%@",SubscribeStateArray);
    [DetailController initStyle:subscribe :titlename :0 :cataid :@"SubscribeList"];
    
    
    
    ImageLocalized *file=[[ImageLocalized alloc]init];
    UIImage *thisView=[file captureView:self.view];
    DetailController.lastview=thisView;
    
    
    
    
    
    
    [self.navigationController pushViewController:DetailController animated:YES];
}




- (void)didReceiveMemoryWarning
{

    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark-
#pragma mark SubscribeCell Delegate

-(void)SubscribeCell:(SubscribeCell *)Nowcell :(NSInteger)buttonPressRowInTableView{

    if (SubscribeRequest){
        [SubscribeRequest clearDelegatesAndCancel];
        SubscribeRequest=nil;
    }

    BOOL currentState = [[self.SubscribeStateArray objectAtIndex:buttonPressRowInTableView]boolValue];
    NSString *URLString;
    if (currentState)URLString =[basePath stringByAppendingString:SubscribeCancelUrl];//如果已经订阅
    else URLString =[basePath stringByAppendingString:SubscribeCommitUrl];

    SubscribeRequest = [[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:URLString]];
    [SubscribeRequest setPostValue:[self.SubscribIdArray objectAtIndex:buttonPressRowInTableView] forKey:@"tag_id"];

    [SubscribeRequest startSynchronous];
    if (SubscribeRequest.responseStatusCode!=200){
        //reset Button state
        if (Nowcell.Subscribed)[Nowcell setButtonStatusWithSubscribed:NO];
        else [Nowcell setButtonStatusWithSubscribed:YES];
        //
        [JsonDataFormatting NetworkingError:@"连接失败"];
    }

 /*
    NSLog(@"%@",listData);
    NSLog(@"%@",CategoryIdArray);
    NSLog(@"%@",SubscribeStateArray);
    NSLog(@"");
*/
    


}


-(void)pushsearchViewController{
    SearchViewController *search = [[SearchViewController alloc]init];
    [Transition pushViewControllerFormBotton:self ViewController:search];
}

-(void)popBack{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)setNavTitle:(NSString *)title{
    UILabel *label = (UILabel*)[self.view viewWithTag:22];
    label.text=title;
}

@end
