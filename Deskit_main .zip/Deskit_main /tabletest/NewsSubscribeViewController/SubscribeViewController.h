//
//  SubscribeViewController.h
//  Deskit_beta
//
//  Created by Sway on 13-7-29.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import "SubscribeListViewController.h"
#import "ASIHTTPRequest.h"
#import "ASIHTTPRequestDelegate.h"
#import "ASIFormDataRequest.h"
#import "JsonDataFormatting.h"


@interface SubscribeViewController : SubscribeListViewController
{
    ASIFormDataRequest *listRequest;
    
}



@end
