//
//  ViewController.h
//  Order
//
//  Created by sjy on 13-6-12.
//  Copyright (c) 2013年 sjy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SubscribeCell.h"
#import "constant.h"
#import "JsonDataFormatting.h"
@interface SubscribeListViewController : UIViewController
<UITableViewDataSource,UITableViewDelegate,SubscribeCellDelegate>{

    
    UIPanGestureRecognizer *gesture;
    CGPoint FirstPosition;
    UIImageView *lastView;
    UIImage *lastview;
}
@property UIImage *lastview;


@property(nonatomic) NSArray *listData;//保存tablview 标题的数组
@property (nonatomic) NSArray *CategoryIdArray;
@property (nonatomic)NSArray *SubscribIdArray;//订阅需要链接的订阅id
@property(nonatomic)NSArray *SubscribeStateArray;
@property(nonatomic)NSArray *DetailId;




@property(nonatomic) IBOutlet UIButton *popBackButton;
@property(nonatomic) IBOutlet UIButton *searchButton;
@property (weak, nonatomic) IBOutlet UILabel *NavTitleLabel;
@property(nonatomic)   IBOutlet UITableView *SelftableView;
-(void)setNavTitle:(NSString *)title;
-(id)init;
@end
