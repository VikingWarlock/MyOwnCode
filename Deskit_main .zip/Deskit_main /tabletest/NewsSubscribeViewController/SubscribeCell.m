//
//  CustomCell.m
//  Order
//
//  Created by Sway on 13-6-21.
//  Copyright (c) 2013年 sjy. All rights reserved.
//

#import "SubscribeCell.h"
@interface SubscribeCell(){
    UIButton *downButton;
}

@end

@implementation SubscribeCell
@synthesize Subscribed;
@synthesize CurrentRow;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        Subscribed=NO;
        // Initialization code
        downButton=[[UIButton alloc]initWithFrame:CGRectMake(250, 11, 56, 26)];
        [downButton setBackgroundImage:[UIImage imageNamed:@"_0002s_0000s_0002_Switch-(on)-Bg"] forState:UIControlStateNormal];
[downButton setTitleColor:[UIColor colorWithRed:40.0/255.0 green:40.0/255.0 blue:40.0/255.0 alpha:1] forState:UIControlStateNormal];
        [downButton setTitle:@"订阅" forState:UIControlStateNormal];
        [downButton.titleLabel setFont:[UIFont systemFontOfSize:14]];
        [downButton addTarget:self action:@selector(SubscribeButtonPress) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:downButton];
        
        self.selectionStyle=UITableViewCellSelectionStyleGray;
        
        
        
        [self.textLabel setFont:[UIFont systemFontOfSize:15]];

        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setFrame:(CGRect)frame{
    [super setFrame:frame];
    frame.size.height=44;
}

-(void)SubscribeButtonPress{
    [self setButtonStatusWithSubscribed:Subscribed];

    if ([self.delegate respondsToSelector:@selector(SubscribeCell::)]){
        [self.delegate SubscribeCell:self :CurrentRow];
    }
    Subscribed=!Subscribed;
}

-(void)setButtonStatusWithSubscribed:(BOOL)subscribed{
    if(subscribed==YES){
    [downButton setBackgroundImage:[UIImage imageNamed:@"button-add-light"] forState:UIControlStateNormal];
    [downButton setTitle:@"取消" forState:UIControlStateNormal];
    [downButton setTitleColor:[UIColor colorWithRed:100.0/255.0 green:100.0/255.0 blue:100.0/255.0 alpha:1] forState:UIControlStateNormal];
    }
    else{
        [downButton setBackgroundImage:[UIImage imageNamed:@"_0002s_0000s_0002_Switch-(on)-Bg"] forState:UIControlStateNormal];
        [downButton setTitle:@"订阅" forState:UIControlStateNormal];
        [downButton setTitleColor:[UIColor colorWithRed:40.0/255.0 green:40.0/255.0 blue:40.0/255.0 alpha:1] forState:UIControlStateNormal];
    }
    
    
}

-(SubscribeCell*)initWithStyle:(UITableViewCellStyle)CellStyle reuseIdentifier:(NSString*)identifier delegate:(id<SubscribeCellDelegate>)Delegate{

    if([self initWithStyle:CellStyle reuseIdentifier:identifier]){//因为上面写有初始化函数 所以用self而不是super
        self.delegate=Delegate;
    }
    return self;
}

@end
