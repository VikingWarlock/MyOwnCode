//
//  SubscribeViewController.m
//  Deskit_beta
//
//  Created by Sway on 13-7-29.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import "SubscribeViewController.h"
#import "constant.h"

@interface SubscribeViewController ()

@end

@implementation SubscribeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
   // NSLog(@"I Need This");
    
    [self ListInit];
    
 //   NSArray *array=[[NSArray alloc]initWithObjects:@"新闻中心",@"学校要闻",@"综合新闻",@"学院动态",@"名师苑",@"银杏海",@"校园观察",@"媒体成电", nil];
 //   self.listData=array;
    self.NavTitleLabel.text=@"所有标签";
	// Do any additional setup after loading the view.
}



-(void) ListInit
{
    NSURL *url=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,@"/front/tag/current_list"]];
    listRequest=[ASIHTTPRequest requestWithURL:url];
    [listRequest setRequestMethod:@"POST"];
    [listRequest setDelegate:self];
    [listRequest startSynchronous];
    
    
    
    
    NSError *error;
    NSData *responseData = [listRequest responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
    
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        
        
        //        NSLog(@"%@",responseDictionary);
        
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"返回值出错");
            NSLog(@"%@",ResponseErrMsg);
            return ;
        }
        
    }
    
    NSArray *data=[responseDictionary objectForKey:@"data"];
    //  NSArray *list=[]
    
 //   NSLog(@"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
 //   NSLog(@"%@",data);
    
    NSMutableArray *temp1=[[NSMutableArray alloc]init];
    NSMutableArray *temp2=[[NSMutableArray alloc]init];
    NSMutableArray *temp3=[[NSMutableArray alloc]init];
    NSMutableArray *temp4=[[NSMutableArray alloc]init];
    int i;
    for (i=0;i<[data count];i++)
    {
        [temp1 addObject:[[data objectAtIndex:i] objectForKey:@"category_id"]];
        [temp2 addObject:[[data objectAtIndex:i] objectForKey:@"name"]];
        [temp3 addObject:[[data objectAtIndex:i] objectForKey:@"id"]];
        [temp4 addObject:[[data objectAtIndex:i] objectForKey:@"is_subscribe"]];
        
    }
    self.listData=temp2;
    self.CategoryIdArray=temp1;
    self.SubscribeStateArray=temp4;
    NSLog(@"%@",temp4);
    self.DetailId=temp3;
    
    
}


/*
-(void)requestFinished:(ASIHTTPRequest *)request{
    NSError *error;
    NSData *responseData = [request responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
    
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        
        
        //        NSLog(@"%@",responseDictionary);
        
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"返回值出错");
            return ;
        }
        
    }
    
    NSArray *data=[responseDictionary objectForKey:@"data"];
  //  NSArray *list=[]
    
    NSLog(@"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
    NSLog(@"%@",data);
    
    NSMutableArray *temp1=[[NSMutableArray alloc]init];
    NSMutableArray *temp2=[[NSMutableArray alloc]init];
    NSMutableArray *temp3=[[NSMutableArray alloc]init];
    NSMutableArray *temp4=[[NSMutableArray alloc]init];
    int i;
    for (i=0;i<[data count];i++)
    {
    [temp1 addObject:[[data objectAtIndex:i] objectForKey:@"category_id"]];
    [temp2 addObject:[[data objectAtIndex:i] objectForKey:@"name"]];
    [temp3 addObject:[[data objectAtIndex:i] objectForKey:@"id"]];
    [temp4 addObject:[[data objectAtIndex:i] objectForKey:@"is_subscribe"]];
        
    }
        self.listData=temp2;
        self.CategoryIdArray=temp1;
        self.SubscribeStateArray=temp4;
        self.SubscribIdArray=temp3;
}

*/


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
