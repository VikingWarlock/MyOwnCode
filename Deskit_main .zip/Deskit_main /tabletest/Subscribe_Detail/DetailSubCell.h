//
//  DetailSubCell.h
//  Deskit_beta
//
//  Created by viking warlock on 8/3/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JsonDataFormatting.h"
#import "ASIHTTPRequestDelegate.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"

#import "ImageLocalized.h"

//#import "InformationViewController.h"


@interface DetailSubCell : UITableViewCell<ASIHTTPRequestDelegate>
{
    BOOL ImageExist;
    ASIFormDataRequest *cellInfRequest;
    ASIFormDataRequest *ImageRequest;
    NSString *essay_id;

    NSString *title;
    NSString *content;
    NSString *date;
    NSString *source;
    NSString *description;
    NSString *pictureURL;

    NSArray *path;
    NSString *pathDocuments;
    

    NSDictionary *Selfdata;
  //  InformationViewController *Information;
    
}

@property (nonatomic,weak) IBOutlet UIImageView *Picture;
@property (nonatomic,weak) IBOutlet UILabel *Title;
@property (nonatomic,weak) IBOutlet UILabel *Content;
@property (nonatomic,strong) NSDictionary *Selfdata;
@property (nonatomic,strong) NSString  *essay_id;

/*
-(void) reloadCell;

-(void) reloadCell :(NSString*) IDnumber :(NSString*) InputContent :(NSString*) InputDescription :(BOOL)pictureExist :(NSString*) InputTitle :(NSString*) InputSource :(NSString*) InputDate;
*/
-(void)reloadCell :(NSDictionary*)detail :(NSString*) InputID;
-(void)setImageToCell :(UIImage*) image;
-(void)initFrame;
-(void)didSelectedOutLookChange;
-(void)settingAboutImage:(NSString*)PicUrl;
-(void)setup;
@end
