//
//  Information_Detail.h
//  Deskit_beta
//
//  Created by viking warlock on 9/13/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import "Subscribe_DetailViewController.h"

@interface Information_Detail : Subscribe_DetailViewController

@end
