//
//  Information_Detail.m
//  Deskit_beta
//
//  Created by viking warlock on 9/13/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import "Information_Detail.h"

@interface Information_Detail ()

@end

@implementation Information_Detail

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self loadingData];
    
    
    
//订阅按钮初始化
    
    SubscribeButton.hidden=NO;
    
    SubscribeButton=[UIButton buttonWithType:UIButtonTypeCustom];
    [SubscribeButton setFrame:CGRectMake(255, 5, 55, 33)];
    [SubscribeButton setImage:[UIImage imageNamed:@"TabBar中的订阅.png"] forState:UIControlStateNormal];
    [SubscribeButton setImage:[UIImage imageNamed:@"TabBar的订阅点击后.png"] forState:UIControlStateHighlighted];
    
    [SubscribeButton addTarget:self action:@selector(Subscribe:) forControlEvents:UIControlEventTouchUpInside];
    
    
    [TabBar addSubview:SubscribeButton];
    [self ButtonImageShow];
 
    //data init
    
    NSURL *url=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,@"/front/tag/current_detail"]];
    SubscribeRequest=[ASIFormDataRequest requestWithURL:url];
    [SubscribeRequest setRequestMethod:@"POST"];
    [SubscribeRequest setPostValue:self.selfID forKey:@"id"];
    [SubscribeRequest setDelegate:self];
    [SubscribeRequest setDidFinishSelector:@selector(SubscribeBool:)];
    [SubscribeRequest startAsynchronous];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
