//
//  TagCloud_Detail.m
//  Deskit_beta
//
//  Created by viking warlock on 9/13/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import "TagCloud_Detail.h"

@interface TagCloud_Detail ()

@end

@implementation TagCloud_Detail

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    //订阅按钮初始化

    if ([self.selfID intValue]<5) {
        SubscribeButton.hidden=YES;
    }else
    {SubscribeButton=[UIButton buttonWithType:UIButtonTypeCustom];
        [SubscribeButton setFrame:CGRectMake(255, 5, 55, 33)];
        [SubscribeButton setImage:[UIImage imageNamed:@"TabBar中的订阅.png"] forState:UIControlStateNormal];
        [SubscribeButton setImage:[UIImage imageNamed:@"TabBar的订阅点击后.png"] forState:UIControlStateHighlighted];
        
        [SubscribeButton addTarget:self action:@selector(Subscribe:) forControlEvents:UIControlEventTouchUpInside];
        
        
        [TabBar addSubview:SubscribeButton];
        [self ButtonImageShow];
        
        NSURL *url=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,@"/front/tag/current_detail"]];
        SubscribeRequest=[ASIFormDataRequest requestWithURL:url];
        [SubscribeRequest setRequestMethod:@"POST"];
        [SubscribeRequest setPostValue:self.selfID forKey:@"id"];
        [SubscribeRequest setDelegate:self];
        [SubscribeRequest setDidFinishSelector:@selector(SubscribeBool:)];
        [SubscribeRequest startAsynchronous];
        
}
//    [self loadingData];



    if ([self.selfID intValue]<5)
    {
        [self cataLoading];
    }else
    {
        [self loadingData];

    }
  
 // Do any additional setup after loading the view.
}


-(void)ListDownloadFinished:(ASIHTTPRequest *)request{
    NSError *error;
    NSData *responseData = [request responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
    
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        //        NSLog(@"%@",responseDictionary);
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"%@",ResponseErrMsg);
            NSLog(@"返回值出错");
            
            return ;
        }
    }
    
    // NSLog(@"%@",responseDictionary);
    
    
   
        NSDictionary *temp=[responseDictionary objectForKey:@"data"];
        NSArray *temp2=[temp objectForKey:@"data"];
        NSMutableArray *temp3=[[NSMutableArray alloc]init];
        int i;
        for (i=0;i<[temp2 count];i++)
        {
            [temp3 addObject:[[temp2 objectAtIndex:i]objectForKey:@"id"]];
        }
        tableViewData=temp3;

    [self API_init];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
