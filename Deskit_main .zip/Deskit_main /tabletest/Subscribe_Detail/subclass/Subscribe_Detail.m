//
//  Subscribe_Detail.m
//  Deskit_beta
//
//  Created by viking warlock on 9/13/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import "Subscribe_Detail.h"

@interface Subscribe_Detail ()

@end

@implementation Subscribe_Detail

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSLog(@"here");
    [self loadingData];
    
    //订阅按钮初始化

    SubscribeButton.hidden=YES;
    
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
