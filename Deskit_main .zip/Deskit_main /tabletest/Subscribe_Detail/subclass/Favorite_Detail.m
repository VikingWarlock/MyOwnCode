//
//  Favorite_Detail.m
//  Deskit_beta
//
//  Created by viking warlock on 9/13/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import "Favorite_Detail.h"

@interface Favorite_Detail ()

@end

@implementation Favorite_Detail

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
  
    
    //订阅按钮初始化

    SubscribeButton.hidden=YES;
    
    
    //data init
    
    SubscribeRequest = [[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:[basePath stringByAppendingString:MyFavoriteListUrl]]];
    //       [SubscribeRequest setDidFinishSelector:@selector(TabDownloadFinishes:)];
    [SubscribeRequest setDelegate:self];
    //        NSLog(@"%@",[ListIdArray objectAtIndex:index]);
    NSDictionary *list_query = [[NSDictionary alloc]initWithObjects:[[NSArray alloc]initWithObjects:[NSNumber numberWithInt:1],[NSNumber numberWithInt:20], nil] forKeys:[[NSArray alloc]initWithObjects:@"page",@"page_size", nil]];
    [SubscribeRequest setPostValue:list_query forKey:@"list_query"];
    [SubscribeRequest setDidFinishSelector:@selector(ListDownloadFinished:)];
    
    
    [SubscribeRequest startAsynchronous];
    
	// Do any additional setup after loading the view.
}




-(void)ListDownloadFinished:(ASIHTTPRequest *)request{
    NSError *error;
    NSData *responseData = [request responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
    
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        //        NSLog(@"%@",responseDictionary);
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"%@",ResponseErrMsg);
            NSLog(@"返回值出错");
            
            return ;
        }
    }
    
    // NSLog(@"%@",responseDictionary);
    
    
        NSDictionary *temp=[responseDictionary objectForKey:@"data"];
        NSArray *temp2=[temp objectForKey:@"data"];
        NSMutableArray *temp3=[[NSMutableArray alloc]init];
        int i;
        for (i=0;i<[temp2 count];i++)
        {
            [temp3 addObject:[[temp2 objectAtIndex:i]objectForKey:@"id"]];
        }
        tableViewData=temp3;
    
    [self API_init];
   }




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
