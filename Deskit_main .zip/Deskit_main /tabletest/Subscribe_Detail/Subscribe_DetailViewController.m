//
//  ViewController.m
//  Subscribe_Detail
//
//  Created by Sway on 13-6-22.
//  Copyright (c) 2013年 Sway. All rights reserved.
//

#import "Subscribe_DetailViewController.h"
#import "InformationViewController.h"
#import "constant.h"


@interface Subscribe_DetailViewController ()

@end

@implementation Subscribe_DetailViewController
@synthesize Subscribed;
@synthesize TabBarTitle;
@synthesize selfID;
@synthesize From;
@synthesize IfNil;
@synthesize lastview;

-(void)unloadThisView
{
    [self RequestCancel:tableRequest];
    [self RequestCancel:cellRequest];
    [self RequestCancel:ImageRequest];
    [self RequestCancel:didSubscribe];
    
}

-(void)dealloc
{

    [self unloadThisView];
    tableRequest=nil;
    cellRequest=nil;
    ImageRequest=nil;
    didSubscribe=nil;
    
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    path=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    pathDocuments=[path objectAtIndex:0];

    self.view=[[[NSBundle mainBundle]loadNibNamed:@"Subscribe_DetailViewController" owner:self options:NULL]lastObject];
    
    gesture=[[UIPanGestureRecognizer alloc]init];
    [gesture addTarget:self action:@selector(backGuesture:)];
    [self.view addGestureRecognizer:gesture];
    
    tableViewData=[[NSMutableArray alloc]init];
    

    NSLog(@"Subscrible_DetailViewController.m loaded");
    TabBarTitle.text=Title;
    
    [SelfTableView setDelegate:self];
    [SelfTableView setDataSource:self];
//    [SelfTableView registerClass:[SubCell class] forCellReuseIdentifier:@"ImageCell"];
//    [SelfTableView registerClass:[SubCell class] forCellReuseIdentifier:@"NoImageCell"];
  
    CGRect frame=CGRectMake(-lastview.size.width, 0, lastview.size.width, lastview.size.height);
    lastView=[[UIImageView alloc]initWithImage:lastview];
    [lastView setFrame:frame];
    [self.view addSubview:lastView];
    


}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestufreRecognizer
{
    
	return gesture.state == UIGestureRecognizerStatePossible;
}

-(void)backGuesture:(UIPanGestureRecognizer*) sender
{
    switch (sender.state) {
        case UIGestureRecognizerStatePossible:
        {
            break;
        }
        case UIGestureRecognizerStateBegan:
        {
            FirstPosition=[sender locationInView:self.view];
            break;
        }
        case UIGestureRecognizerStateChanged:
        {
            CGPoint translation=[sender translationInView:self.view];
            if (abs((int)translation.y)*3 < translation.x)
            {
                CGPoint NowPosition=[sender locationInView:self.view];
                CGRect frame=self.view.frame;
                float Xmove=(NowPosition.x-FirstPosition.x);
                frame.origin.x+=Xmove;
                [self.view setFrame:frame];
            }
            break;
        }
        case UIGestureRecognizerStateEnded:
        {
            NSLog(@"lastview %f,%f",lastView.frame.origin.x,lastView.frame.size.width);
            if (self.view.frame.origin.x>back_width) {
                [UIView animateWithDuration:0.3f
                                      delay:0
                                    options:UIViewAnimationOptionCurveLinear
                                 animations:^{
                                     CGRect frame = self.view.frame;
                                     frame.origin.x = 320;
                                     [self.view setFrame:frame];
                                     
                                 }
                                 completion:^(BOOL finished) {
                                     [self.navigationController popViewControllerAnimated:NO];
                                 }
                 ];
            }
            else
            {
                [UIView animateWithDuration:0.3f
                                      delay:0
                                    options:UIViewAnimationOptionCurveLinear
                                 animations:^{
                                     CGRect frame = self.view.frame;
                                     frame.origin.x = 0;
                                     [self.view setFrame:frame];
                                     
                                 }
                                 completion:^(BOOL finished) {
                                     
                                 }
                 
                 ];
            }
            break;
        }
        case UIGestureRecognizerStateCancelled:
        {
            break;
        }
            
        default:
            break;
    }
    
}

-(void)SubscribeBool :(ASIFormDataRequest*)request
{
    NSError *error;
    NSData *responseData = [request responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
    
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        //        NSLog(@"%@",responseDictionary);
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"%@",ResponseErrMsg);
            NSLog(@"返回值出错");
            
            return ;
        }
    }
    
    NSLog(@"%@",responseDictionary);
    NSDictionary *temp1=[responseDictionary objectForKey:@"data"];
    BOOL subscribe=[[temp1 objectForKey:@"is_subscribe"]boolValue];
    
    Subscribed=subscribe;
    
    NSLog(@"%d",subscribe);
    
    [self ButtonImageShow];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(void)initStyle:(BOOL)subscribe :(NSString *)title :(int)numbers :(NSString *)cata_id :(NSString*) from
{
    Title=title;
    Subscribed=subscribe;
    rows=numbers;
    selfID=cata_id;
    From=from;
  
}



-(void) loadingData
{
    NSURL *url=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,@"/front/tag/essay/current_list_id"]];
    tableRequest=[ASIFormDataRequest requestWithURL:url];
    [tableRequest setRequestMethod:@"POST"];
    [tableRequest setPostValue:selfID forKey:@"tag_id"];
    [tableRequest setDidFinishSelector:@selector(ThisDownloadFinished:)];
    [tableRequest setDelegate:self];
    [tableRequest startAsynchronous];
}

-(void)cataLoading
{
    NSURL *url=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,ListDetailUrl]];
    tableRequest=[ASIFormDataRequest requestWithURL:url];
    [tableRequest setRequestMethod:@"POST"];
    [tableRequest setPostValue:selfID forKey:@"category_id"];
    NSDictionary *list_query = [[NSDictionary alloc]initWithObjects:[[NSArray alloc]initWithObjects:[NSNumber numberWithInt:1],[NSNumber numberWithInt:10], nil] forKeys:[[NSArray alloc]initWithObjects:@"page",@"page_size", nil]];
    [tableRequest setPostValue:list_query forKey:@"list_query"];
    [tableRequest setDidFinishSelector:@selector(CataList:)];
    [tableRequest setDelegate:self];
    [tableRequest startAsynchronous];
}



-(void)CataList:(ASIHTTPRequest *)request
{
    NSError *error;
    NSData *responseData = [request responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
    
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        //        NSLog(@"%@",responseDictionary);
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"%@",ResponseErrMsg);
            NSLog(@"返回值出错");
            
            return ;
        }
    }
    
    // NSLog(@"%@",responseDictionary);
    tableViewData=[[NSMutableArray alloc]init];
    NSDictionary *temp2=[[NSDictionary alloc]initWithDictionary:[responseDictionary objectForKey:@"data"]];
    NSArray *temp=[temp2 objectForKey:@"data"];
    NSDictionary *temp1;
    int i;
//    NSLog(@"%@",temp2);
    for (i=0;i<[temp count];i++)
    {
       // NSLog(@"");
        temp1=[temp objectAtIndex:i];
        [tableViewData addObject:[temp1 objectForKey:@"id"]];
    }
    
    [self API_init];
    
}


-(void)ThisDownloadFinished:(ASIHTTPRequest *)request{
    NSError *error;
    NSData *responseData = [request responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
    
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        //        NSLog(@"%@",responseDictionary);
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"%@",ResponseErrMsg);
            NSLog(@"返回值出错");
            
            return ;
        }
    }

   // NSLog(@"%@",responseDictionary);
  
    
        tableViewData=[responseDictionary objectForKey:@"data"];
   // NSLog(@"%@",tableViewData);
    [self API_init];
  }


-(void)API_init
{
    [SelfTableView reloadData];
 

}


//tableview相关数据


-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell=[self tableView:tableView cellForRowAtIndexPath:indexPath];
    return cell.frame.size.height;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [tableViewData count];
}





-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
   static NSString *CellReusableIdentifier=@"DetailCell";
    
   DetailSubCell  *cell=[tableView dequeueReusableCellWithIdentifier:CellReusableIdentifier];
        
    
    
    if (cell==nil){
        cell=[[DetailSubCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellReusableIdentifier];
       // NSLog(@"%@",tableViewData);
        cell.essay_id=[NSString stringWithFormat:@"%@",[tableViewData objectAtIndex:indexPath.row]];
        [cell setup];
    }
    
    return cell;
    
    
    
    
    
    
    /*
     
     name: /front/tag/essay/current_list_id ok
     input struct{
     tag_id int
     }
     output []essay
     
     */

    

}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    InformationViewController *infoController =[[InformationViewController alloc]init];
   
    
    //  information page初始化 2013-7-23 邢旻罡
    
    if (![From isEqualToString:@"Push"]) {
        
    
    DetailSubCell *cell=(DetailSubCell*)[tableView cellForRowAtIndexPath:indexPath];
    if (cell) {
        
        [self unloadThisView];
        [infoController initStyle2:cell.Selfdata :[[tableViewData objectAtIndex:indexPath.row]integerValue]];
        ImageLocalized *file=[[ImageLocalized alloc]init];
        UIImage *thisView=[file captureView:self.view];
        infoController.lastview=thisView;
        
    [self.navigationController pushViewController:infoController animated:YES];
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    }
    }
}






- (IBAction)popBack:(id)sender {
    [self unloadThisView];
    [self.navigationController popViewControllerAnimated:YES];


}
- (void)Subscribe:(UIButton *)sender {
    
    NSURL *url;
    if (Subscribed)
    
    {
        url=[NSURL URLWithString:[basePath stringByAppendingString:SubscribeCancelUrl]];
    }else
        url=[NSURL URLWithString:[basePath stringByAppendingString:SubscribeCommitUrl]];
    
    didSubscribe=[ASIFormDataRequest requestWithURL:url];
    [didSubscribe setRequestMethod:@"POST"];
    [didSubscribe setPostValue:selfID forKey:@"tag_id"];
    [didSubscribe setDelegate:self];
    [didSubscribe setDidFinishSelector:@selector(changeButtonImage:)];
    [didSubscribe startAsynchronous];
    
//    [self changeButtonImage];//订阅按钮点击后的响应效果
    

    
}


-(void)RequestCancel:(ASIHTTPRequest*)request
{
    [request setDelegate:nil];
    [request clearDelegatesAndCancel];
   // [request dealloc];

}


-(void)changeButtonImage :(ASIFormDataRequest*) request
{
    NSError *error;
    NSData *responseData = [request responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
    
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        //        NSLog(@"%@",responseDictionary);
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"%@",ResponseErrMsg);
            NSLog(@"返回值出错");
            
            return ;
        }
    }
    
    if (Subscribed==YES){
        [SubscribeButton setFrame:CGRectMake(255, 5, 55, 33)];
        [SubscribeButton setImage:[UIImage imageNamed:@"TabBar中的订阅.png"] forState:UIControlStateNormal];
        [SubscribeButton setImage:[UIImage imageNamed:@"TabBar的订阅点击后.png"] forState:UIControlStateHighlighted];
        Subscribed=NO;
    }
    else{
        UIImage *image =[UIImage imageNamed:@"取消订阅.png"];
        [SubscribeButton setImage:image forState:UIControlStateNormal];
        [SubscribeButton setFrame:CGRectMake(241, 5, 69, 33)];
        [SubscribeButton setImage:[UIImage imageNamed:@"取消订阅时的阴影.png"] forState:UIControlStateHighlighted];
        Subscribed=YES;
    }
    
}

-(void)ButtonImageShow{
    if (Subscribed==NO){
        [SubscribeButton setFrame:CGRectMake(255, 5, 55, 33)];
        [SubscribeButton setImage:[UIImage imageNamed:@"TabBar中的订阅.png"] forState:UIControlStateNormal];
        [SubscribeButton setImage:[UIImage imageNamed:@"TabBar的订阅点击后.png"] forState:UIControlStateHighlighted];
    }
    else{
        UIImage *image =[UIImage imageNamed:@"取消订阅.png"];
        [SubscribeButton setImage:image forState:UIControlStateNormal];
        [SubscribeButton setFrame:CGRectMake(241, 5, 69, 33)];
        [SubscribeButton setImage:[UIImage imageNamed:@"取消订阅时的阴影.png"] forState:UIControlStateHighlighted];
    }
    
}



@end
