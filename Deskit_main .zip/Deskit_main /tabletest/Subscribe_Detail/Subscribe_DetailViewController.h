//
//  ViewController.h
//  Subscribe_Detail
//
//  Created by Sway on 13-6-22.
//  Copyright (c) 2013年 Sway. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "SubCell.h"

#import "JsonDataFormatting.h"
#import "ASIHTTPRequestDelegate.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"


#import "DeskItCell_settings.h"
#import "DeskItCellLoadFile.h"

#import "DetailSubCell.h"

@interface Subscribe_DetailViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,DeskItCell_settingsDelegate,UIGestureRecognizerDelegate>{
    IBOutlet UITableView *SelfTableView;
    UIButton *SubscribeButton;
    IBOutlet UIView *TabBar;
    BOOL Subscribed;
 //   IBOutlet UILabel *TabBarTitle;
    int rows;
    int number;
    int PictureSumNumber;
    
    ASIFormDataRequest *tableRequest;
    ASIFormDataRequest *cellRequest;
    ASIFormDataRequest *ImageRequest;
    ASIFormDataRequest *SubscribeRequest;
    ASIFormDataRequest *didSubscribe;
    
    NSMutableArray *tableViewData;
    NSArray *tableRequireDownload;
    
    NSMutableDictionary *tableDataInFile;  //和外部文件有关的数据库
    NSDictionary *initTableInFile;
    NSMutableDictionary *imageDictionary;
    
    
    NSString *From;
    NSString *Title;
  //  NSString *selfID;
    
    
    NSArray*path;
    NSString *pathDocuments;
    
    UIPanGestureRecognizer *gesture;
    CGPoint FirstPosition;
    UIImageView *lastView;
    UIImage *lastview;
}
@property UIImage *lastview;


@property BOOL Subscribed;
@property (nonatomic,weak) IBOutlet UILabel *TabBarTitle;
@property (nonatomic,strong) NSString *selfID;
@property (nonatomic,strong) NSString *From;
@property (nonatomic,weak) IBOutlet UILabel *IfNil;
-(void) initStyle :(BOOL)subscribe :(NSString*)title :(int)numbers :(NSString*)cata_id :(NSString*)from;
-(void)API_init;
-(void) loadingData;
-(void) cataLoading;
-(void)ButtonImageShow;
-(void)SubscribeBool :(ASIFormDataRequest*)request;

@end
