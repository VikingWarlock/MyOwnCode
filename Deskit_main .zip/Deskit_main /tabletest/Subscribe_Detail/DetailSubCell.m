//
//  DetailSubCell.m
//  Deskit_beta
//
//  Created by viking warlock on 8/3/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import "DetailSubCell.h"
#import "constant.h"



@implementation DetailSubCell


@synthesize Content;
@synthesize Title;
@synthesize Picture;
@synthesize essay_id;
@synthesize Selfdata;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self=[[[NSBundle mainBundle]loadNibNamed:@"DetailCell" owner:self options:NULL]lastObject];
        
  
        
    }
  /*
    [Title addSubview:self];
    [Content addSubview:self];
    [Picture addSubview:self];
   */
   path=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    pathDocuments=[path objectAtIndex:0];
    
    
    
    return self;
}


-(void)initFrame
{
    [Title setFrame:CGRectMake(12, 12, 292, 16)];
    [Content setFrame:CGRectMake(12, 30, 292, 31)];

    [Picture setHidden:YES];
    [super setFrame:self.frame];

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    
    
    
    // Configure the view for the selected state
}


-(void)didSelectedOutLookChange
{
/*
    self.Title.textColor=[UIColor grayColor];
    self.Content.textColor=[UIColor grayColor];
 */
    
 //Content.text=@"hello";
    [self.Title setTextColor:[UIColor grayColor]];
    [self.Content setTextColor:[UIColor grayColor]];
    self.Title.alpha=0.5;
    self.Content.alpha=0.5;
    
}




-(void) DownloadCellDataStart
{
    /*
            NSMutableDictionary *write=[[NSMutableDictionary alloc]init];
        [write setObject:tableDataInFile forKey:@"Detail"];
        
        if([write writeToFile:[NSString stringWithFormat:@"%@/%@",pathDocuments,@"Detail.plist"] atomically:YES])
            NSLog(@"Detail.plist succeed"); else NSLog(@"fail");
        number=0;
        [self EachCellImageDownload];
        return;
    */
    
 //   NSString *essayID=[tableRequireDownload objectAtIndex:number];
    NSURL *url=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,EssayDetail]];
    cellInfRequest=[ASIFormDataRequest requestWithURL:url];
    [cellInfRequest setRequestMethod:@"POST"];
    [cellInfRequest setDidFinishSelector:@selector(cellFinished:)];
    [cellInfRequest setDelegate:self];
    [cellInfRequest setPostValue:essay_id forKey:@"id"];
    [cellInfRequest startAsynchronous];
    
}

-(void)cellFinished:(ASIFormDataRequest*)request
{
    NSError *error;
    NSData *responseData = [request responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
    
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        //        NSLog(@"%@",responseDictionary);
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"%@",ResponseErrMsg);
            NSLog(@"返回值出错");
            
            return ;
        }
    }
    
    NSDictionary *data=[responseDictionary objectForKey:@"data"];
    NSLog(@"%@\n\n\n\n",data);
    NSDictionary *essay=[data objectForKey:@"essay"];
    NSLog(@"%@\n\n\n\n",essay);
    
    NSMutableDictionary *item=[[NSMutableDictionary alloc]init];
    [item setObject:[essay objectForKey:@"source"] forKey:@"source"];
    [item setObject:[essay objectForKey:@"content"] forKey:@"content"];
    [item setObject:[essay objectForKey:@"description"] forKey:@"description"];
    [item setObject:[essay objectForKey:@"publish_date"] forKey:@"source"];
    [item setObject:[essay objectForKey:@"title"] forKey:@"title"];
    [item setObject:[essay objectForKey:@"thumb"] forKey:@"pictureURL"];
    
    ImageLocalized *file=[[ImageLocalized alloc]init];
    [file addDataToFile:item forKey:essay_id FileName:@"Detail.plist"];
    [self reloadCell:[[NSDictionary alloc]initWithDictionary:item] :essay_id];
    
    
    //[tableDataInFile setValue:item forKey:[NSString stringWithFormat:@"%@",[tableRequireDownload objectAtIndex:number]]];
    
    
}


-(void)setup
{
  
    ImageLocalized *file=[[ImageLocalized alloc]init];
    [self initFrame];
    Title.text=@"";
    Content.text=@"";
    NSDictionary *data=[file readNSDictionary:@"Detail.plist" :self.essay_id ];
    if (data) {
        [self reloadCell:data :essay_id];
    }else
    {
        [self DownloadCellDataStart];
    }
    
}


-(void)reloadCell:(NSDictionary *)detail :(NSString*) InputID
{
   
 
    
    NSDictionary *data=[[NSDictionary alloc]initWithDictionary:detail];
    
    
    essay_id=InputID;
  //  NSLog(@"%d",[data count]);
    
    if (data && [data count]>0) {
    Selfdata=[[NSDictionary alloc]initWithDictionary: data];
    pictureURL=[detail objectForKey:@"pictureURL"];
    content=[detail objectForKey:@"content"];
    description=[detail objectForKey:@"description"];
    title=[detail objectForKey:@"title"];
    }
    
        
    
    Content.text=description;
    Title.text=title;
    
        
    [self initFrame];
    if ([pictureURL length]>0) {
        [self settingAboutImage:pictureURL];
    }
  //  [self setContainImageViewState:ImageExist];

}



-(void)settingAboutImage :(NSString *)PicUrl
{
    ImageLocalized *file=[[ImageLocalized alloc]init];
    if ((!pictureURL)||[pictureURL length]<=0) {
        return;
    }
    UIImage *image;
    image=[file LoadPicById:essay_id DataBaseFileName:@"picMatch.plist"];
    if (image) {
        [self setImageToCell:image];
    }else
    {
        //NSURL *url=[NSURL URLWithString:<#(NSString *)#>]
        NSLog(@"picURL is %@",pictureURL);
        ImageRequest =[[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString: pictureURL]];
        [ImageRequest setDidFinishSelector:@selector(ImageDownloadFinished:)];
        [ImageRequest setDelegate:self];
        [ImageRequest setRequestMethod:@"GET"];
        [ImageRequest startAsynchronous];

    
    }

}


-(void)ImageDownloadFinished:(ASIFormDataRequest*)request{
    NSData *DownloadData =[request responseData];
    if ([request responseStatusCode]!=200){
        NSLog(@"%d",[request responseStatusCode]);
        return;
    }
    UIImage * image =[[UIImage alloc]init];
    image=[UIImage imageWithData:DownloadData];
    
    /*
    if ([UIImagePNGRepresentation(image) writeToFile:[NSString stringWithFormat:@"%@/img/%d",pathDocuments,++PictureSumNumber] atomically:YES])
    {
        NSLog(@"picture succeed");
        [imageDictionary setValue:[NSString stringWithFormat:@"%@/img/%d",pathDocuments,PictureSumNumber] forKey:[ NSString stringWithFormat:@"%@",[tableViewData objectAtIndex:number]]];
        
        NSMutableDictionary *temp=[[NSMutableDictionary alloc]init];
        [temp setValue:imageDictionary forKey:@"data"];
        [temp setValue:[NSNumber numberWithInt: PictureSumNumber] forKey:@"amount"];
        if([temp writeToFile:[NSString stringWithFormat:@"%@/picMatch.plist",pathDocuments] atomically:YES])
        {NSLog(@"picMatch.plist succeed");}
    }
    else NSLog(@"fail");
    
    */
    ImageLocalized *file=[[ImageLocalized alloc]init];
    [file addPic:image URL_Address:[NSString stringWithString:pictureURL] DataBaseFileName:@"picMatch.plist" FileNameDetail:essay_id];
    
    [self setImageToCell:image];

}
-(void)setImageToCell:(UIImage *)image
{
    
    if (image){
//    NSLog(@"before,%f,%f",Title.frame.size.width,Title.frame.size.height);
    [Title setFrame:CGRectMake(12,12,241,16)];
//    NSLog(@"after,%f,%f",Title.frame.size.width,Title.frame.size.height);
    [Content setFrame:CGRectMake(12,30,241,31)];
    [Picture setHidden:NO];
    [Picture setImage:image];
    }
    else {
        [Title setFrame:CGRectMake(12, 12, 292, 16)];
        [Content setFrame:CGRectMake(12, 30, 292, 31)];
        [Picture setHidden:YES];
    }
    [super setFrame:self.frame];

}


-(void)dealloc{
    if (ImageRequest){
        [ImageRequest clearDelegatesAndCancel];
    }
    ImageRequest=nil;
    if (cellInfRequest) {
        [cellInfRequest clearDelegatesAndCancel];
    }
    cellInfRequest=nil;
}




/*
-(void)setFrame:(CGRect)frame{
    frame.origin.x-=130;
    frame.size.width=450;
    [super setFrame:frame];
}
*/


/*

-(void)reloadCell:(NSString *)IDnumber :(NSString *)InputContent :(NSString *)InputDescription :(BOOL)pictureExist :(NSString *)InputTitle :(NSString *)InputSource :(NSString *)InputDate
{
    essay_id=IDnumber;
    content=InputContent;
    description=InputDescription;
    ImageExist=pictureExist;
    title=InputTitle;
    
    source=InputSource;
    date=InputDate;
    
    
    Content.text=description;
    Title.text=title;
    
    

}


-(void)reloadCell
{
    
    

    NSLog(@"reload cell");
    NSLog(@"%@\n\n\n\n\n",self.essay_id);
    NSURL *url=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,@"/front/essay/detail"]];
    cellInfRequest=[ASIFormDataRequest requestWithURL:url];
    [cellInfRequest setRequestMethod:@"POST"];
    [cellInfRequest setPostValue:self.essay_id forKey:@"id"];
    [cellInfRequest startSynchronous];
    
    NSError *error;
    NSData *responseData = [cellInfRequest responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
    
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        //        NSLog(@"%@",responseDictionary);
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"%@",ResponseErrMsg);
            NSLog(@"返回值出错");
            
            return ;
        }
    }
    
    NSDictionary *data=[responseDictionary objectForKey:@"data"];
    NSLog(@"%@\n\n\n\n",data);
    NSDictionary *essay=[data objectForKey:@"essay"];
    NSLog(@"%@\n\n\n\n",essay);
    
    source=[essay objectForKey:@"source"];
    content=[essay objectForKey:@"content"];
    description=[essay objectForKey:@"description"];
    data=[essay objectForKey:@"publish_date"];
    pictureURL=[essay objectForKey:@"thumb"];
    title=[essay objectForKey:@"title"];
    
    Content.text=description;
    Title.text=title;
    
    
    
    if ([pictureURL isEqualToString:@""]||pictureURL==NULL||pictureURL==nil||[pictureURL isEqualToString:@"nil"])  ImageExist=NO;
    else {
        ImageExist=YES;
        
        
        
            imageRequest =[[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString: pictureURL]];
          //  [imageRequest setDidFinishSelector:@selector(ImageDownloadFinished:)];
          //  [imageRequest setDelegate:self];
            [imageRequest setRequestMethod:@"GET"];
            [imageRequest startSynchronous];
       
        NSData *data =[imageRequest responseData];
        if ([imageRequest responseStatusCode]!=200){
            NSLog(@"%d",[imageRequest responseStatusCode]);
            return;
        }
        UIImage * image =[UIImage imageWithData:data];
        [self.Picture setImage:image];
        
    }
    
    
}
*/


@end
