//
//  DeskItCell_settings.h
//  tabletest
//
//  Created by vikingwarlock on 13-6-16.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CellSelectedButton.h"
#import "ASIFormDataRequest.h"
#import "ImageLocalized.h"

@class DeskItCell_settings;
@protocol DeskItCell_settingsDelegate <NSObject>
@optional
-(void)DeskItCell_settings:(DeskItCell_settings*)cell;
-(void)DeskItCell_settingsGoback:(DeskItCell_settings*)cell;


@end
@interface DeskItCell_settings : UITableViewCell<UIGestureRecognizerDelegate,ASIHTTPRequestDelegate>
{
    CGPoint beginPoint;
    CGPoint endPoint;
    bool SAshowed;
    bool showedChange;
    bool viewchange;
    bool shouldBegin;
    int direction;
    
}


//宽度是450
//@property (strong,nonatomic)  UIView *UnderButton;
@property (weak,nonatomic) IBOutlet UILabel *MainText;//正文
@property (weak,nonatomic) IBOutlet CellSelectedButton *ShareButton;//分享按钮
@property (weak,nonatomic) IBOutlet CellSelectedButton *AdmireButton;//赞按钮
@property (weak,nonatomic) IBOutlet UILabel *Title;//标题
@property (weak,nonatomic) IBOutlet UIImageView *FrontPicture;//右侧图片
@property (weak,nonatomic) IBOutlet UILabel *ShareNum;//分享数量
@property (weak,nonatomic) IBOutlet UILabel *AdmireNum;//赞数量
@property(nonatomic)NSInteger currentRow;//Cell当前Row
@property(nonatomic)NSInteger currentEssayId;


@property (nonatomic)bool SAshowed;
@property (nonatomic)bool ContainImage;

@property (strong,nonatomic) UIPanGestureRecognizer *TableViewCellGesture;

@property (nonatomic,assign)id<DeskItCell_settingsDelegate>delegate;
-(void) goback;
-(void)setContainImageViewState:(BOOL)isContainImage;
-(void)setImageWithUrl:(NSURL *)url imageArray:(NSMutableDictionary*)array index:(NSInteger)row;
@end
