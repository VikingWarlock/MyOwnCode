//
//  DeskItAccessablity.h
//  Deskit_beta
//
//  Created by viking warlock on 9/22/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeskItAccessablity : NSObject
{
    NSMutableArray *list;
}

-(NSString*)replace :(NSString*)source :(NSString*)with;
-(NSArray*)ImageList:(NSString*)source;

@end
