//
//  PushNum.m
//  Deskit_beta
//
//  Created by viking warlock on 9/2/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import "PushNum.h"

@implementation PushNum

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void)initStyle:(int)num
{
    UIImage *image=[[UIImage alloc]init];
    if (num<10) {
        image=[UIImage imageNamed:@"message-bg-1.png"];
    }else
    {
        image=[UIImage imageNamed:@"message-bg-2.png"];
    }
    CGRect frame=CGRectMake(0, 0, image.size.width*0.5, image.size.height*0.5);
    [self setFrame:frame];
    imageview=[[UIImageView alloc]init];
    [imageview setImage:image];
    [self addSubview:imageview];
    [imageview setFrame:frame];
    number=[[UILabel alloc]init];
    [number setTextAlignment:UITextAlignmentCenter];
    [number setText:[NSString stringWithFormat:@"%d",num]];
    [number setTextColor:[UIColor whiteColor]];
    [number setBackgroundColor:[UIColor clearColor]];
    [number setFont:[UIFont systemFontOfSize:10]];
    [self addSubview:number];
    [number setFrame:frame];
    

}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
