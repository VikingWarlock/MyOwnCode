//
//  DeskItAccessablity.m
//  Deskit_beta
//
//  Created by viking warlock on 9/22/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import "DeskItAccessablity.h"

@implementation DeskItAccessablity
-(NSString*)replace:(NSString *)source :(NSString *)with
{
    NSString *backup=source;
    
    [self replacesub:backup :0];
    return backup;
    
}


-(NSArray*)ImageList:(NSString *)source
{
    list=[[NSMutableArray alloc]init];
    
    
    
    [self replacesub:source :0];
    
    return list;
}
-(void)replacesub:(NSString*)source :(int)startPosition
{
    
    
    
    NSString*con=[source substringFromIndex:startPosition];
    NSRange start;
    NSRange backstart;
    
    start=[con rangeOfString:@"<img"];
    if (start.length<4) {
        return;
    }
    
    backstart=start;
    
    NSString *temp1=[con substringFromIndex:start.location];
    start=[temp1 rangeOfString:@"src=\""];
    backstart.location+=start.location;
    backstart.location+=start.length;
    NSString *temp2=[temp1 substringFromIndex:start.location+start.length];
    NSRange start2=[temp2 rangeOfString:@"\""];
    NSRange new;
    
    new.location=0;
    new.length=start2.location;
    NSString *temp3=[[NSString alloc]initWithString:[temp2 substringWithRange: new]];
    [list addObject:temp3];
    

    [self replacesub:source :backstart.location+backstart.length+startPosition];
    
}

@end
