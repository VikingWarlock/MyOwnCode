//
//  MySubscribeListViewController.h
//  Deskit_beta
//
//  Created by Sway on 13-7-28.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import "SubscribeListViewController.h"
#import "constant.h"
#import "ASIFormDataRequest.h"
#import "ASIHTTPRequestDelegate.h"
#import "JsonDataFormatting.h"
@interface MySubscribeListViewController : SubscribeListViewController<ASIHTTPRequestDelegate>

@end
