//
//  MySubscribeListViewController.m
//  Deskit_beta
//
//  Created by Sway on 13-7-28.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import "MySubscribeListViewController.h"

@interface MySubscribeListViewController (){
    ASIFormDataRequest *Srequest;
}

@end

@implementation MySubscribeListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    [self.NavTitleLabel setText:@" 我的订阅"];
    Srequest = [[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:[basePath stringByAppendingString:MySubscribeListUrl]]];
    [Srequest setDelegate:self];
    [Srequest startAsynchronous];

    
    // Do any additional setup after loading the view from its nib.
}

-(void)viewDidDisappear:(BOOL)animated{
    if (Srequest){
        [Srequest clearDelegatesAndCancel];
        Srequest=nil;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)requestFinished:(ASIHTTPRequest *)request{
    NSData * data = [request responseData];
    JsonDataFormatting *formater =[[JsonDataFormatting alloc]initWithJsonData:data];
    if (formater.state!=0){
        [JsonDataFormatting NetworkingError:@"连接失败"];
        return;
        
    }
    NSArray *resultDataArray = [formater getData];
//    NSLog(@"%@",resultDataArray);
    NSMutableArray * nameArray =[[NSMutableArray alloc]init];
    NSMutableArray * SubscribeIdArray = [[NSMutableArray alloc ]init];
    NSMutableArray * categoryIdArray =[[NSMutableArray alloc ]init];
    for (NSDictionary *item in resultDataArray){
        [nameArray addObject:[item objectForKey:@"name"]];
        [SubscribeIdArray addObject:[item objectForKey:@"id"]];
        [categoryIdArray addObject:[item objectForKey:@"category_id"]];
    }
    self.listData=nameArray;
    self.CategoryIdArray=categoryIdArray;

    self.DetailId=SubscribeIdArray;
    
//2013-8-12 上一行修改*******************************
    
    self.SubscribIdArray=SubscribeIdArray;
    
    //订阅状态全置为已订阅
    NSMutableArray *temp =[[NSMutableArray alloc]init];
    for (NSInteger i=0;i<[self.listData count];i++){
        [temp addObject:[NSNumber numberWithBool:YES]];
    }
    self.SubscribeStateArray=temp;
    
    
    [self.SelftableView reloadData];
}

-(void)dealloc
{
    if (Srequest) {
        [Srequest clearDelegatesAndCancel];
        Srequest=nil;
        
    }
}

@end
