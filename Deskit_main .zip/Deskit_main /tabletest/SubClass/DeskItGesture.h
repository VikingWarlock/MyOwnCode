//
//  DeskItGesture.h
//  Deskit_beta
//
//  Created by viking warlock on 9/19/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeskItGesture : UIPanGestureRecognizer

{
    UIPanGestureRecognizer *gesture;
    CGPoint FirstPosition;
    UIImageView *lastView;
    UIImage *lastview;

}

//不会使用…………

@end
