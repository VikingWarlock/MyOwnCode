//
//  PushNum.h
//  Deskit_beta
//
//  Created by viking warlock on 9/2/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PushNum : UIView
{
    UILabel *number;
    UIImageView *imageview;
    
}

-(void) initStyle :(int)num;

@end

