//
//  DeskItCellLoadFile.h
//  tabletest
//
//  Created by vikingwarlock on 13-6-16.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeskItCellLoadFile : NSObject
{
}
+(NSDictionary*) LoadFile:(NSString *) FileName;
+(void)WriteFile:(NSDictionary*)dictionary name:(NSString*)FileName;
+(BOOL)FileExist :(NSString*) FileName;

@end
