//
//  DeskItViewController.m
//  tabletest
//
//  Created by vikingwarlock on 13-6-14.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import "DeskItViewController.h"
#import "DeskItCell_settings.h"
#import "DeskItCellLoadFile.h"
#import <QuartzCore/QuartzCore.h>
#import "Transition.h"
//#import "NoTopNewsTableViewController.h"





@interface DeskItViewController ()
{
    BOOL isPaning;
    BOOL isLeftShow,isLeftDragging;
    BOOL isRightShow,isRightDragging;
    SGFocusImageFrame *_imageFrame;
    NewsCell *TopNewsCell;
    
    BOOL TopNewsExist;//TableView会以它来判断是否需要显示slider
    ASIFormDataRequest *baseRequest;
    ASIFormDataRequest *listRequest;
    
    
    //ListRequest
    BOOL firstConnected;
    ASIFormDataRequest *listSecondRequest;
    NSArray *ListNameArray;
    NSArray *ListIdArray;
    //
    
    //TableViewCell's Array
    //    NSMutableDictionary *CellsArray;
    NSMutableDictionary *DataSource_key;
    NSMutableDictionary *CellsImageArray;
    NSArray *CellsIdArray;
    //
    
    
    //CustomTabBar
    CustomTabBar *TabBar;
    //
    
    
    
    
    
}
@end

@implementation DeskItViewController

@synthesize lastMoved;
@synthesize NowMove;
@synthesize SlideTable;
@synthesize Main_Page;


-(void)viewWillAppear:(BOOL)animated{

    
//修复页面返回手势被锁定bug
    
    if (Main_Page.frame.origin.x<0) {
      //  NSLog(@"<0");
    }else
    {
    SlideTable.scrollEnabled=YES;
    SlideTable.userInteractionEnabled=YES;
    }
}

-(void)ScreenStyle
{
    if (ScreenFrame_iPhone.size.height>480) {
        self.view.frame=ScreenFrame_without_status_iphone;
        Main_Page.frame=ScreenFrame_without_status_iphone;
        NSLog(@"%f,%f,%f,%f",Main_Page.frame.origin.x,Main_Page.frame.origin.y,Main_Page.frame.size.width,Main_Page.frame.size.height);
        
        CGRect temp=SlideTable.frame;
        [SlideTable setFrame:CGRectMake(temp.origin.x, temp.origin.y, temp.size.width, temp.size.height+88)];
        temp=TabBar.frame;
        [TabBar setFrame:CGRectMake(temp.origin.x, temp.origin.y+88, temp.size.width, temp.size.height)];
    
    }

}


-(void)viewDidLoad
{
    [super viewDidLoad];
    
    [self CheckResource];
    
    
    path=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    pathDocuments=[path objectAtIndex:0];
    NowTag=[[NSNumber alloc]initWithInt:0];

    [self ScreenStyle];
    
#pragma mark 按钮初始化
    UIImageView *speechButtonImageView =[[UIImageView alloc]initWithFrame:CGRectMake(11, 11, 22, 22)];
    [speechButton addSubview:speechButtonImageView];
    [speechButtonImageView setImage:[UIImage imageNamed:@"speech.png"]];
    [speechButton setBackgroundImage:[UIImage imageNamed:@"icon40-pressed-bg.png"] forState:UIControlStateHighlighted];
    
    UIImageView *messageButtonImageView = [[UIImageView alloc]initWithFrame:CGRectMake(11, 11, 22, 22)];
    [messageButton addTarget:self action:@selector(Button_Slide) forControlEvents:UIControlEventTouchUpInside];//邢旻罡 2013-7-23
    
    [messageButton addSubview:messageButtonImageView];
    [messageButtonImageView setImage:[UIImage imageNamed:@"message.png"]];
    
    [messageButton setBackgroundImage:[UIImage imageNamed:@"icon40-pressed-bg.png"] forState:UIControlStateHighlighted];
    
#pragma mark 装载TableVIew数据
	// Do any additional setup after loading the view, typically from a nib.
  //  DataSource=[[DeskItCellLoadFile LoadFile:data_file_name]objectForKey:@"NewsInf"];
    ImageLocalized *file=[[ImageLocalized alloc]init];
    NSDictionary *localTemp=[[NSMutableDictionary alloc]initWithDictionary:[file readNSDictionary:@"Root.plist" :@"0"]] ;
    DataSource=[localTemp objectForKey:@"data"];
    
    
    
//    TopNewsExist=[[DataSource objectForKey:@"TopNewsExist"] boolValue];
    TopNewsExist=YES;
    
    
    CellsImageArray=[[NSMutableDictionary alloc]init];
    
    
#pragma mark 手势初始化
    lastMoved=nil;
    NowMove=nil;
    shouldBegin=NO;
    
    pan = [[UIPanGestureRecognizer alloc]init];
    [pan addTarget:self action:@selector(handlePan:)];
    [self.Main_Page addGestureRecognizer:pan];
    
    
#pragma mark 右滑菜单初始化
    [self settingViewInit];
#pragma mark 顶部新闻头条初始化
    //改为收到数据后初始化
    
//    [self setupNewsScrollViews];
    
    
    //这条是必须的
    TopNewsCell = [[NewsCell alloc]init];
    
    
//    [TopNewsCell addSubview:_imageFrame];
#pragma mark 底部TabBar初始化
    TabBar = [[CustomTabBar alloc]init];
    
    
    
    [self.Main_Page addSubview:TabBar];
    TabBar.delegate=self;
#pragma mark 下拉刷新初始化//////////////////////////////////////////////
    
    //CGRectMake(160.0f, 0.0f - SlideTable.bounds.size.height, self.view.frame.size.width, SlideTable.bounds.size.height)
    //原本语句
    
    if (_refreshHeaderView == nil) {
		
		EGORefreshTableHeaderView *view = [[EGORefreshTableHeaderView alloc] initWithFrame:CGRectMake(0.0f, 0.0f - SlideTable.bounds.size.height, self.view.frame.size.width, SlideTable.bounds.size.height)];
		view.delegate = self;
		[SlideTable addSubview:view];
		_refreshHeaderView = view;
		
	}
	
	//  update the last update date
	[_refreshHeaderView refreshLastUpdatedDate];
    
    
#pragma mark slider数据下载
    baseRequest = [[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:[basePath stringByAppendingString:SlideUrl]]];
    [baseRequest setDelegate:self];
    [baseRequest setDidFinishSelector:@selector(SlideRequestFinished:)];
    [baseRequest startAsynchronous];
    
#pragma mark list 数据下载
    listRequest = [[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:[basePath stringByAppendingString:ListUrl]]];
    [listRequest setDelegate:self];
    [listRequest setDidFinishSelector:@selector(DownLoadListFinished:)];
    firstConnected=YES;
    [listRequest startAsynchronous];
    
    
    
    
//月份修改
 
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    unsigned unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit;
    
    NSDateComponents *components = [calendar components:unitFlags fromDate:[NSDate date]];
    NSInteger iCurMonth = [components month];  //当前的月份
    NSMutableArray *monthList=[[NSMutableArray alloc]initWithObjects:
    @"一月",
    @"二月",
    @"三月",
    @"四月",
    @"五月",
    @"六月",
    @"七月",
    @"八月",
    @"九月",
    @"十月",
    @"十一月",
    @"十二月"
    , nil];
    MonthTitle.text=[[NSString alloc]initWithFormat:@"%@",[monthList objectAtIndex:iCurMonth-1]];
    
    
    
   // NSLog(@"");
    
    
  //  [self ScreenStyle];

    
    //推送
    [self notificationInit];
}


-(void)CheckResource
{
    NSArray *paths =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSLog(@"%@",documentsDirectory);
    NSFileManager *fileManage =[NSFileManager defaultManager];
    NSString *myDirectory =[documentsDirectory stringByAppendingPathComponent:@"img"];
    if( [fileManage createDirectoryAtPath:myDirectory withIntermediateDirectories:YES attributes:nil error:NULL])
        NSLog(@"succeed create folder");
    else
        NSLog(@"fail create folder");
        
//    BOOL ok= [fileManage createDirectoryAtPath:myDirectory attributes:nil error:nil];
}




-(void)viewWillDisappear:(BOOL)animated{
    if (baseRequest)[baseRequest clearDelegatesAndCancel];
    baseRequest=nil;
    if (listRequest)[listRequest clearDelegatesAndCancel];
    listRequest=nil;
    if (listSecondRequest)[listSecondRequest clearDelegatesAndCancel];
    listSecondRequest=nil;
    
}


//table view slide part has been written in the cell class
-(void) MoveCellAddition
{
    
    
    if (lastMoved==nil)
    {
        lastMoved=NowMove;
    }
    else
        if (lastMoved!=NowMove)
        {
            [lastMoved goback];
            lastMoved=NowMove;
        }
    
}


//slide view part

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(void)scrollHandlePan:(UIPanGestureRecognizer*) panParam
{
    if(isPaning)
    {
        [self handlePan:panParam];
    }
}



-(void)handlePan:(UIPanGestureRecognizer*) panParam
{
    
    if (panParam.state==UIGestureRecognizerStatePossible){
        
    }else
        
    {
        
        
        if (panParam.state==UIGestureRecognizerStateBegan)
        {
            beginPoint=[panParam locationInView:Main_Page];
            
        }
        if (beginPoint.x>160)
        {
        if(isLeftShow)
            {
                isLeftDragging = YES;
            }
            else if(isRightShow)
            {
                isRightDragging = YES;
            }
            else if(!isLeftDragging&&!isRightDragging)
            {
                float v_X = [panParam velocityInView:panParam.view].x;
                if(v_X>0)
                {
                    isLeftDragging = YES;
                }
                else
                {
                    isRightDragging = YES;
                }
            }
            CGPoint point = [panParam translationInView:panParam.view];
            [panParam setTranslation:CGPointZero inView:panParam.view];
            //   NSLog(@"%f",point.x);
            //  if (1)
            //  {
            float contentX = self.Main_Page.frame.origin.x;
            
            
            if(isRightDragging)
            {
                contentX += point.x;
                if(contentX < -view_slide_left)
                {
                    contentX = -view_slide_left;
                }
                else if(contentX > 0)
                {
                    contentX = 0;
                }
            }
            
            CGRect frame = self.Main_Page.frame;
            frame.origin.x = contentX;
            self.Main_Page.frame= frame;
            
            if(panParam.state == UIGestureRecognizerStateCancelled || panParam.state == UIGestureRecognizerStateEnded)
            {
                float v_X = [panParam velocityInView:panParam.view].x;
                float diff = 0;
                float finishedX = 0;
                
                if(isRightDragging)
                {
                    if(v_X > 0)
                    {
                        diff = contentX;
                        finishedX = 0;
                        isLeftShow = isRightShow = NO;
                    }
                    else
                    {
                        diff = contentX + view_slide_left;
                        finishedX = -view_slide_left;
                        isRightShow = YES;
                    }
                }
                //防止出现 抖动
                
                NSTimeInterval duration = MIN(0.3f,ABS(diff/v_X));
                [UIView animateWithDuration:duration
                                      delay:0
                                    options:UIViewAnimationOptionCurveLinear
                                 animations:^{
                                     CGRect frame = self.Main_Page.frame;
                                     frame.origin.x = finishedX;
                                     self.Main_Page.frame= frame;
                                 }
                                 completion:^(BOOL finished) {
                                     
                                     isPaning = NO;
                                     isLeftDragging = NO;
                                     isRightDragging = NO;
                                     beginPoint=CGPointMake(0, 0);
                                     
                                     
                                     
                                 }
                 
                 ];
                
                [self slideAvailable];
                
            }
            
        }
        
        
    }//else
    
}


-(void)slideAvailable
{
    if (self.Main_Page.frame.origin.x<0) {
        SlideTable.scrollEnabled=NO;
        SlideTable.userInteractionEnabled=NO;
    }
    else //if (frame.origin.x>=0)
    {
        SlideTable.scrollEnabled=YES;
        SlideTable.userInteractionEnabled=YES;
        
    }
    
    
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    touch=[[event allTouches] anyObject];
    PointX=[touch locationInView:self.view].x;
    
    
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    float contentX = self.Main_Page.frame.origin.x;
    int temp=[touch locationInView:self.view].x;
    touch = [[event allTouches] anyObject];
    
    if (contentX<0) {
        
        
        if((temp<=PointX+10)&&(temp<80))
        {
            
            isLeftDragging=YES;
            
            
            NSTimeInterval duration = 0.2f;
            [UIView animateWithDuration:duration
                                  delay:0
                                options:UIViewAnimationOptionCurveLinear
                             animations:^{
                                 CGRect frame = self.Main_Page.frame;
                                 frame.origin.x = 0;
                                 self.Main_Page.frame= frame;
                             }
                             completion:^(BOOL finished) {
                                 isPaning = NO;
                                 isLeftDragging = NO;
                                 isRightDragging = NO;
                                 
                                 SlideTable.scrollEnabled=YES;
                                 SlideTable.userInteractionEnabled=YES;
                                 
                             }];
            
        }
    }
    
}


///////////2013-7-23 added 邢旻罡
-(void) Button_Slide
{
    
    
    [UIView animateWithDuration:0.2f
                          delay:0
                        options:UIViewAnimationOptionCurveLinear
                     animations:^{
                         CGRect frame = self.Main_Page.frame;
                         frame.origin.x = -view_slide_left;
                         self.Main_Page.frame= frame;
                     }
                     completion:^(BOOL finished) {
                         SlideTable.scrollEnabled=NO;
                         SlideTable.userInteractionEnabled=NO;
                         
                     }];
    
    
}







//init part


- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
	CGPoint translation = [(UIPanGestureRecognizer*)gestureRecognizer translationInView:self.view];
    
    CGPoint pointint=[(UIPanGestureRecognizer*)gestureRecognizer locationInView:self.view];
    
    if (pointint.x<160) {
        return NO;
    }
    
    return fabs(translation.y) < fabs(translation.x);
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestufreRecognizer
{
    
	return pan.state == UIGestureRecognizerStatePossible;
}


-(IBAction)reload:(id)sender
{
    [lastMoved goback];
    DataSource=[[DeskItCellLoadFile LoadFile:@"test"]objectForKey:@"NewsInf"];
    [SlideTable reloadData];
    lastMoved=nil;
}






#pragma mark S设置界面
-(void)settingViewInit{
    //以下是示例代码
    
    UIView *SettingView =[[[NSBundle mainBundle] loadNibNamed:@"SettingBarButton" owner:self options:nil] lastObject];
    if (ScreenFrame_iPhone.size.height>480) {
        [SettingView setFrame:ScreenFrame_without_status_iphone];
    }
    
    
    [self.view insertSubview:SettingView belowSubview:Main_Page];
    [SubscribeButton addTarget:self action:@selector(subscribe) forControlEvents:UIControlEventTouchUpInside];
    //    [self.view setBackgroundColor:[UIColor colorWithRed:23.0/255.0 green:22.0/255.0 blue:22.0/255.0 alpha:1]];
    //    UIView *SettingNavBar = [[UIView alloc]initWithFrame:CGRectMake(44, 0, 320, 44)];
    //    [SettingNavBar setBackgroundColor:[UIColor colorWithRed:31.0/255 green:30.0/255 blue:30.0/255 alpha:1]];
    //    [self.view insertSubview:SettingNavBar belowSubview:Main_Page];
    //
    //    UIButton *setButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    //    [setButton setFrame:CGRectMake(44, 0, 60, 60)];
    //    [setButton setTitle:@"订阅" forState:UIControlStateNormal&UIControlStateHighlighted];
    //    [setButton addTarget:self action:@selector(subscribe) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    //添加要用到类似这个语句
    //    [self.view insertSubview:setButton belowSubview:Main_Page];
    //    [SettingNavBar addSubview:setButton ];
    //
    //    UIView *view =[[[NSBundle mainBundle ]loadNibNamed:@"SettingBarButton" owner:self options:nil] lastObject];
    //    [view setFrame:CGRectMake(0, 44, 320, 44)];
    //    [self.view insertSubview:view belowSubview:Main_Page];
    //
    
    
    
}

-(void)subscribe{
    TagCloudViewController *tagCloudController =[[TagCloudViewController alloc]init];
  
    ImageLocalized *file=[[ImageLocalized alloc]init];
    UIImage *thisView=[file captureView:self.view];
    tagCloudController.lastview=thisView;
    

    
    [self.navigationController pushViewController:tagCloudController animated:YES];
}



#pragma mark -
#pragma mark TableView部分
#pragma mark TableView Data Source
-(NSInteger)numberOfSectionsInTableView:(UITableView *) tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    //    return [[DataSource allKeys]count]+1;//[modify@卓越：6-20]给头条新闻加个cell的位置
    if (TopNewsExist)
        return [[DataSource allKeys]count];//[modify@Georry:7-1]字典里加了一个条目，所以不用＋1
    else return [[DataSource allKeys]count]-1;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //点击表格进入informationPage!!!
    int row=0;
  //   NSLog(@"%d",indexPath.row);
    
    if((TopNewsExist && indexPath.row>0)||(!TopNewsExist&&indexPath.row>=0))
    {
        if (TopNewsExist) {
    //        row--;
        }
        NSLog(@"%d",indexPath.row);
            DeskItCell_settings *cell= (DeskItCell_settings*) [tableView cellForRowAtIndexPath:indexPath];
                row+=cell.currentRow;

             //   NSNumber *essay_id=[CellsIdArray objectAtIndex:row];
        NSNumber *essay_id=[[NSNumber alloc]initWithInteger: cell.currentEssayId];
        
            InformationViewController *infoViewcontroller=[[InformationViewController alloc]init];
        [infoViewcontroller initStyleFromRoot:essay_id];
        ImageLocalized *file=[[ImageLocalized alloc]init];
        UIImage *thisView=[file captureView:self.view];
        infoViewcontroller.lastview=thisView;
        
        [self.navigationController pushViewController:infoViewcontroller animated:YES];
        
//            [self navigationController:infoViewcontroller animated:YES completion:nil];

    }
        


}



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier=@"MyCell";
    NSInteger row;
    if (TopNewsExist){
        if ((indexPath.row)==0) {
            return TopNewsCell;
        }
        row =indexPath.row-1;
        
    }
    else row=indexPath.row;
    DataSource_key=[DataSource objectForKey:[NSString stringWithFormat:@"%d",row]];
    
    DeskItCell_settings *cell=(DeskItCell_settings *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell==nil){
        cell=[[DeskItCell_settings alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.AdmireButton.CellSelectedDelegate=self;//设置好分享与暂的代理
        cell.ShareButton.CellSelectedDelegate=self;
        [cell.FrontPicture setImage:nil];
    }
    
 /////////////////////
//CurrentRow 指向错误
    
    cell.AdmireButton.CurrentCellRow=row;//这两条也是必须的
    cell.ShareButton.CurrentCellRow=row;
    
    
    [cell setCurrentRow:row];
 /////////////////////
    
    [cell.Title setText: [DataSource_key objectForKey:@"Title"] ];
    [cell.MainText setText:[DataSource_key objectForKey:@"MainText"]];
    cell.currentEssayId=[[DataSource_key objectForKey:@"id"]intValue];
    NSString *imageURL =[DataSource_key objectForKey:@"FrontPicture"];
    
    
    //    if ((cell.ContainImage==YES)&&(row<=[CellsImageArray count])){
    //        id pic =[CellsImageArray objectAtIndex:row];
    //        if ([pic isKindOfClass:[NSString class]])[cell.FrontPicture setImage:nil];
    //        else [cell.FrontPicture setImage:(UIImage*)pic];
    //    }
    BOOL downloaded=NO;
    if ([imageURL isEqualToString:@""]||imageURL==NULL||imageURL==nil||[imageURL isEqualToString:@"nil"])[cell setContainImageViewState:NO];
    else {
        
        NSDictionary *imagematch=[[NSDictionary alloc]initWithContentsOfFile:[pathDocuments stringByAppendingString:@"/picMatch.plist"]];
        if ([[imagematch allKeys]containsObject:@"data"]&&[[imagematch allKeys]containsObject:@"amount"]) {
           // int PictureSumNumber=[[imagematch objectForKey:@"amount"]intValue];
            NSDictionary *temp=[[NSDictionary alloc]initWithDictionary: [imagematch objectForKey:@"data"]];
            
            if ([[temp allKeys]containsObject:[NSString stringWithFormat:@"%@", [DataSource_key objectForKey:@"id"]]]) {
                [cell setContainImage:YES];
                
  //              NSLog(@"%@",[temp objectForKey:[NSString stringWithFormat:@"%@",[DataSource_key objectForKey:@"id"]]]);
                
               // UIImage *image=[[UIImage alloc]initWithContentsOfFile:[[temp objectForKey:[NSString stringWithFormat:@"%@",[DataSource_key objectForKey:@"id"]]]objectForKey:@"Path"]];
                ImageLocalized *file=[[ImageLocalized alloc]init];
                UIImage *image=[file LoadPicById:[DataSource_key objectForKey:@"id"] DataBaseFileName:@"picMatch.plist"];
                
                
                [cell.FrontPicture setImage:image];
                
                downloaded=YES;
                
            }else downloaded=NO;
            
        }
        else
        {
            downloaded=NO;
        }
        
        
        if (!downloaded)
        {
        [cell setContainImageViewState:YES];
        UIImage *image = [CellsImageArray objectForKey:[NSNumber numberWithInt:row]];
        if (!image)
            [cell setImageWithUrl:[NSURL URLWithString:imageURL] imageArray:CellsImageArray index:row];
        else {
            [cell.FrontPicture setImage:image];
        }
        }
    }
    
    
    
    
    //    [cell.FrontPicture setImage:[UIImage imageNamed:[DataSource_key objectForKey:@"FrontPicture"]]];
    
    
    
    //
    
#pragma cell的设置代码，等孙嘉玉写好cell后再用
    //    [[cell Title] setText:[DataSource_key objectForKey:@"Title"]];
    //    [[cell ShareNum] setText:[DataSource_key objectForKey:@"ShareNum"]];
    //    [[cell AdmireNum] setText:[DataSource_key objectForKey:@"AdmireNum"]];
    //    [[cell MainText] setText:[DataSource_key objectForKey:@"MainText"]];
    //    [[cell FrontPicture]setImage:[UIImage imageNamed:[DataSource_key objectForKey:@"FrontPicture"]]];
    
    
    
    
    cell.delegate=self;
    
    
    return cell;
    
}

-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if ((indexPath.row)==0&&TopNewsExist)return 160;
    return 74;
}

//-(void)tableView:(UITableView *) tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath*)indexPath
//{
//
//
//}



//-(float)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
//    return 160;
//}
//
//-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
//    return _imageFrame;
//}


//推送部分
-(void)notificationInit
{
    
    NSDictionary *setting=[[NSDictionary alloc]initWithContentsOfFile:[NSString stringWithFormat:@"%@/%@",pathDocuments,@"setting.plist"]];
    BOOL yesPush=[[setting objectForKey:@"PushButton"]intValue];
    if (yesPush) {
        

    
    NSURL *url=[NSURL URLWithString:[basePath stringByAppendingString:notificationNumber]];
    NotificationRequest=[ASIFormDataRequest requestWithURL:url];
    [NotificationRequest setRequestMethod:@"POST"];
    [NotificationRequest setDelegate:self];
    [NotificationRequest setDidFinishSelector:@selector(notificationShow:)];
    [NotificationRequest startAsynchronous];
    }
}


-(void)notificationShow :(ASIFormDataRequest*)request
{
    NSError *error;
    NSData *responseData = [request responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
    
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        //        NSLog(@"%@",responseDictionary);
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"%@",ResponseErrMsg);
            NSLog(@"返回值出错");
            
            return ;
        }
    }

    
    NSString *temp=[responseDictionary objectForKey:@"data"];
    int notificationNUM=[temp intValue];
    if (notificationNUM>0) {
        
    
    pushNumberLabel=[[PushNum alloc]init];
    [pushNumberLabel initStyle:notificationNUM];
  //  NSLog(@"%f,%f",push.frame.size.height,push.frame.size.width);
    [Main_Page  addSubview:pushNumberLabel];
    [pushNumberLabel setFrame:CGRectMake(265, 0, pushNumberLabel.frame.size.width , pushNumberLabel.frame.size.height)];
    
    //设置大小在此
    }
    
}





//

#pragma mark-
#pragma 底部TabBar部分
#pragma mark CustomTabBar Delegate
-(void)CustomTabBar:(UIButton *)button pressedButtonIndex:(NSInteger)index{
    NSDictionary *CellDataSource;
    
    
    
    //添加本地数据！
    NowTag=[[NSNumber alloc]initWithInteger:index];
    
    NSMutableDictionary *temp=[[NSMutableDictionary alloc]initWithContentsOfFile:[pathDocuments stringByAppendingString:@"/Root.plist"]];
    if (![temp isEqualToDictionary:[[NSMutableDictionary alloc]init] ]) {
        NSMutableDictionary *temp2=[temp objectForKey:[NSString stringWithFormat:@"%d", [NowTag intValue]]];
        DataSource=[temp2 objectForKey:@"data"];
        if (index==0)TopNewsExist=YES;
        else TopNewsExist=[[DataSource objectForKey:@"TopNewsExist"] boolValue];
        
        [SlideTable reloadData];
        
    }
    else
    {
        temp=[[NSMutableDictionary alloc]init];
        [temp writeToFile:[pathDocuments stringByAppendingString:@"/Root.plist"] atomically:YES];
    
    }
    
    
    
    
    if(listSecondRequest){
        [listSecondRequest clearDelegatesAndCancel];
        listSecondRequest=nil;
    }
  //  NSLog(@"%d",[DataSource isEqualToDictionary:[[NSDictionary alloc]init]]);
    
    if ((![[temp allKeys]containsObject:[NSString stringWithFormat:@"%d", [NowTag intValue]]])||[temp isEqualToDictionary:[[NSMutableDictionary alloc]init]])
    {
        switch (index) {
        case 0:{

            [self TabRequestStart:0];
        }
            break;
        case 1:{

            [self TabRequestStart:1];
        }
            break;
        case 2:{

            [self TabRequestStart:2];
        }
            break;
        case 3:{

            [self TabRequestStart:3];
        }
            break;
        default:
            break;
    }
    
    DataSource=CellDataSource;
    
    if (index==0)TopNewsExist=YES;
    else TopNewsExist=[[DataSource objectForKey:@"TopNewsExist"] boolValue];
    
    
    
    
    
    [SlideTable reloadData];
    }
    
}

//按Tab后对list的请求
-(void)TabRequestStart:(NSInteger)index{
    listSecondRequest = [[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:[basePath stringByAppendingString:ListDetailUrl]]];
    [listSecondRequest setDidFinishSelector:@selector(TabDownloadFinishes:)];
    [listSecondRequest setDelegate:self];
    [listSecondRequest setPostValue:[ListIdArray objectAtIndex:index] forKey:@"category_id"];
    NSLog(@"%@",[ListIdArray objectAtIndex:index]);
    NSDictionary *list_query = [[NSDictionary alloc]initWithObjects:[[NSArray alloc]initWithObjects:[NSNumber numberWithInt:1],[NSNumber numberWithInt:10], nil] forKeys:[[NSArray alloc]initWithObjects:@"page",@"page_size", nil]];
    [listSecondRequest setPostValue:list_query forKey:@"list_query"];
    [listSecondRequest startAsynchronous];
}



#pragma mark -
#pragma mark TableViewCell部分
#pragma mark DeskItCell_setttings Delegate


#pragma mark cell滑出
-(void)DeskItCell_settings:(DeskItCell_settings *)cell{
    //这些是示例代码
    [cell setBackgroundColor:[UIColor colorWithRed:221.0/255.0 green:221.0/255.0 blue:221.0/255.0 alpha:1]];
    //=====================
    
    NowMove=cell;
    [self MoveCellAddition];
    
//    NSString *LikeUrl = [basePath stringByAppendingString:LikeStateUrl];
//    NSString *FavoriteUrl = [basePath stringByAppendingString:FavoriteStateUrl];
//    NSString *favoriteTotalUrl =[basePath stringByAppendingString:FavoriteTotalUrl];
//    NSString *LikeTotal = [basePath stringByAppendingString:LikeTotalUrl];
    
//    UIActivityIndicatorView *flower = [[UIActivityIndicatorView alloc]initWithFrame:CGRectMake(130, 0, 130, 88)];
//    [cell addSubview:flower];
//    [flower startAnimating];
    
    //网络请求
 //   NSInteger currentRow = cell.currentRow;
    
    CellRequest = [[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:[basePath stringByAppendingString:ListDetailLeftUrl]]];
   // [CellRequest setPostValue:[CellsIdArray objectAtIndex:currentRow] forKey:@"id"];
    [CellRequest setPostValue:[NSString stringWithFormat:@"%d",cell.currentEssayId ] forKey:@"id"];
    [CellRequest startSynchronous];
    
    //数据解析
    NSError *error;
    NSData *data = [CellRequest responseData];
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
    dictionary = [dictionary objectForKey:@"data"];
    if (dictionary==nil){
        [JsonDataFormatting NetworkingError:@"获取cellletf数据失败"];
        return;
    }
//    NSLog(@"%@",[dictionary allKeys]);
    
    //设置左边小格
    BOOL Favorited = [[dictionary objectForKey:@"current_favorite"] boolValue];
    BOOL Liked = [[dictionary objectForKey:@"current_like"] boolValue];
    NSInteger FavoriteTotal = [[dictionary objectForKey:@"favorite_number"] intValue];
    NSInteger LikeTotal = [[dictionary objectForKey:@"like_number"] intValue];
    [cell.AdmireNum setText:[[NSString alloc]initWithFormat:@"%d",LikeTotal]];
    [cell.ShareNum setText:[[NSString alloc]initWithFormat:@"%d",FavoriteTotal]];
    [cell.AdmireButton setButtonState:Liked];
    [cell.ShareButton setButtonState: Favorited];
   // [cell setCurrentEssayId:[[CellsIdArray objectAtIndex:currentRow] intValue]];






    
    
    
//    NSDictionary * di = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
//    NSLog(@"CellLeft:%@",[[di objectForKey:@"data"] allKeys]);
//    [flower stopAnimating];
    
    
    
}

#pragma mark cell往回滑后会调用这个
-(void)DeskItCell_settingsGoback:(DeskItCell_settings *)cell{
    //代码写在这里===============
    //这些是示例代码
    NSLog(@"go back");
    [cell setBackgroundColor:[UIColor whiteColor]];
    //===============
}

/*
-(void)ScrollDidSelect:(int)PassInformation
{
    NSLog(@"succeed coming here");
    NSLog(@"%d",PassInformation);
}
*/


#pragma mark -
#pragma mark 顶部头条新闻部分
#pragma mark 代理 - 头条新闻点击事件
- (void)foucusImageFrame:(SGFocusImageFrame *)imageFrame didSelectItem:(SGFocusImageItem *)item{
    //    [imageFrame updateImage:NULL title:@"!!!!" forItemIndex:item.tag];//标题和图片的修改函数
    // [imageFrame update];

 //   NSLog(@"\n\n\n\n\n\n\n\n\n\n%@",DataSource);
    
 //   NSLog(@"%d",item.tag);
    
    NSDictionary *temp=[[NSDictionary alloc]initWithDictionary:[TopNewsData objectAtIndex:item.tag]];
    
    InformationViewController *informationPage;
    informationPage=[[InformationViewController alloc]init];
    [informationPage initStyle2:temp :[[temp objectForKey:@"id"]integerValue] ];
    [self.navigationController pushViewController:informationPage animated:YES];
    
}


#pragma mark 头条滑动栏的初始化函数，这个不是代理
- (void)setupNewsScrollViews:(NSInteger)SliderItemNum
{
//    SGFocusImageItem *item1 = [[SGFocusImageItem alloc] initWithTitle:@"Downloading" image:[UIImage imageNamed:@"banner1"] tag:0];
//    SGFocusImageItem *item2 = [[SGFocusImageItem alloc] initWithTitle:@"Downloading" image:[UIImage imageNamed:@"banner2"] tag:1] ;
//    SGFocusImageItem *item3 = [[SGFocusImageItem alloc] initWithTitle:@"Downloading" image:[UIImage imageNamed:@"banner3"] tag:2] ;
//    SGFocusImageItem *item4 = [[SGFocusImageItem alloc] initWithTitle:@"Downloading" image:[UIImage imageNamed:@"banner4"] tag:3] ;
    NSMutableArray *itemsArray=[[NSMutableArray alloc ]init];
    for (NSInteger i =0 ;i<SliderItemNum;i++){
        [itemsArray addObject:[[SGFocusImageItem alloc] initWithTitle:@"Dounloading" image:nil tag:i]];
    }
    _imageFrame = [[SGFocusImageFrame alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 160.0)
                                                  delegate:self focusImageItemsArray:itemsArray];
    //    [self.view addSubview:imageFrame];

    
    
}

#pragma mark -
#pragma mark 下拉更新部分
#pragma mark Data Source Loading / Reloading Methods

- (void)reloadTableViewDataSource{
	NSLog(@"正在更新");
	//  should be calling your tableviews data source model to reload
	//  put here just for demo
    
    [self TabRequestStart:[NowTag intValue]];
    
	_reloading = YES;
}

- (void)doneLoadingTableViewData{
	NSLog(@"更新完成");
	//  model should call this when its done loading
	_reloading = NO;
	[_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:SlideTable];
	
}



#pragma mark UIScrollViewDelegate Methods

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
	[_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
    
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    
	[_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
	
}



#pragma mark EGORefreshTableHeaderDelegate Methods

- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView*)view{
	
	[self reloadTableViewDataSource];
	[self performSelector:@selector(doneLoadingTableViewData) withObject:nil afterDelay:3.0];
	
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView*)view{
	
	return _reloading; // should return if data source model is reloading
	
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView*)view{
	
	return [NSDate date]; // should return date data source was last changed
	
}

- (void)viewDidUnload {
    SubscribeButton = nil;
    MonthTitle = nil;
    MyInfoButton = nil;
    MySubscribeButton = nil;
    MyFavoritesButton = nil;
    searchButton = nil;
    SettingButton = nil;
    [self RequestCancel:CellRequest];
    [self RequestCancel:NotificationRequest];
    [self RequestCancel:baseRequest];
    
    [super viewDidUnload];
}

#pragma mark -
#pragma mark SearchButton 搜索按钮
- (IBAction)searchButtonPress:(id)sender {

    
    

    [Transition pushViewControllerFormBotton:self ViewController:[[SearchViewController alloc]init]];
//    [self.navigationController pushViewController:[[SearchViewController alloc]init] animated:NO];
//    [self presentViewController:[[SearchViewController alloc]init] animated:YES completion:nil];
}

#pragma mark - 我的订阅 按钮事件
- (IBAction)PushMySubscribeList:(id)sender {
   MySubscribeListViewController *controller = [[MySubscribeListViewController alloc]initWithNibName:@"SubscribeListViewController" bundle:[NSBundle mainBundle]];
    ImageLocalized *file=[[ImageLocalized alloc]init];
    UIImage *thisView=[file captureView:self.view];
    controller.lastview=thisView;
    [self.navigationController pushViewController:controller animated:YES];

    
    //    [self presentViewController:[[SearchViewController alloc]init] animated:YES completion:nil];

 /*
    Subscribe_Detail *controller=[[Subscribe_Detail alloc]init];
    [self.navigationController pushViewController:controller animated:YES];
   */
}


//我的收藏 按钮事件
-(IBAction)PushMyFavoriteList:(id)sender
{
    Favorite_Detail *controll=[[Favorite_Detail alloc]init];
    [controll initStyle:NO :@"我的收藏" :0 :@"-1" :@"favorite"];
    ImageLocalized *file=[[ImageLocalized alloc]init];
    UIImage *thisView=[file captureView:self.view];
    controll.lastview=thisView;
    [self.navigationController pushViewController:controll animated:YES];

//    [self presentViewController:controll animated:YES completion:nil];

}


-(IBAction)PushMyinfo:(id)sender
{
    MyInfoViewController *controller =[[MyInfoViewController alloc]initWithNibName:@"MyInfoViewController" bundle:[NSBundle mainBundle]];
    ImageLocalized *file=[[ImageLocalized alloc]init];
    UIImage *thisView=[file captureView:self.view];
    controller.lastview=thisView;
   // [file addPic:thisView URL_Address:@"here" DataBaseFileName:@"temp.plist" FileNameDetail:@"none"];
    
    [self.navigationController pushViewController:controller animated:YES];
}


-(IBAction)PushNotification:(id)sender
{
    PushViewController *controller=[[PushViewController alloc]initWithNibName:@"Subscribe_DetailViewController" bundle:[NSBundle mainBundle]];
    controller.From=@"Push";
    ImageLocalized *file=[[ImageLocalized alloc]init];
    UIImage *thisView=[file captureView:self.view];
    controller.lastview=thisView;
    pushNumberLabel.hidden=YES;
    [self.navigationController pushViewController:controller animated:YES];
}


//setting push
-(IBAction)SettingPush:(id)sender
{
    SettingViewController *controller=[[SettingViewController alloc]init];
    ImageLocalized *file=[[ImageLocalized alloc]init];
    UIImage *thisView=[file captureView:self.view];
    controller.lastview=thisView;
    [self.navigationController pushViewController:controller animated:YES];

}


#pragma mark -
#pragma mark slider初始连接线程 Delegate

-(void)SlideRequestFinished:(ASIHTTPRequest *)request{
    
    NSData *responseData=[request responseData];
    JsonDataFormatting *formater=[[JsonDataFormatting alloc]initWithJsonData:responseData];
    if (formater.state!=0){
        
        [JsonDataFormatting NetworkingError];
        return;
    }
    
    NSArray *data =[formater getData];
    
    TopNewsData=[[NSArray alloc]initWithArray:data];
    
    
 //   NSLog(@"%@",data);
    NSInteger index=0;

    //初始化传入slider的数量
    [self setupNewsScrollViews:[data count]];
    
//    TopNewsCell = [[NewsCell alloc]init];
    [TopNewsCell addSubview:_imageFrame];
    
    for (NSDictionary *di in data){
        NSString *title=[di objectForKey:@"title"];
        [_imageFrame setTitle:title Index:index];
        NSString *imageUrl=[basePath stringByAppendingString:[di objectForKey:@"slide_image_url"]];
        [_imageFrame setImageWithUrl:[NSURL URLWithString:imageUrl] Index:index];
        index++;
        
        
    }
    //    NSLog(@"%@",data);
    [SlideTable reloadData];
}


#pragma mark - 栏目id与名字的下载
-(void)DownLoadListFinished:(ASIFormDataRequest*)request{
    NSData *responseData=[request responseData];
    JsonDataFormatting *fomater=[[JsonDataFormatting alloc]initWithJsonData:responseData];
    if (fomater.state!=0){
        NSLog(@"error code:%d",fomater.state);
        return;
    }
    
    NSArray *responseArray=[fomater getData];
    
    
    NSMutableArray *NameMutable,*IdMutable = [[NSMutableArray alloc]init];
    NSInteger index=0;
    for (NSDictionary *item in responseArray){
        NSString *name=[item objectForKey:@"name"];
        [NameMutable addObject:name];
        [TabBar setButtonTitle:name WithIndex:index];
        index++;
        [IdMutable addObject:[item objectForKey:@"id"]];
    }
    
    ListNameArray = [[NSArray alloc]initWithArray:NameMutable];
    ListIdArray = [[NSArray alloc]initWithArray:IdMutable];
    
    
    
    //第一次连接时，自动启动Tab得请求，如果时从其他页面返回则不再请求
    
    
    
    
    if (firstConnected){
        firstConnected=NO;
        NowTag=[[NSNumber alloc]initWithInteger:0];
        
        NSMutableDictionary *temp=[[NSMutableDictionary alloc]initWithContentsOfFile:[pathDocuments stringByAppendingString:@"/Root.plist"]];
        if (temp ) {
            NSMutableDictionary *temp2=[temp objectForKey:[NSString stringWithFormat:@"%d", [NowTag intValue]]];
            DataSource=[temp2 objectForKey:@"data"];
            if (index==0)TopNewsExist=YES;
            else TopNewsExist=[[DataSource objectForKey:@"TopNewsExist"] boolValue];
            
            [SlideTable reloadData];
            
        }
        else
        {
            temp=[[NSMutableDictionary alloc]init];
            [temp writeToFile:[pathDocuments stringByAppendingString:@"/Root.plist"] atomically:YES];
            [self TabRequestStart:0];

        }

        
    }
}

#pragma mark - 点击TabBar后进行响应数据的下载
-(void)TabDownloadFinishes:(ASIFormDataRequest*)request{
    //设置TableView的数组就行
    NSData *data =[request responseData];

    JsonDataFormatting *formater = [[JsonDataFormatting alloc]initWithJsonData:data];
    
    if(formater.state!=0){
        return;
    }
    NSArray *TableViewCellDataArray=[formater getData];
    DataSource=[self TransformToLocalData:TableViewCellDataArray WithIndex:[NowTag intValue]];
    
    NSMutableDictionary *temp=[[NSMutableDictionary alloc]init];
    [temp setObject:DataSource forKey:@"data"];
    NSMutableDictionary *temp2=[[NSMutableDictionary alloc]initWithContentsOfFile:[pathDocuments stringByAppendingString:@"/Root.plist"]];
    if (temp2) {
        NSLog(@"");
    }else
    {temp2=[[NSMutableDictionary alloc]init];}
    
    [temp2 setObject:temp forKey:[NSString stringWithFormat:@"%d", [NowTag intValue]]];
    [temp2 writeToFile:[pathDocuments stringByAppendingString:@"/Root.plist"] atomically:YES];
    
    
    [SlideTable reloadData];
}



//将服务器返回的数据转换成可写入plist的数据
-(NSMutableDictionary*)TransformToLocalData:(NSArray*)data WithIndex:(NSInteger)index{
    NSMutableDictionary *resultData= [[NSMutableDictionary alloc]init];
    
    if (index==0)[resultData setObject:[NSNumber numberWithBool:YES] forKey:@"TopNewsExist"];
    else
    
    [resultData setObject:[NSNumber numberWithBool:NO] forKey:@"TopNewsExist"];
    NSInteger i=0;
    
    NSMutableArray *CellsIdMutableArray = [[NSMutableArray alloc]init];
    
    for (NSDictionary *item in data){
        NSMutableDictionary *temp=[[NSMutableDictionary alloc]init];
        [temp setObject:[item objectForKey:@"title"] forKey:@"Title"];
        [temp setObject:[item objectForKey:@"description"] forKey:@"MainText"];
        [temp setObject:[item objectForKey:@"thumb"] forKey:@"FrontPicture"];
        [temp setObject:[item objectForKey:@"id"] forKey:@"id"];
        [temp setObject:[NSNumber numberWithBool:NO] forKey:@"Admired"];
        [temp setObject:[NSNumber numberWithBool:NO] forKey:@"Shared"];
        [temp setObject:@"0" forKey:@"AdmireNum"];
        [temp setObject:@"0" forKey:@"ShareNum"];

        [CellsIdMutableArray addObject:[item objectForKey:@"id"]];
        [resultData setObject:temp forKey:[[NSString alloc]initWithFormat:@"%d",i]];
        i++;
    }
    CellsIdArray = [[NSArray alloc]initWithArray:CellsIdMutableArray];
    return resultData;
}



//Request异步终止

-(void)RequestCancel:(ASIHTTPRequest*)request
{
    [request setDelegate:nil];
    [request clearDelegatesAndCancel];
    // [request dealloc];
    
}





@end
