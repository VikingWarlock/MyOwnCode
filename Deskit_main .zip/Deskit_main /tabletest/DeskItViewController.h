//
//  DeskItViewController.h
//  tabletest
//
//  Created by vikingwarlock on 13-6-14.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DeskItCell_settings.h"
#import "DeskItCellLoadFile.h"
#import "CustomTabBar.h"//底部的TabBar
#import "SGFocusImageFrame.h"//头条Scroll
#import "SGFocusImageItem.h"
#import "EGORefreshTableHeaderView.h"
#import "NewsCell.h"
#import "TagCloudViewController.h"
#import "SearchViewController.h"
#import "ASIHTTPRequestDelegate.h"
#import "ASIFormDataRequest.h"
#import "constant.h"
#import "JsonDataFormatting.h"
#import "MySubscribeListViewController.h"
#import "InformationViewController.h"
#import "MyInfoViewController.h"
#import "SettingViewController.h"

#import "PushViewController.h"
#import "Favorite_Detail.h"
//#import "Information_Detail.h"
#import "Subscribe_Detail.h"
#import "TagCloud_Detail.h"

#import "PushNum.h"



@class DeskItViewController;

@interface DeskItViewController : UIViewController<UITableViewDataSource,UITableViewDelegate, UIGestureRecognizerDelegate,UIScrollViewDelegate,DeskItCell_settingsDelegate,CustomTabBarDelegate,SGFocusImageFrameDelegate,EGORefreshTableHeaderDelegate,CellSelectedButtonDelegate,ASIHTTPRequestDelegate>
{
    IBOutlet UIButton *speechButton;
    IBOutlet UIButton *messageButton;
    NSDictionary *DataSource;
    __weak IBOutlet UIButton *SubscribeButton;
    
    UITouch *touch;
    int PointX;
    
    CGPoint beginPoint;
    UIView *topView;
    
    bool shouldBegin;
    bool SAshowed;
    UIPanGestureRecognizer* pan;
    __weak IBOutlet UILabel *MonthTitle;
    __weak IBOutlet UIButton *MyInfoButton;
    
    __weak IBOutlet UIButton *MySubscribeButton;
    
    __weak IBOutlet UIButton *MyFavoritesButton;
    PushNum *pushNumberLabel;
    __weak IBOutlet UIButton *searchButton;
    EGORefreshTableHeaderView *_refreshHeaderView;
    __weak IBOutlet UIButton *SettingButton;
	
	//  Reloading var should really be your tableviews datasource
	//  Putting it here for demo purposes
	BOOL _reloading;
    
    ASIFormDataRequest *CellRequest;
    ASIFormDataRequest *NotificationRequest;
    
    NSArray *TopNewsData;
    
    NSNumber *NowTag;
    
    
    NSArray*path;
    NSString *pathDocuments;
    

}

//@property (strong,nonatomic) UIPanGestureRecognizer *panGesture;
//@property (strong,nonatomic) UIPanGestureRecognizer *gesture;
@property (strong,nonatomic) IBOutlet UITableView *SlideTable;
@property (strong,nonatomic) IBOutlet UIView *Main_Page;
@property (strong,nonatomic) DeskItCell_settings *lastMoved;
@property (strong,nonatomic) DeskItCell_settings *NowMove;


-(void) MoveCellAddition;

@end
