//
//  SGFocusImageItem.h
//  SGFocusImageFrame
//
//  Created by Shane Gao on 17/6/12.
//  Copyright (c) 2012 Shane Gao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequestDelegate.h"
#import "ASIFormDataRequest.h"


@interface SGFocusImageItem : NSObject<ASIHTTPRequestDelegate>

@property (nonatomic, retain)  NSString     *title;
@property (nonatomic, retain)  UIImage      *image;
@property (nonatomic, assign)  NSInteger     tag;
@property(nonatomic,assign)UIImageView *button;//因为这最初设置是是UIButton


- (id)initWithTitle:(NSString *)title image:(UIImage *)image tag:(NSInteger)tag;
-(void)setImageWithUrl:(NSURL*)url;
@end
