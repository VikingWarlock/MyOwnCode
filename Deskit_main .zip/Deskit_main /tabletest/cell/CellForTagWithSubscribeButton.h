//
//  CellForTagWithSubscribeButton.h
//  Deskit_beta
//
//  Created by Sway on 13-9-21.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CellSelectedButton.h"
#import "ASIFormDataRequest.h"
@interface CellForTagWithSubscribeButton : UITableViewCell<SelectedButtonDelegate,ASIHTTPRequestDelegate>
@property (nonatomic)NSString *TagName;
@property (nonatomic)NSInteger TagId;
@property (nonatomic)SelectedButton *SubscribeButton;
@end
