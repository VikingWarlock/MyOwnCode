//
//  CellForTagWithSubscribeButton.m
//  Deskit_beta
//
//  Created by Sway on 13-9-21.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

//本类再进行initWithTagId方法后只需设置cell的点击效果即可

#import "CellForTagWithSubscribeButton.h"

#import "constant.h"
@interface CellForTagWithSubscribeButton(){
    //检查是否订阅的请求和订阅请求
    ASIFormDataRequest *Request,*SubscribeRequest;
}
@end

@implementation CellForTagWithSubscribeButton

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code

        [self addButton];
    }
    return self;
}

-(id)initWithTagId:(NSInteger)Id TagName:(NSString*)name{
    self=[super init];
    if (self){
        [self setTagName:name];
        [self setTagId:Id];
        
        
        
        [self addButton];
        
        
        Request= [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[basePath stringByAppendingString:TagDetailUrl]]];
        [Request setPostValue:[NSNumber numberWithInteger:Id] forKey:@"id"];
        [Request setDelegate:self];
        [Request setDidFinishSelector:@selector(checkSubscribe:)];
        [Request startAsynchronous];
        
    }
    return self;

}

-(void)addButton{
    self.SubscribeButton=[[CellSelectedButton alloc]initWithFrame:CGRectMake(260,8, 50, 30) NormalImage:[UIImage imageNamed:@"Search-Subscribe-Normal@2x.png"] SelectedImage:[UIImage imageNamed:@"Search-Subscribe-Selected@2x.png" ]];
    [self.SubscribeButton setDelegate:self];
    
    //按钮上加个菊花
    UIActivityIndicatorView* gear=[[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    [gear setHidesWhenStopped:YES];
    UIView *gearBackgroundView =[[UIView alloc]initWithFrame:CGRectMake(10, 10, self.SubscribeButton.bounds.size.width-20, self.SubscribeButton.bounds.size.height-20)];
    [gearBackgroundView setBackgroundColor:[UIColor colorWithRed:221.0/255.0 green:221.0/255.0 blue:221.0/255.0 alpha:1]];
    [gearBackgroundView addSubview:gear];
    [gear setFrame:CGRectMake(gearBackgroundView.bounds.size.width/2-gear.bounds.size.width/2, (gearBackgroundView.bounds.size.height-gear.bounds.size.height)/2, gear.bounds.size.width, gear.bounds.size.height)];
    [gearBackgroundView setTag:1];
    [self.SubscribeButton addSubview:gearBackgroundView];
    [gear startAnimating];
    [self addSubview:self.SubscribeButton];
}

-(void)dealloc{
    
    if (Request){
        [Request clearDelegatesAndCancel];
    }
    Request=nil;
    
    if (SubscribeRequest){
        [SubscribeRequest clearDelegatesAndCancel];
        
    }
    SubscribeRequest=nil;

}

-(void)setTagName:(NSString *)TagName{
    _TagName = TagName ;
    self.textLabel.text=TagName;
}

-(void)setTagId:(NSInteger)TagId{
    _TagId=TagId;
    if (Request)[Request clearDelegatesAndCancel];
    Request= [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[basePath stringByAppendingString:TagDetailUrl]]];
    [Request setPostValue:[NSNumber numberWithInteger:TagId] forKey:@"id"];
    [Request setDelegate:self];
    [Request setDidFinishSelector:@selector(checkSubscribe:)];
    [Request startAsynchronous];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


-(void)buttonPress:(CellSelectedButton *)button{

    if (!button.SelectedState){
        //连接订阅
        SubscribeRequest = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[basePath stringByAppendingString:SubscribeCancelUrl]]];
        [SubscribeRequest setPostValue:[NSNumber numberWithInteger:self.TagId] forKey:@"tag_id"];
        [SubscribeRequest startSynchronous];//忽略请求结果
        NSData *data=[SubscribeRequest responseData];
        NSDictionary *dic =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"%@",dic);
        
    }
    else {
        //取消订阅
        SubscribeRequest = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[basePath stringByAppendingString:SubscribeCommitUrl]]];
        [SubscribeRequest setPostValue:[NSNumber numberWithInteger:self.TagId] forKey:@"tag_id"];
        [SubscribeRequest startSynchronous];//忽略请求结果
        NSData *data=[SubscribeRequest responseData];
        NSDictionary *dic =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"%@",dic);
    }
}



-(void)checkSubscribe:(ASIFormDataRequest*)request{
    NSLog(@"aa");
    NSData *data =[request responseData];
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
    if (![[dic objectForKey:@"err"] isMemberOfClass:[NSNull class]])return ;//请求失败
    //请求成功
    BOOL isSubsribe=[[[dic objectForKey:@"data"] objectForKey:@"is_subscribe"] boolValue];
    [self.SubscribeButton setButtonState:isSubsribe];
    
    //去除菊花
    UIView *view=[self.SubscribeButton viewWithTag:1];
    [view removeFromSuperview];
}

@end
