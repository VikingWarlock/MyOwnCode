//
//  SGFocusImageItem.m
//  SGFocusImageFrame
//
//  Created by Shane Gao on 17/6/12.
//  Copyright (c) 2012 Shane Gao. All rights reserved.
//

#import "SGFocusImageItem.h"

@interface SGFocusImageItem(){
    ASIFormDataRequest *FormRequest;
}

@end

@implementation SGFocusImageItem
@synthesize title =  _title;
@synthesize image =  _image;
@synthesize tag =  _tag;

- (void)dealloc
{
    [FormRequest clearDelegatesAndCancel];
    [FormRequest release];
    [_title release];
    [_image release];
    [super dealloc];
}

- (id)initWithTitle:(NSString *)title image:(UIImage *)image tag:(NSInteger)tag
{
    self = [super init];
    if (self) {
        self.title = title;
        self.image = image;
        self.tag = tag;
    }
    
    return self;
}

-(void)setImageWithUrl:(NSURL *)url{//设置连接失败的话直接略过
//    NSLog(@"connecting");
    FormRequest=[[ASIFormDataRequest alloc]initWithURL:url];
    [FormRequest setDelegate:self];
    [FormRequest startAsynchronous];
}
-(void)requestFinished:(ASIHTTPRequest *)request{
    NSData *responseData=[request responseData];
    NSInteger state = [request responseStatusCode];
    if (state!=200){
        NSLog(@"%d",state);
     return ;
    }
    if (responseData==nil){
        NSLog(@"empty");
     return;
    }
    UIImage *image =[UIImage imageWithData:responseData];
    //--------------原版注释--------------------------
//    [self.button setBackgroundImage:image forState:UIControlStateNormal];
    //--------------原版注释--------------------------
    [self.button setImage:image];
    
//    NSLog(@"setted");
}

@end
