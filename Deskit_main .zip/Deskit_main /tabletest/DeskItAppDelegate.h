//
//  DeskItAppDelegate.h
//  tabletest
//
//  Created by vikingwarlock on 13-6-14.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeskItAppDelegate : UIResponder <UIApplicationDelegate>
{
    NSArray*path;
    NSString *pathDocuments;
}
@property (strong, nonatomic) UIWindow *window;

@end
