//
//  PushViewController.h
//  Deskit_beta
//
//  Created by viking warlock on 9/1/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import "Subscribe_DetailViewController.h"
#import "JsonDataFormatting.h"
#import "ASIHTTPRequestDelegate.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import "constant.h"
#import "ImageLocalized.h"
#import "InformationViewController.h"


@interface PushViewController : Subscribe_DetailViewController
{
    ASIFormDataRequest *PushList;
    
    NSArray *PushListData;
    
}
@end
