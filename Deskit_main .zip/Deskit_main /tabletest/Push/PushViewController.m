//
//  PushViewController.m
//  Deskit_beta
//
//  Created by viking warlock on 9/1/13.
//  Copyright (c) 2013 Viking Warlock. All rights reserved.
//

#import "PushViewController.h"

@interface PushViewController ()

@end

@implementation PushViewController

@synthesize TabBarTitle;
@synthesize IfNil;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    self.selfID=@"0";
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    [self loadListData];
    //订阅按钮初始化

    SubscribeButton.hidden=YES;
    
}

-(void)loadListData
{
    Title=@"我的消息";
    TabBarTitle.text=Title;
    NSURL *url=[NSURL URLWithString:[basePath stringByAppendingString:notificationListUnread]];
    PushList=[ASIFormDataRequest requestWithURL:url];
    [PushList setRequestMethod:@"POST"];
    [PushList setDidFinishSelector:@selector(SetupPushList:)];
    [PushList setDelegate:self];
    [PushList startAsynchronous];
}

-(void)SetupPushList :(ASIFormDataRequest*) request
{
    NSError *error;
    NSData *responseData = [request responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
    
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        //        NSLog(@"%@",responseDictionary);
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"%@",ResponseErrMsg);
            NSLog(@"返回值出错");
            
            return ;
        }
    }
    
    PushListData=[responseDictionary objectForKey:@"data"];

    if ([PushListData count]<=0)
    {
    
    
    
//        NSMutableDictionary *temp1=[[NSMutableDictionary alloc]init];
//        [temp1 setObject:@"" forKey:<#(id<NSCopying>)#>]
        //tableViewData=[[NSMutableDictionary alloc]init];
        SelfTableView.hidden=YES;
        IfNil.hidden=NO;
        
    }
    else
    {
       /*
        NSDictionary *file1=[[NSDictionary alloc]init];
        NSDictionary *FromFile=[[NSDictionary alloc]init];
        ImageLocalized *file;
        file1=[file readNSDictionary:@"Detail.plist" :nil];
        FromFile=[file1 objectForKey:@"Detail"];
        for (NSDictionary *temp in PushListData) {
            if ([[FromFile allKeys]containsObject:[NSString stringWithFormat:@"%@",[temp objectForKey:@"id"]]]) {
                continue;
            }
            [file]
        }
        */
        
        NSDictionary *temp=[[NSDictionary alloc]init];
        NSMutableArray *temp3=[[NSMutableArray alloc]init];
        for (temp in PushListData)
        {
            [temp3 addObject:[temp objectForKey:@"id"]];
        }
        tableViewData=temp3;

        [self API_init];
    
    }
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    InformationViewController *controller=[[InformationViewController alloc]init];
    NSDictionary *temp=[[NSDictionary alloc]initWithDictionary:[PushListData objectAtIndex:indexPath.row]];
    [controller initStyle2:temp :[[temp objectForKey:@"id"]intValue]];
    [self.navigationController pushViewController:controller animated:YES];
    DetailSubCell *cell=(DetailSubCell*)[SelfTableView cellForRowAtIndexPath:indexPath];
    [cell didSelectedOutLookChange];
    [SelfTableView deselectRowAtIndexPath:indexPath animated:NO];
   // [SelfTableView reloadData];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)dealloc
{
    if (PushList) {
        [PushList clearDelegatesAndCancel];
        PushList=nil;
    }
}


@end
