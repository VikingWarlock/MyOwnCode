//
//  ListConnectDeleate.m
//  Deskit_beta
//
//  Created by Sway on 13-7-21.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import "ListConnectDeleate.h"
@interface ListConnectDeleate(){
    BOOL firstConnected;
    ASIFormDataRequest *secondRequest;
}
@end

@implementation ListConnectDeleate

-(id)init{
    self=[super init];
    if (self){
        firstConnected=NO;
    }
    return self;
}
-(void)dealloc{
    secondRequest=nil;
}



-(void)requestFinished:(ASIFormDataRequest *)request{
//    NSData *responseData=[request responseData];
//
//    NSDictionary *Data=[NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:nil];
//    NSNull *err=[Data objectForKey:@"err"];
//    NSLog(@"%@",Data);
//
//    if (firstConnected==NO){
//        firstConnected=YES;
//        NSInteger category_id = (NSInteger)[[[Data objectForKey:@"data"] objectAtIndex:self.TabIndex] objectForKey:@"id"];
//        NSString *name =(NSString*)[[[Data objectForKey:@"data"] objectAtIndex:self.TabIndex] objectForKey:@"name"];
//
//
////        [request clearDelegatesAndCancel];
//        secondRequest =[[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:listDetailUrl]];
//        [secondRequest setPostValue:@"1" forKey:@"category_id"];
//        [secondRequest setDelegate:self];
//        [secondRequest startAsynchronous];
//    }
}

//-(void)haha{
//    [listDetailRequest startAsynchronous];
//}

@end
