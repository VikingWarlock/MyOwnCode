//
//  DeskItTableView.h
//  tabletest_mod1
//
//  Created by vikingwarlock on 13-6-19.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DeskItCell_settings.h"
@interface DeskItTableView : UITableViewController

@end
