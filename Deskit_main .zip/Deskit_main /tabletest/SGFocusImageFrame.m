//
//  SGFocusImageFrame.m
//  SGFocusImageFrame
//
//  Created by Shane Gao on 17/6/12.
//  Copyright (c) 2012 Shane Gao. All rights reserved.
//

#import "SGFocusImageFrame.h"
#import "SGFocusImageItem.h"
#import <objc/runtime.h>
#import "constant.h"
#import "MyUIPageControl.h"

#import "InformationViewController.h"


@interface SGFocusImageFrame () {
    UIScrollView *_scrollView;
   MyUIPageControl *_pageControl;
    NSMutableArray *labelArray;
    NSMutableArray *buttonArray;
    
}
 
- (void)setupViews;
- (void)switchFocusImageItems;


@end

static NSString *SG_FOCUS_ITEM_ASS_KEY = @"com.touchmob.sgfocusitems";

static CGFloat SWITCH_FOCUS_PICTURE_INTERVAL = 6.0; //switch interval time

@implementation SGFocusImageFrame
@synthesize delegate = _delegate;


+(void)setItemImage:(UIImage *)image WithIndex:(NSInteger)index{
}
//初始化
- (id)initWithFrame:(CGRect)frame delegate:(id<SGFocusImageFrameDelegate>)delegate focusImageItems:(SGFocusImageItem *)firstItem, ...
{
    
    self = [super initWithFrame:frame];//调用父类方法
    if (self) {
        buttonArray=[[NSMutableArray alloc] init];
        labelArray=[[NSMutableArray alloc] init];
        NSMutableArray *imageItems = [NSMutableArray array];//储存Item参数的数组
        SGFocusImageItem *eachItem;
        va_list argumentList;//C语言中解决变参问题的一组宏
        //开始处理参数
        if (firstItem)
        {                                  
            [imageItems addObject: firstItem];
            va_start(argumentList, firstItem);       
            while((eachItem = va_arg(argumentList, SGFocusImageItem *)))
            {
                [imageItems addObject: eachItem];            
            }
            va_end(argumentList);
        }
        
        //为本类添加属性扩展
        objc_setAssociatedObject(self, (const void *)SG_FOCUS_ITEM_ASS_KEY, imageItems, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        
        [self setupViews];
        
        [self setDelegate:delegate]; 
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame delegate:(id<SGFocusImageFrameDelegate>)delegate focusImageItemsArray:(NSArray*)imageItems
{
    
    self = [super initWithFrame:frame];//调用父类方法
    if (self) {
        buttonArray=[[NSMutableArray alloc] init];
        labelArray=[[NSMutableArray alloc] init];
//        NSMutableArray *imageItems = [NSMutableArray array];//储存Item参数的数组
//        SGFocusImageItem *eachItem;
//        va_list argumentList;//C语言中解决变参问题的一组宏
        //开始处理参数
//        if (firstItem)
//        {
//            [imageItems addObject: firstItem];
//            va_start(argumentList, firstItem);
//            while((eachItem = va_arg(argumentList, SGFocusImageItem *)))
//            {
//                [imageItems addObject: eachItem];
//            }
//            va_end(argumentList);
//        }
        
        
        //为本类添加属性扩展
        objc_setAssociatedObject(self, (const void *)SG_FOCUS_ITEM_ASS_KEY, imageItems, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        
        [self setupViews];
        
        [self setDelegate:delegate];
    }
    return self;
}

- (void)dealloc
{
    objc_setAssociatedObject(self, (const void *)SG_FOCUS_ITEM_ASS_KEY, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [_scrollView release];
    [_pageControl release];
    [super dealloc];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

#pragma mark - private methods
- (void)setupViews
{
    //获取imageItem
    NSArray *imageItems = objc_getAssociatedObject(self, (const void *)SG_FOCUS_ITEM_ASS_KEY);
    _scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
    
    
    //scrollView底部小圆点
//    _pageControl = [[MyUIPageControl alloc] initWithFrame:CGRectMake(self.bounds.size.width *.5 - size.width *.5, self.bounds.size.height - size.height, size.width, size.height)];
    //UIPageControl圆点
    //frame mark
    _pageControl = [[MyUIPageControl alloc] initWithFrame:CGRectMake(self.bounds.size.width*0.72,self.bounds.size
.height-(kNewsTitleHight+kUIPageControlHight)*0.5,self.bounds.size.width*0.25,kUIPageControlHight)];
    
    
    [self addSubview:_scrollView];
    [self addSubview:_pageControl];
    
    /*
    _scrollView.layer.cornerRadius = 10;
    _scrollView.layer.borderWidth = 1 ;
    _scrollView.layer.borderColor = [[UIColor lightGrayColor ] CGColor];
    */
    _scrollView.showsHorizontalScrollIndicator = NO;//隐藏竖直滚动条
    _scrollView.pagingEnabled = YES;
    
    
    _pageControl.numberOfPages = imageItems.count;
    _pageControl.currentPage = 0;//当前页面
    
    _scrollView.delegate = self;
    
    
    
    // single tap gesture recognizer
    //设置单击手势
//    UITapGestureRecognizer *tapGestureRecognize = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapGestureRecognizer:)];
//    tapGestureRecognize.delegate = self;
//    tapGestureRecognize.numberOfTapsRequired = 1;
    
    
    
    //把手势识别器添加给scrollView
   // [_scrollView addGestureRecognizer:tapGestureRecognize];
    _scrollView.contentSize = CGSizeMake(_scrollView.frame.size.width * imageItems.count, _scrollView.frame.size.height);
    
    
    
    
    
    for (int i = 0; i < imageItems.count; i++) {
        SGFocusImageItem *item = [imageItems objectAtIndex:i];
//        NSLog(@"for loop %d",i);
        //---------------------原版注释－－－－－－－－－－－
//        //添加图片展示按钮
//        UIButton * imageView = [UIButton buttonWithType:UIButtonTypeCustom];
//        [imageView setFrame:CGRectMake(i * _scrollView.frame.size.width, 0, _scrollView.frame.size.width, _scrollView.frame.size.height)];
//        [imageView setBackgroundImage:item.image forState:UIControlStateNormal];
//        imageView.tag = i;
//        
//        imageView.contentMode=UIViewContentModeScaleAspectFit;
//        [buttonArray addObject:imageView];
//        
//        //添加点击事件
//        [imageView addTarget:self action:@selector(clickPageImage:) forControlEvents:UIControlEventTouchUpInside];
        //---------------------－－－－－－－－－－－
        
//        //重写头条
        UIImageView * imageView = [[UIImageView alloc]init];
        [imageView setFrame:CGRectMake(i * _scrollView.frame.size.width, 0, _scrollView.frame.size.width, _scrollView.frame.size.height)];
        [imageView setImage:item.image];
        imageView.tag = i;
        
        [imageView setContentMode:UIViewContentModeScaleAspectFill];
//        //添加点击事件
//        UITapGestureRecognizer *recognizer =[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(topImageClick:)];
//        [imageView addGestureRecognizer:recognizer];
        [imageView setUserInteractionEnabled:YES];
        //在其上面加个button
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
//        [button setAlpha:0];
//        [button setUserInteractionEnabled:YES];
        [button setFrame:CGRectMake(0, 0, imageView.bounds.size.width, imageView.bounds.size.height)];
        [button setBackgroundColor:[UIColor clearColor]];
        [imageView addSubview:button];
        [button addTarget:self action:@selector(clickPageImage:) forControlEvents:UIControlEventTouchUpInside];
        [button setBackgroundImage:[UIImage imageNamed:@"buttonBackground@2x.png"] forState:UIControlStateHighlighted];
        
        [buttonArray addObject:imageView];
        




        
        
        //frame mark
        //新闻的透明标题栏
        UIView *titleView = [[UIView alloc]initWithFrame:CGRectMake(i*_scrollView.frame.size.width, _scrollView.frame.size.height-kNewsTitleHight, _scrollView.frame.size.width, kNewsTitleHight)];
        [titleView setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.5]];
        [_scrollView addSubview:titleView];
        
        
        //frame mark
        //添加标题栏
        UILabel * lbltitle = [[UILabel alloc] initWithFrame:CGRectMake(i * _scrollView.frame.size.width+12, _scrollView.frame.size.height-30.0, _scrollView.frame.size.width*0.6, 22)];
        [lbltitle setTextColor:[UIColor colorWithWhite:1 alpha:1]];//字体时白色

        [lbltitle setTextAlignment:UITextAlignmentCenter];
        lbltitle.text= item.title;
        [labelArray addObject:lbltitle];
        lbltitle.tag=i*10;
        //lbltitle.text =@"城市摄影展!!!!!!!!!!!!!!!!!!!!!aaaaaaaaa";
        
        lbltitle.backgroundColor = [UIColor clearColor];
        
        [_scrollView addSubview:imageView];
        item.button=imageView;
        [_scrollView addSubview:titleView];
        [_scrollView addSubview:lbltitle];
        [lbltitle release];
    }
    
    
    
    
    
   // [tapGestureRecognize release];
    
    //动态滚动功能，暂时禁用
    [self performSelector:@selector(switchFocusImageItems) withObject:nil afterDelay:SWITCH_FOCUS_PICTURE_INTERVAL];

}

- (void)switchFocusImageItems
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(switchFocusImageItems) object:nil];
    
    CGFloat targetX = _scrollView.contentOffset.x + _scrollView.frame.size.width;
    [self moveToTargetPosition:targetX];

    [self performSelector:@selector(switchFocusImageItems) withObject:nil afterDelay:SWITCH_FOCUS_PICTURE_INTERVAL];
}

//- (void)singleTapGestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
//{
//    //NSLog(@"%s", __FUNCTION__);
//    NSArray *imageItems = objc_getAssociatedObject(self, (const void *)SG_FOCUS_ITEM_ASS_KEY);
//    int page = (int)(_scrollView.contentOffset.x / _scrollView.frame.size.width);
//    NSLog(@"%d",page);
//    if (page > -1 && page < imageItems.count) {
//        SGFocusImageItem *item = [imageItems objectAtIndex:page];
//        if ([self.delegate respondsToSelector:@selector(foucusImageFrame:didSelectItem:)]) {
//            [self.delegate foucusImageFrame:self didSelectItem:item];
//        }
//    }
//    //objc_setAssociatedObject(self, (const void *)SG_FOCUS_ITEM_ASS_KEY, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
//}

- (void)moveToTargetPosition:(CGFloat)targetX
{
    //NSLog(@"moveToTargetPosition : %f" , targetX);
    if (targetX >= _scrollView.contentSize.width) {
        targetX = 0.0;
    }
    
    [_scrollView setContentOffset:CGPointMake(targetX, 0) animated:YES] ;
    _pageControl.currentPage = (int)(_scrollView.contentOffset.x / _scrollView.frame.size.width);
}


-(void)setTitle:(NSString *)title Index:(NSInteger)index{
        UILabel *ItemLabel = [labelArray objectAtIndex:index];
    [ItemLabel setText:title];
}

- (void)updateImage:(UIImage*)image title:(NSString*)title forItemIndex:(NSInteger)index{
//    NSArray *imageItems = objc_getAssociatedObject(self, (const void *)SG_FOCUS_ITEM_ASS_KEY);
    //--------------原版注释--------------------------
//    UIButton *ItemButton = [buttonArray objectAtIndex:index];
//    [ItemButton setBackgroundImage:image forState:UIControlStateNormal];
    //----------------------------------------
    UIImageView *imageView = [buttonArray objectAtIndex:index];
    [imageView setImage:image];
    
    UILabel *ItemLabel = [labelArray objectAtIndex:index];
    [ItemLabel setText:title];

    
    
}


#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    _pageControl.currentPage = (int)(scrollView.contentOffset.x / scrollView.frame.size.width);
    
}

#ifdef _FOR_DEBUG_
-(BOOL) respondsToSelector:(SEL)aSelector {
    printf("SELECTOR: %s\n", [NSStringFromSelector(aSelector) UTF8String]);
    return [super respondsToSelector:aSelector];
}
#endif


#pragma mark - UIButtonTouchEvent
-(void)clickPageImage:(UIButton *)sender{
    
    NSLog(@"%s", __FUNCTION__);
    
    NSArray *imageItems = objc_getAssociatedObject(self, (const void *)SG_FOCUS_ITEM_ASS_KEY);
    int page = (int)(_scrollView.contentOffset.x / _scrollView.frame.size.width);
    if (page > -1 && page < imageItems.count) {
        SGFocusImageItem *item = [imageItems objectAtIndex:page];
        if ([self.delegate respondsToSelector:@selector(foucusImageFrame:didSelectItem:)]) {
            [self.delegate foucusImageFrame:self didSelectItem:item];
        }
    }
    
 //   [self PageTurn:sender.tag];
    
    //************添加代理到RootViewController

    
}


//delegate scroll did select
/*
-(void)PageTurn :(int )income
{
    if([self.ScrollDidSelectDelegate respondsToSelector:@selector(ScrollDidSelect:)])
        
    [self.ScrollDidSelectDelegate ScrollDidSelect:income];

}
*/

#pragma mark -setImage With Url in Asynchronized Way
-(void)setImageWithUrl:(NSURL *)url Index:(NSInteger)index{
    NSArray *imageItems = objc_getAssociatedObject(self, (const void *)SG_FOCUS_ITEM_ASS_KEY);
    SGFocusImageItem *item = [imageItems objectAtIndex:index];
    [item setImageWithUrl:url];
}

//-(void)topImageClick:(UITapGestureRecognizer*)recognizer{
//    NSLog(@"234234");
//    if (recognizer.state==UITouchPhaseEnded){
//        [self clickPageImage:nil];
//    }
//}
@end
