//
//  CustomTabBar.m
//  Tes
//
//  Created by Sway on 13-6-19.
//  Copyright (c) 2013年 Sway. All rights reserved.
//

#import "CustomTabBar.h"


@interface CustomTabBar(){
    NSArray *buttonArray;
}
@end

@implementation CustomTabBar
@synthesize delegate=_delegate;


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}


-(id)init{
    self = [super init];
    if (self){
        CGSize size=[UIScreen mainScreen].bounds.size;
        //        NSLog(@"%f",size.height);
        [self setFrame:CGRectMake(0,size.height-64, size.width, 44)];
        
        buttonBasicBackgoundColor =[UIColor colorWithRed:31.0/255.0 green:30.0/255.0 blue:30.0/255.0 alpha:1];
        [self setBackgroundColor:buttonBasicBackgoundColor];
        
        //位置
        button0=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 80, 44)];
        button1=[[UIButton alloc]initWithFrame:CGRectMake(80, 0, 80, 44)];
        button2=[[UIButton alloc]initWithFrame:CGRectMake(160, 0, 80, 44)];
        button3=[[UIButton alloc]initWithFrame:CGRectMake(240, 0, 80, 44)];
        buttonArray=[[NSArray alloc]initWithObjects:button0,button1,button2,button3,nil];
        [self addSubview:button0];
        [self addSubview:button1];
        [self addSubview:button2];
        [self addSubview:button3];
        
        //标题
        [button0 setTitle:@"新闻" forState:UIControlStateNormal];
        [button1 setTitle:@"通知" forState:UIControlStateNormal];
        [button2 setTitle:@"活动" forState:UIControlStateNormal];
        [button3 setTitle:@"生活" forState:UIControlStateNormal];
        
        //标题
        [button0 setTitle:@"新闻" forState:UIControlStateHighlighted];
        [button1 setTitle:@"通知" forState:UIControlStateHighlighted];
        [button2 setTitle:@"活动" forState:UIControlStateHighlighted];
        [button3 setTitle:@"生活" forState:UIControlStateHighlighted];
        
        [button0.titleLabel setFont:[UIFont systemFontOfSize:14]];
        [button1.titleLabel setFont:[UIFont systemFontOfSize:14]];
        [button2.titleLabel setFont:[UIFont systemFontOfSize:14]];
        [button3.titleLabel setFont:[UIFont systemFontOfSize:14]];
        
        
        //颜色
        [button0 setBackgroundColor:buttonBasicBackgoundColor];
        [button1 setBackgroundColor:buttonBasicBackgoundColor];
        [button2 setBackgroundColor:buttonBasicBackgoundColor];
        [button3 setBackgroundColor:buttonBasicBackgoundColor];
        //标题颜色
        NormalTitleColor=[UIColor colorWithRed:118.0/255.0 green:117.0/255.0 blue:117.0/255.0 alpha:1];
        [button0 setTitleColor:NormalTitleColor forState:UIControlStateNormal];
        [button1 setTitleColor:NormalTitleColor forState:UIControlStateNormal];
        [button2 setTitleColor:NormalTitleColor forState:UIControlStateNormal];
        [button3 setTitleColor:NormalTitleColor forState:UIControlStateNormal];
        
        
        [button0 addTarget:self action:@selector(buttonpress0:) forControlEvents:UIControlEventTouchUpInside];
        [button1 addTarget:self action:@selector(buttonpress1:) forControlEvents:UIControlEventTouchUpInside];
        [button2 addTarget:self action:@selector(buttonpress2:) forControlEvents:UIControlEventTouchUpInside];
        [button3 addTarget:self action:@selector(buttonpress3:) forControlEvents:UIControlEventTouchUpInside];
        
        
        
        
        selectedTitleColor=[UIColor whiteColor];
        selectedBackgroundColor=[UIColor colorWithRed:11.0/255.0 green:10.0/255.0 blue:10.0/255.0 alpha:1];
        ButtonArray=[NSArray arrayWithObjects:button0,button1,button2,button3, nil];
        lastSelectedButtonIndex=-1;
        [self setButtonSelectedStatus:button0 withButtonIndex:0];
        
    }
    return self;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */


-(void)setButtonSelectedStatus:(UIButton *)button withButtonIndex:(NSInteger)index{
    if (lastSelectedButtonIndex==selectedButtonIndex)return;
    [button setBackgroundColor:selectedBackgroundColor];
    [button setTitleColor:selectedTitleColor forState:UIControlStateNormal];
    selectedButtonIndex=index;
}

-(void)resumeButtonStatus{
    if (lastSelectedButtonIndex==selectedButtonIndex)return;
    UIButton *button = (UIButton*)[ButtonArray objectAtIndex:lastSelectedButtonIndex];
    [button setBackgroundColor:buttonBasicBackgoundColor];
    [button setTitleColor:NormalTitleColor forState:UIControlStateNormal];
}



//-(void)buttonSelectedStatus2{}
//-(void)buttonSelectedStatus3{}
//-(void)buttonSelectedStatus4{}
//-(void)resumebutton0{}
//-(void)resumebutton1{}
//-(void)resumebutton2{}
//-(void)resumebutton3{}


-(void)buttonpress0:(UIButton*)button{
    lastSelectedButtonIndex=selectedButtonIndex;
    selectedButtonIndex=0;
    [self setButtonSelectedStatus:button0 withButtonIndex:0];
    [self resumeButtonStatus];
    if ([self.delegate respondsToSelector:@selector(CustomTabBar:pressedButtonIndex:)]){
        
        [self.delegate CustomTabBar:button0 pressedButtonIndex:0];
    }
}
-(void)buttonpress2:(UIButton*)button{
    lastSelectedButtonIndex=selectedButtonIndex;
    selectedButtonIndex=2;
    [self setButtonSelectedStatus:button2 withButtonIndex:2];
    [self resumeButtonStatus];
    if ([self.delegate respondsToSelector:@selector(CustomTabBar:pressedButtonIndex:)]){
        
        [self.delegate CustomTabBar:button2 pressedButtonIndex:2];
    }
}
-(void)buttonpress3:(UIButton*)button{
    lastSelectedButtonIndex=selectedButtonIndex;
    selectedButtonIndex=3;
    [self setButtonSelectedStatus:button3 withButtonIndex:3];
    [self resumeButtonStatus];
    if ([self.delegate respondsToSelector:@selector(CustomTabBar:pressedButtonIndex:)]){
        
        [self.delegate CustomTabBar:button3 pressedButtonIndex:3];
    }
}
-(void)buttonpress1:(UIButton*)button{
    lastSelectedButtonIndex=selectedButtonIndex;
    selectedButtonIndex=1;
    [self setButtonSelectedStatus:button1 withButtonIndex:1];
    [self resumeButtonStatus];
    if ([self.delegate respondsToSelector:@selector(CustomTabBar:pressedButtonIndex:)]){
        
        [self.delegate CustomTabBar:button1 pressedButtonIndex:1];
    }
}

-(void)setButtonTitle:(NSString *)title WithIndex:(NSInteger)index{
    UIButton *button =[buttonArray objectAtIndex:index];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitle:title forState:UIControlStateHighlighted];
}


@end
