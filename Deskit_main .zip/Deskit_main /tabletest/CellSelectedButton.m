//
//  CellSelectedButton.m
//  Deskit_beta
//
//  Created by Sway on 13-6-22.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import "CellSelectedButton.h"

@implementation CellSelectedButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


-(id)initWithFrame:(CGRect)frame NormalImage:(UIImage*)Nimage SelectedImage:(UIImage *)Simage{
    self=[super initWithFrame:frame NormalImage:Nimage SelectedImage:Simage];
    if (self){
    }
    return self;
}

-(void)Select{
    [super Select];
    if ([self.CellSelectedDelegate respondsToSelector:@selector(SelectedButton:CellIndexRow:Message:)]){
        [self.CellSelectedDelegate SelectedButton:self CellIndexRow:self.CurrentCellRow Message:self.Message];
    }
}

-(void)buttonPress{
    [super Select];
    if ([self.CellSelectedDelegate respondsToSelector:@selector(buttonPress:)]){
        [self.CellSelectedDelegate buttonPress:self];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
