//
//  DeskItViewController.m
//  InformationPage
//
//  Created by vikingwarlock on 13-7-2.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import "InformationViewController.h"
#import "JsonDataFormatting.h"
#import "constant.h"
#import <QuartzCore/QuartzCore.h>

#define icon_select_height 44
#define icon_select_width 110

@interface InformationViewController ()

@end

@implementation InformationViewController

@synthesize AdmireButton;
@synthesize BackButton;
@synthesize DateLabel;
@synthesize JoinButton;
@synthesize MenuButton;
@synthesize MenuView;
@synthesize MainView;
@synthesize MainInformation;
@synthesize SharedButton;
@synthesize SourcesLabel;
@synthesize lastview;



-(void)ScreenStyle
{
    if (ScreenFrame_iPhone.size.height>480) {
        self.view.frame=ScreenFrame_without_status_iphone;
        MainView.frame=ScreenFrame_without_status_iphone;
        

        
       // NSLog(@"%f,%f,%f,%f",Main_Page.frame.origin.x,Main_Page.frame.origin.y,Main_Page.frame.size.width,Main_Page.frame.size.height);
        
        CGRect temp=MainInformation.frame;
        [MainInformation setFrame:CGRectMake(temp.origin.x, temp.origin.y, temp.size.width, temp.size.height+88)];
  //      temp=TabBar.frame;
  //      [TabBar setFrame:CGRectMake(temp.origin.x, temp.origin.y+88, temp.size.width, temp.size.height)];
        
    }
    
}




- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self ScreenStyle];

    /*
    if (data) {[MainInformation loadHTMLString:[data objectForKey:@"content"] baseURL:nil];}
    */
    ImageLocalized *file=[[ImageLocalized alloc]init];
    setting=[[NSDictionary alloc]initWithDictionary:[file readNSDictionary:@"setting.plist" :Nil]];
    
    
    
     [self ViewInit];
//    [self.MenuView setFrame:CGRectMake(MenuView.frame.origin.x, MenuView.frame.origin.y, icon_select_width, 0)];
        CGSize screenSize = [UIScreen mainScreen].bounds.size;
        MenuView.frame=CGRectMake(screenSize.width-icon_select_width-10, 44+10, icon_select_width, 0);
    [MenuView setBackgroundColor:[UIColor colorWithRed:229.0/255.0 green:229.0/255.0 blue:229.0/255.0 alpha:1]];
//    [MenuView setBackgroundColor:[UIColor blackColor]];
    
    //    NSLog(@"%f,%f",self.MenuView.frame.origin.x,self.MenuView.frame.origin.y);

    [self loadingStyle];
    
    self.MenuView.hidden=YES;
//    self.MenuView.alpha=0.8;
    
    ActionList=[[NSMutableArray alloc]init];
    NameList=[[NSMutableArray alloc]init];
    self.MainInformation.multipleTouchEnabled=NO;
    
    
    gesture=[[UIPanGestureRecognizer alloc]init];
    [gesture addTarget:self action:@selector(backGuesture:)];
    
    [MainInformation addGestureRecognizer:gesture];
    [self.view addGestureRecognizer:gesture];
    CGRect frame=CGRectMake(-lastview.size.width, 0, lastview.size.width, lastview.size.height);
    lastView=[[UIImageView alloc]initWithImage:lastview];
    [lastView setFrame:frame];
    [self.view addSubview:lastView];
    


    
	// Do any additional setup after loading the view, typically from a nib.
}


-(void)ViewInit{
    [self MenuButtonInit];
}





-(void) loadingStyle
{
    
//    [self LoadWeb:essay_id];
    //    essay_id=108;
    if (Shared) {
        [SharedButton setImage:[UIImage imageNamed:@"icon-star-solid-blue.png"] forState:UIControlStateNormal];}else [SharedButton setImage:[UIImage imageNamed:@"icon-star-hollow-black.png"] forState:UIControlStateNormal];
    
    if(Admired){
        [AdmireButton setImage:[UIImage imageNamed:@"finger_selected.png"] forState:UIControlStateNormal];}else [AdmireButton setImage:[UIImage imageNamed:@"finger_normal.png"] forState:UIControlStateNormal];
    
    if (Joined) {
        JoinButton.hidden=NO;
    }else JoinButton.hidden=YES;
    
    SourcesLabel.text=[NSString stringWithFormat:@"%@",Source];
    DateLabel.text=Date;
    
  /*
    int count=[ButtonList count];
    int i;
    for (i=1; i<=count; i++) {
        //add button
        [self addButton:[ButtonList objectAtIndex:(i-1)] :nil :i];
        
    }
    */
    
    
}


////外部加载

-(void) initStyleFromDetail:(int)essayid :(BOOL)admired :(BOOL)shared :(NSString *)date :(NSString *)source
{
    essay_id=essayid;
    Admired=admired;
    Shared=shared;
    Date=date;
    Source=source;
    

    From =[NSString stringWithFormat:@"Detail"];
}

-(void) initStyleFromRoot:(NSNumber*)essayid
{
    essay_id=[essayid intValue];
    Admired=YES;
    Shared=YES;
    Date=@"";
    Source=@"";
    
    From=[NSString stringWithFormat:@"Root"];
    [self LoadWeb:essay_id];

}

-(void)initStyle2:(NSDictionary *)information :(int)idnum
{
    data=[[NSDictionary alloc]initWithDictionary:information];
    
    
 //   [MainInformation loadHTMLString:[data objectForKey:@"content"] baseURL:nil];
 //   essay_id=[[NSString stringWithFormat:@"%@", [data objectForKey:@"id"] ]intValue];
    essay_id=idnum;
    From=[NSString stringWithFormat:@"Detail"];
    
    NSURL *url;
    
    
    
    url=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,@"/front/essay/current_detail"]];
    WebRequest=[ASIFormDataRequest requestWithURL:url];
    [WebRequest setRequestMethod:@"POST"];
    [WebRequest setDidFinishSelector:@selector(LoadwebRequestFinished:)];
    [WebRequest setPostValue:[NSNumber numberWithInt:essay_id] forKey:@"id"];
    [WebRequest setDelegate:self];
    RequestMethod=1;
    [WebRequest startAsynchronous];
    

}


-(void) LoadWeb:(int)Dataid
{
    NSURL *url;
      
    
    
    url=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,@"/front/essay/current_detail"]];
    WebRequest=[ASIFormDataRequest requestWithURL:url];
    [WebRequest setRequestMethod:@"POST"];
    [WebRequest setDidFinishSelector:@selector(LoadwebRequestFinished:)];
    [WebRequest setPostValue:[NSNumber numberWithInt:Dataid] forKey:@"id"];
    [WebRequest setDelegate:self];
    RequestMethod=1;
    [WebRequest startAsynchronous];
    
    
    
}




-(void) addButton   :(int)position
{
    UIButton *temp;

    
//    temp=[[UIButton alloc]init];
    temp=[UIButton buttonWithType:UIButtonTypeCustom];
    [temp setTitle:[NSString stringWithFormat:@"%@", [NameList objectAtIndex:position-1]] forState:UIControlStateNormal];
//    [temp setBackgroundImage:[UIImage imageNamed:@"ButtonWhite.png"] forState:UIControlStateNormal];
    [temp setBackgroundImage:[UIImage imageNamed:@"ButtonBlack.png"] forState:UIControlStateHighlighted];
    [temp setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [temp.titleLabel setFont:[UIFont systemFontOfSize:15]];
    [temp setBackgroundColor:[UIColor colorWithRed:247.0/255.0 green:247.0/255.0 blue:247.0/255.0 alpha:1]];
     temp.titleEdgeInsets=UIEdgeInsetsMake(0, -20, 0, 0);
     
    [self.MenuView setFrame:CGRectMake(self.MenuView.frame.origin.x, self.MenuView.frame.origin.y, self.MenuView.frame.size.width, self.MenuView.frame.size.height+icon_select_height+1)];
    [self.MenuView addSubview:temp];
    temp.tag=position-1;
    temp.frame=CGRectMake(0, (position-1)*(icon_select_height+1), icon_select_width, icon_select_height);

    temp.hidden=NO;
    
    [temp addTarget:self action:@selector(TurnToDetailPage:) forControlEvents:UIControlEventTouchUpInside];
    self.MenuView.layer.shadowColor = [[UIColor colorWithRed:100.0/255.0 green:100.0/255.0 blue:100.0/255.0 alpha:1] CGColor];
    self.MenuView.layer.shadowOffset = CGSizeMake(1.0f, 1.0f);
    self.MenuView.layer.shadowRadius = 3.0f;
    self.MenuView.layer.shadowOpacity = 1.0f;
 
}




- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestufreRecognizer
{
    
	return gesture.state == UIGestureRecognizerStatePossible;
}

-(void)backGuesture:(UIPanGestureRecognizer*) sender
{
    switch (sender.state) {
        case UIGestureRecognizerStatePossible:
        {
            break;
        }
        case UIGestureRecognizerStateBegan:
        {
            FirstPosition=[sender locationInView:self.view];
            break;
        }
        case UIGestureRecognizerStateChanged:
        {
            CGPoint translation=[sender translationInView:self.view];
            if (abs((int)translation.y)*3 < translation.x)
            {
                CGPoint NowPosition=[sender locationInView:self.view];
                CGRect frame=self.view.frame;
                float Xmove=(NowPosition.x-FirstPosition.x);
                frame.origin.x+=Xmove;
                [self.view setFrame:frame];
            }
            break;
        }
        case UIGestureRecognizerStateEnded:
        {
      //      NSLog(@"lastview %f,%f",lastView.frame.origin.x,lastView.frame.size.width);
            if (self.view.frame.origin.x>back_width) {
                [UIView animateWithDuration:0.3f
                                      delay:0
                                    options:UIViewAnimationOptionCurveLinear
                                 animations:^{
                                     CGRect frame = self.view.frame;
                                     frame.origin.x = 320;
                                     [self.view setFrame:frame];
                                     
                                 }
                                 completion:^(BOOL finished) {
                                     [self.navigationController popViewControllerAnimated:NO];
                                 }
                 ];
            }
            else
            {
                [UIView animateWithDuration:0.3f
                                      delay:0
                                    options:UIViewAnimationOptionCurveLinear
                                 animations:^{
                                     CGRect frame = self.view.frame;
                                     frame.origin.x = 0;
                                     [self.view setFrame:frame];
                                     
                                 }
                                 completion:^(BOOL finished) {
                                     
                                 }
                 
                 ];
            }
            break;
        }
        case UIGestureRecognizerStateCancelled:
        {
            break;
        }
            
        default:
            break;
    }
    
}


-(void) TurnToDetailPage :(UIButton*) sender
{
//    DeskItActionButton *this;
    Information_Detail *viewcontroll=[[Information_Detail alloc]init];
    
    MenuShowed=NO;
    touches=nil;
    self.MenuView.hidden=YES;
    
    self.MainView.userInteractionEnabled=YES;
    StartPoint=CGPointZero;
    
 //   NSLog(@"%@",[[NSString alloc]initWithFormat:@"%@",[ActionList objectAtIndex:sender.tag]]);

    [viewcontroll initStyle:NO :[NSString stringWithFormat:@"%@",[NameList objectAtIndex:sender.tag]] :0 :[[NSString alloc]initWithFormat:@"%@",[ActionList objectAtIndex:sender.tag]] :@"InformationPage"];
    
    
    
    ImageLocalized *file=[[ImageLocalized alloc]init];
    UIImage *thisView=[file captureView:self.view];
    viewcontroll.lastview=thisView;
    
    
    [self.navigationController pushViewController:viewcontroll animated:YES];

}

/*
-(void) TurnToDetailPage2 :(ButtonAddition*) sender
{
    //    DeskItActionButton *this;
    Subscribe_DetailViewController *viewcontroll=[[Subscribe_DetailViewController alloc]init];
    [viewcontroll initStyle:NO :@"test" :0 :sender.IncomingDate];
    [self.navigationController pushViewController:viewcontroll animated:YES];
    
    
}
*/


-(IBAction)sharepress:(id)sender
{
    NSURL *url;
    
    RequestMethod=3;
    
    Shared=!Shared;
    if (Shared) {
        
        url=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,@"/front/front_user/essay/favorite/current_create"]];
        
        [SharedButton setImage:[UIImage imageNamed:@"icon-star-solid-blue.png"] forState:UIControlStateNormal];}
    else {
        url=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,@"/front/front_user/essay/favorite/current_delete"]];
        
        [SharedButton setImage:[UIImage imageNamed:@"icon-star-hollow-black.png"] forState:UIControlStateNormal];}
    
    
    ButtonRequest=[ASIFormDataRequest requestWithURL:url];
    [ButtonRequest setRequestMethod:@"POST"];
    [ButtonRequest setPostValue:[NSNumber numberWithInt:essay_id] forKey:@"essay_id"];
    [ButtonRequest setDelegate:self];
    [ButtonRequest startAsynchronous];
    
}


-(IBAction)admirepress:(id)sender
{
    NSURL *url;
    
    
    RequestMethod=2;
    
    Admired=!Admired;
    if(Admired){
        url=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,@"/front/front_user/essay/like/current_create"]];
        
        [AdmireButton setImage:[UIImage imageNamed:@"finger_selected.png"] forState:UIControlStateNormal];
    }
    else {
        url=[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,@"/front/front_user/essay/like/current_delete"]];
        
        [AdmireButton setImage:[UIImage imageNamed:@"finger_normal.png"] forState:UIControlStateNormal];
    }
    
    
    ButtonRequest=[ASIFormDataRequest requestWithURL:url];
    [ButtonRequest setPostValue:[NSNumber numberWithInt:essay_id] forKey:@"essay_id"];
    [ButtonRequest setRequestMethod:@"POST"];
    
    [ButtonRequest setDelegate:self];
    [ButtonRequest startAsynchronous];
    
    
}


-(void)touchesBegan:(NSSet *)touch withEvent:(UIEvent *)event
{
    if (MenuShowed)
    {
        touches=[[event allTouches]anyObject];
        StartPoint=[touches locationInView:MainView];
        //        NSLog(@"%f,%f,%f,%f,%f,%f",StartPoint.x,StartPoint.y,MenuView.frame.origin.x,MenuView.frame.origin.y,MenuView.frame.origin.x+MenuView.frame.size.width,MenuView.frame.origin.y+MenuView.frame.size.height);
    }
}


-(void)touchesEnded:(NSSet *)touch withEvent:(UIEvent *)event
{
    
    if (MenuShowed) {
        
        if (StartPoint.x<self.MenuView.frame.origin.x||StartPoint.x>self.MenuView.frame.origin.x+self.MenuView.frame.size.width||StartPoint.y<self.MenuView.frame.origin.y||StartPoint.y>self.MenuView.frame.origin.y+self.MenuView.frame.size.height)
        {
            
            [UIView setAnimationsEnabled:YES];
            
            [UIView animateWithDuration:0.5f delay:0 options:0 animations:^{MenuView.alpha=0;} completion:^(BOOL finished){MenuShowed=NO;
                touches=nil;
                self.MenuView.hidden=YES;
            }];
            
            self.MainView.userInteractionEnabled=YES;
            StartPoint=CGPointZero;
            
        }
        
        
    }
    
    
}


-(IBAction)MenuButtonPress:(id)sender
{
    if (!MenuShowed) {
        MenuShowed=YES;
        self.MainView.userInteractionEnabled=NO;
        self.MainView.opaque=YES;
        
        self.MenuView.alpha=0;
        self.MenuView.hidden=NO;
        [UIView setAnimationsEnabled:YES];
        [UIView animateWithDuration:0.5f delay:0 options:0 animations:^{MenuView.alpha=1;} completion:nil];
        
        touches=[[UITouch alloc] init];
    }
    
    

    
}



- (IBAction)JoinButtonPress:(id)sender {
    if(Joined==YES){
        [JoinButton setFrame:CGRectMake(217, 7, 49, 29)];
        [JoinButton setTitle:@"参加" forState:UIControlStateNormal];
        Joined=NO;
    }
    else{
        [JoinButton setFrame:CGRectMake(197, 7, 69, 29)];
        [JoinButton setTitle:@"取消参加" forState:UIControlStateNormal];
        Joined=YES;
    }
    
    
    
}


-(void)MenuButtonInit{
    UIImage *MenuButtonImage=[UIImage imageWithCGImage:[UIImage imageNamed:@"icon-label-blue.png"].CGImage scale:2 orientation:UIImageOrientationUp];
    [MenuButton setImage:MenuButtonImage forState:UIControlStateNormal];
    
    UIImage *backGroundImage=[UIImage imageNamed:@"icon40-pressed-bg.png"];
    [MenuButton setBackgroundImage:backGroundImage forState:UIControlStateHighlighted];
}





- (IBAction)popBack:(id)sender {

    [self.navigationController popViewControllerAnimated:YES];
/*
    if([From isEqualToString:@"Detail"])
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else
    {
        if ([From isEqualToString:@"Root"])
        [self dismissViewControllerAnimated:YES completion:nil];
    }
*/

}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





////request 代理

-(void)requestFinished:(ASIHTTPRequest*)request
{
    NSError *error;
    NSData *responseData = [request responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
  //  NSLog(@"dictionary test %@",responseDictionary);
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        
        
        //        NSLog(@"%@",responseDictionary);
        
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"返回值出错");
            NSLog(@"%@",ResponseErrMsg);
            return ;
        }
        
        
        
        
    }
    

}


-(void)LoadwebRequestFinished:(ASIHTTPRequest *)request{
    NSError *error;
    NSData *responseData = [request responseData];
    NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
    NSString *ResponseErrMsg=[responseDictionary objectForKey:@"err_local"];
  //  NSLog(@"%@",responseDictionary);
    if (error!=nil){
        NSLog(@"Jsonerror:%@",error);
        return;
    }
    else{
        if ([responseDictionary count]==0) {
            NSLog(@"返回空值");
            return;
        }
        
        
        //        NSLog(@"%@",responseDictionary);
        
        NSNull *ResponseErr=[responseDictionary objectForKey:@"err"];
        
        
        if (![ResponseErr isEqual:[NSNull null]]){
            NSLog(@"返回值出错");
            NSLog(@"%@",ResponseErrMsg);
            return ;
        }

        
        
        
    }
    
    //  if (request.url==[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",basePath,@"/front/essay/current_detail"]]) {
//    if (request==WebRequest) {
    
    NSDictionary *temp=[[NSDictionary alloc]initWithDictionary:[responseDictionary objectForKey:@"data"]];
    NSDictionary *TempArray=[[NSDictionary alloc]initWithDictionary:[temp objectForKey:@"essay"]];
    
    Shared=[[temp objectForKey:@"current_favorite"]boolValue];
    Admired=[[temp objectForKey:@"current_like"]boolValue];
    
    
    [self webviewLoad:TempArray];
    
    
    [self PageLoad:TempArray];
    [self loadingStyle];
    
    [self buttonLoad:TempArray];
    
}


-(void)PageLoad:(NSDictionary*)sender
{
    Source=[[NSString alloc]initWithFormat:@"%@",[sender objectForKey:@"source"]];
    Date=[[NSString alloc]initWithFormat:@"%@",[sender objectForKey:@"publish_date"]];
}

-(void)webviewLoad:(NSDictionary*)sender
{
    NSString *cont=[sender objectForKey:@"content"];
    NSString *output;
    
   /*
    NSArray *DevicePath =NSSearchPathForDirectoriesInDomains(NSApplicationDirectory,NSUserDomainMask,YES);
    NSString *pathApp=[DevicePath objectAtIndex:0];
  */
    //  NSURL *baseURL = [NSURL fileURLWithPath:pathApp];
    
    NSString *path = [[NSBundle mainBundle] bundlePath];
    NSURL *baseURL = [NSURL fileURLWithPath:path];
    
    if ([[setting objectForKey:@"Cellular"]intValue]) {
        output=cont;
    }else
    {
        
        DeskItAccessablity *access=[[DeskItAccessablity alloc]init];
        NSArray *Imagelist=[[NSArray alloc]initWithArray:[access ImageList:cont]];
        
        for (NSString *temp in Imagelist) {
           // cont=[cont stringByReplacingOccurrencesOfString:temp withString:targetPath];
            cont=[cont stringByReplacingOccurrencesOfString:temp withString:@"offline.png"];
            
        }
        output=cont;
        
    }
    
    NSLog(@"%@",output);
    
    [MainInformation loadHTMLString:output baseURL:baseURL];

}


-(void)buttonLoad:(NSDictionary*) sender
{
    ButtonList=[sender objectForKey:@"tags"];
    
    int i;
    if ([ButtonList count]<=0) {
        MenuButton.hidden=YES;
    }
    for (i=0; i<[ButtonList count]; i++) {
        NSDictionary *ButtonInf=[ButtonList objectAtIndex:i];
        [ActionList addObject:[ButtonInf objectForKey:@"id"]];
        [NameList addObject:[ButtonInf objectForKey:@"name"]];
        [self addButton :i+1];
    }


}



-(void)dealloc{
    if (WebRequest){
        [WebRequest clearDelegatesAndCancel];
    }
    WebRequest=nil;
    if (ButtonList) {
        [ButtonRequest clearDelegatesAndCancel];
    }
    ButtonRequest=nil;
}


@end
