//
//  DeskItViewController.h
//  InformationPage
//
//  Created by vikingwarlock on 13-7-2.
//  Copyright (c) 2013年 Viking Warlock. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "JsonDataFormatting.h"
#import "ASIHTTPRequestDelegate.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
//#import "Subscribe_DetailViewController.h"
#import "Information_Detail.h"
//#import "DeskItActionButton.h"
//#import "ButtonAddition.h"
#import "DeskItAccessablity.h"



@interface InformationViewController : UIViewController
{
    BOOL Shared;
    BOOL Admired;
    BOOL MenuShowed;
    BOOL Joined;
    UITouch *touches;
    UITapGestureRecognizer *gestrue;
    CGPoint StartPoint;
    
    NSMutableArray *ActionList;
    NSMutableArray *NameList;
    NSArray *ButtonList;
    
    NSString *Date;
    NSString *Source;
    NSString *From;
    
    NSString *selectNUM;
    
    int essay_id;
    int RequestMethod;
    
    ASIFormDataRequest *WebRequest;
    ASIFormDataRequest *ButtonRequest;
    
    NSDictionary *data;
    
    UIPanGestureRecognizer *gesture;
    CGPoint FirstPosition;
    UIImageView *lastView;
    UIImage *lastview;
    
    NSDictionary*setting;
    
}

@property (retain,nonatomic) UIImage *lastview;
@property (weak,nonatomic) IBOutlet UIWebView *MainInformation;


@property (weak,nonatomic) IBOutlet UIButton *AdmireButton;
@property (weak,nonatomic) IBOutlet UIButton *SharedButton;
@property (weak,nonatomic) IBOutlet UIButton *JoinButton;
@property (weak,nonatomic) IBOutlet UIButton *MenuButton;
@property (weak,nonatomic) IBOutlet UIButton *BackButton;

@property (weak,nonatomic) IBOutlet UIView *MenuView;
@property (weak,nonatomic) IBOutlet UIView *MainView;


@property (weak,nonatomic) IBOutlet UILabel *SourcesLabel;
@property (weak,nonatomic) IBOutlet UILabel *DateLabel;


//-(void) initStyle:(NSString*) date :(BOOL) shared :(BOOL)admired :(BOOL)join :(NSString*)source :(NSArray*) activity :(NSArray*) action;
-(void) initStyleFromDetail:(int)essayid :(BOOL)admired :(BOOL)shared :(NSString*)date :(NSString*)source;

-(void) initStyle2 :(NSDictionary*) information :(int)idnum;

-(void) initStyleFromRoot :(NSNumber*)essayid;



@end
