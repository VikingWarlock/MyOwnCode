//
//  ViewController.h
//  My Info
//
//  Created by xtoucher08 on 13-6-30.
//  Copyright (c) 2013年 xtoucher08. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JsonDataFormatting.h"
#import "ASIHTTPRequestDelegate.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"


@interface MyInfoViewController : UIViewController
<UITableViewDataSource,UITableViewDelegate>
{
    ASIFormDataRequest *inforequest;
    UIPanGestureRecognizer *gesture;
    CGPoint FirstPosition;
    UIImageView *lastView;
    UIImage *lastview;
}
@property UIImage *lastview;


@property (nonatomic,retain) IBOutlet UITextField *name;
@property (nonatomic,retain) IBOutlet UITextField *studyNo;
@property (nonatomic,retain) IBOutlet UITextField *college;

@property(nonatomic,retain) IBOutlet UILabel *nameInf;
@property(nonatomic,retain) IBOutlet UILabel *studyNoInf;
@property(nonatomic,retain) IBOutlet UILabel *collageInf;


-(IBAction)closeKeyBoard:(id)sender;

@end
